import urllib.request, urllib.parse, json, ssl, http.cookiejar

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj), urllib.request.HTTPSHandler(context=ctx))

login_data = urllib.parse.urlencode({'user': 'linexwar', 'pass': 'Just09166388665j@'}).encode()
res = opener.open('https://skybridge.linexware.net.ng:2083/login/?login_only=1', data=login_data)
token = json.loads(res.read().decode())['security_token']

backup_php = """<?php
require_once __DIR__ . '/config.php';
try {
    $pdo = getDb();
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $dump = "-- SKYBRIDGE DATABASE FULL BACKUP BEFORE CLEANUP\\n-- Generated at " . date('Y-m-d H:i:s') . "\\n\\nSET FOREIGN_KEY_CHECKS=0;\\n";
    
    $stats = [];
    foreach ($tables as $table) {
        $createStmt = $pdo->query("SHOW CREATE TABLE `" . $table . "`")->fetch(PDO::FETCH_NUM);
        $dump .= "\\n-- -----------------------------\\n-- Table structure for `" . $table . "`\\n-- -----------------------------\\n";
        $dump .= "DROP TABLE IF EXISTS `" . $table . "`;\\n";
        $dump .= $createStmt[1] . ";\\n\\n";
        
        $rows = $pdo->query("SELECT * FROM `" . $table . "`")->fetchAll(PDO::FETCH_ASSOC);
        $count = count($rows);
        $stats[$table] = $count;
        if ($count > 0) {
            $dump .= "-- Dumping data for `" . $table . "`\\n";
            foreach ($rows as $row) {
                $fields = array_map(function($v) use ($pdo) {
                    if ($v === null) return 'NULL';
                    return $pdo->quote($v);
                }, $row);
                $dump .= "INSERT INTO `" . $table . "` (`" . implode('`, `', array_keys($row)) . "`) VALUES (" . implode(', ', $fields) . ");\\n";
            }
        }
    }
    $dump .= "\\nSET FOREIGN_KEY_CHECKS=1;\\n";
    
    file_put_contents('/home/linexwar/skybridge_backup_pre_cleanup.sql', $dump);
    file_put_contents(__DIR__ . '/backup_pre_cleanup.sql', $dump);
    
    jsonResponse('success', 'Backup completed successfully', [
        'tables_count' => count($tables),
        'table_stats' => $stats,
        'backup_size_bytes' => strlen($dump)
    ]);
} catch (Exception $e) {
    jsonResponse('error', $e->getMessage(), null, 500);
}
?>"""

data = urllib.parse.urlencode({
    'dir': '/home/linexwar/skybridge.linexware.net.ng/api',
    'file': 'do_backup.php',
    'content': backup_php
}).encode()
req = urllib.request.Request(f'https://skybridge.linexware.net.ng:2083{token}/execute/Fileman/save_file_content', data=data)
opener.open(req)
print('Backup script saved')
