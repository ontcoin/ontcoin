import urllib.request, urllib.parse, json, ssl, http.cookiejar

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj), urllib.request.HTTPSHandler(context=ctx))

login_data = urllib.parse.urlencode({'user': 'linexwar', 'pass': 'Just09166388665j@'}).encode()
res = opener.open('https://skybridge.linexware.net.ng:2083/login/?login_only=1', data=login_data)
token = json.loads(res.read().decode())['security_token']

migration_php = """<?php
require_once __DIR__ . '/config.php';

try {
    $pdo = getDb();
    
    // 1. Ensure backup file exists before doing ANY alteration
    if (!file_exists('/home/linexwar/skybridge_backup_pre_cleanup.sql')) {
        jsonResponse('error', 'Critical: Backup verification failed. Aborting migration.', null, 500);
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    
    // 2. Consolidate and preserve existing data into users table:
    $userCols = $pdo->query("DESCRIBE users")->fetchAll(PDO::FETCH_COLUMN);
    
    $colsToAdd = [
        'first_name' => "VARCHAR(64) NOT NULL DEFAULT '' AFTER name",
        'last_name' => "VARCHAR(64) NOT NULL DEFAULT '' AFTER first_name",
        'mined_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER fcm_token",
        'referral_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER mined_balance",
        'bonus_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER referral_balance"
    ];
    
    foreach ($colsToAdd as $col => $def) {
        if (!in_array($col, $userCols)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN $col $def");
        }
    }
    
    // Update first_name and last_name from user_profiles if user_profiles exists
    $allTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    if (in_array('user_profiles', $allTables)) {
        $pdo->exec("
            UPDATE users u
            JOIN user_profiles p ON u.user_id = p.user_id
            SET u.first_name = COALESCE(NULLIF(p.first_name, ''), u.first_name),
                u.last_name = COALESCE(NULLIF(p.last_name, ''), u.last_name)
            WHERE p.first_name IS NOT NULL OR p.last_name IS NOT NULL
        ");
    }
    
    // Backfill any empty first_name / last_name from name
    $usersWithoutNames = $pdo->query("SELECT id, name, first_name, last_name FROM users WHERE first_name = '' OR first_name IS NULL")->fetchAll();
    foreach ($usersWithoutNames as $u) {
        $parts = explode(' ', trim($u['name']), 2);
        $fn = $parts[0] ?: 'Skybridge';
        $ln = $parts[1] ?? 'Miner';
        $up = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ? WHERE id = ?");
        $up->execute([$fn, $ln, $u['id']]);
    }
    
    // Transfer balances from wallets or user_balances into users table
    if (in_array('wallets', $allTables)) {
        $pdo->exec("
            UPDATE users u
            JOIN wallets w ON u.user_id = w.user_id
            SET u.mined_balance = w.mined_token_balance,
                u.referral_balance = w.referral_balance,
                u.bonus_balance = w.bonus_balance
        ");
    } elseif (in_array('user_balances', $allTables)) {
        $pdo->exec("
            UPDATE users u
            JOIN user_balances b ON u.user_id = b.user_id
            SET u.mined_balance = b.mined_balance,
                u.referral_balance = b.referral_balance,
                u.bonus_balance = b.bonus_balance
        ");
    }
    
    // 3. Re-create / ensure clean table schema for the 7 CORE tables
    
    // Table 2: mining_sessions
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS mining_sessions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            start_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            end_time DATETIME NOT NULL,
            end_time_unix BIGINT NOT NULL,
            base_hashrate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            effective_hashrate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            booster_multiplier DECIMAL(5,2) NOT NULL DEFAULT 1.00,
            claimed TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_claimed (user_id, claimed),
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Table 3: referrals
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS referrals (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            referrer_id VARCHAR(32) NOT NULL,
            referee_id VARCHAR(32) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            joined_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reward_earned DECIMAL(20,8) NOT NULL DEFAULT 0.00000000,
            UNIQUE KEY uk_referee (referee_id),
            INDEX idx_referrer (referrer_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Table 4: email_verifications
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS email_verifications (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(191) NOT NULL,
            otp VARCHAR(10) NOT NULL,
            action VARCHAR(30) NOT NULL DEFAULT 'register',
            first_name VARCHAR(64) NULL,
            last_name VARCHAR(64) NULL,
            password_hash VARCHAR(255) NULL,
            referral_code VARCHAR(32) NULL,
            is_verified TINYINT(1) NOT NULL DEFAULT 0,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_email_action (email, action)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Table 5: notifications
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS notifications (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            title VARCHAR(255) NOT NULL,
            body TEXT NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_notifications (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Table 6: announcements
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS announcements (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            category VARCHAR(50) NOT NULL DEFAULT 'Announcement',
            content TEXT NOT NULL,
            image_url TEXT NULL,
            external_url TEXT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Table 7: system_settings
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS system_settings (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            maintenance_mode TINYINT(1) NOT NULL DEFAULT 0,
            announcement_message TEXT NULL,
            base_mining_rate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            session_duration_hours INT NOT NULL DEFAULT 25,
            season_name VARCHAR(100) NOT NULL DEFAULT 'Genesis Mining Pool',
            season_pool_balance DECIMAL(20,8) NOT NULL DEFAULT 10000000.00000000,
            min_app_version VARCHAR(20) NOT NULL DEFAULT '1.0.0',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Ensure default system_settings row exists
    $sCount = $pdo->query("SELECT COUNT(*) FROM system_settings")->fetchColumn();
    if ($sCount == 0) {
        $pdo->exec("
            INSERT INTO system_settings (id, maintenance_mode, announcement_message, base_mining_rate, session_duration_hours, season_name, season_pool_balance)
            VALUES (1, 0, 'Welcome to SkyBridge Network Genesis Mining Pool!', 1.0000, 25, 'Genesis Mining Pool', 10000000.00000000)
        ");
    }
    
    // 4. Drop all obsolete, duplicated, admin, and unnecessary tables from LIVE database
    $tablesToKeep = [
        'users',
        'mining_sessions',
        'referrals',
        'email_verifications',
        'notifications',
        'announcements',
        'system_settings'
    ];
    
    $currentTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $dropped = [];
    foreach ($currentTables as $t) {
        if (!in_array($t, $tablesToKeep)) {
            $pdo->exec("DROP TABLE IF EXISTS `$t`");
            $dropped[] = $t;
        }
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    
    $remainingTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $usersCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    
    jsonResponse('success', 'Database restructured cleanly and obsolete tables dropped', [
        'tables_kept' => $remainingTables,
        'tables_dropped' => $dropped,
        'dropped_count' => count($dropped),
        'preserved_users_count' => $usersCount
    ]);

} catch (Exception $e) {
    jsonResponse('error', $e->getMessage(), null, 500);
}
?>"""

data = urllib.parse.urlencode({
    'dir': '/home/linexwar/skybridge.linexware.net.ng/api',
    'file': 'run_cleanup_migration.php',
    'content': migration_php
}).encode()
req = urllib.request.Request(f'https://skybridge.linexware.net.ng:2083{token}/execute/Fileman/save_file_content', data=data)
opener.open(req)
print('Migration script saved')
