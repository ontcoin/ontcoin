import urllib.request, urllib.parse, json, ssl, http.cookiejar

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj), urllib.request.HTTPSHandler(context=ctx))

login_data = urllib.parse.urlencode({'user': 'linexwar', 'pass': 'Just09166388665j@'}).encode()
res = opener.open('https://skybridge.linexware.net.ng:2083/login/?login_only=1', data=login_data)
token = json.loads(res.read().decode())['security_token']
print("cPanel logged in, token:", token)

def save_file(directory, filename, content):
    data = urllib.parse.urlencode({
        'dir': directory,
        'file': filename,
        'content': content
    }).encode()
    req = urllib.request.Request(f'https://skybridge.linexware.net.ng:2083{token}/execute/Fileman/save_file_content', data=data)
    res = opener.open(req)
    result = json.loads(res.read().decode())
    if result.get('status') == 1:
        print(f"Saved: {directory}/{filename}")
    else:
        mk_params = urllib.parse.urlencode({
            'cpanel_jsonapi_version': '2',
            'cpanel_jsonapi_module': 'Fileman',
            'cpanel_jsonapi_func': 'mkfile',
            'dir': directory,
            'name': filename
        })
        opener.open(urllib.request.Request(f'https://skybridge.linexware.net.ng:2083{token}/json-api/cpanel?{mk_params}'))
        res = opener.open(req)
        print(f"Created & Saved: {directory}/{filename}")

def delete_file(directory, filename):
    data = urllib.parse.urlencode({'dir': directory, 'file': filename}).encode()
    req = urllib.request.Request(f'https://skybridge.linexware.net.ng:2083{token}/execute/Fileman/delete_files', data=data)
    opener.open(req)

# Step 1: Execute Table Cleanup and verify the exact 6 core tables
migration_sql_php = """<?php
require_once __DIR__ . '/config.php';

try {
    $pdo = getDb();
    
    // Ensure all obsolete tables are dropped
    $obsolete = [
        'activities', 'admin_audit_logs', 'admin_roles', 'admin_users', 
        'api_tokens', 'app_settings', 'balance_snapshots', 'coins', 
        'kyc', 'kyc_settings', 'kyc_verifications', 
        'leaderboard', 'leaderboard_cache', 'login_sessions', 
        'mining_boosters', 'mining_cycles', 'mining_rewards', 'mining_seasons', 'mining_settings', 
        'referral_codes', 'referral_rewards', 'referral_settings', 'referral_tree', 
        'security_events', 'support_replies', 'support_tickets', 'system_logs', 
        'tasks_and_missions', 'transactions_ledger', 
        'user_balances', 'user_boosters', 'user_devices', 'user_profiles', 'user_settings', 'user_task_completions', 
        'wallets'
    ];
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    foreach ($obsolete as $tbl) {
        $pdo->exec("DROP TABLE IF EXISTS `$tbl`");
    }
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    
    // Make sure the users table has all necessary fields
    $cols = $pdo->query("DESCRIBE users")->fetchAll(PDO::FETCH_COLUMN);
    $neededCols = [
        'first_name' => "VARCHAR(64) NOT NULL DEFAULT '' AFTER name",
        'last_name' => "VARCHAR(64) NOT NULL DEFAULT '' AFTER first_name",
        'mined_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER fcm_token",
        'referral_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER mined_balance",
        'bonus_balance' => "DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER referral_balance"
    ];
    foreach ($neededCols as $col => $sqlDef) {
        if (!in_array($col, $cols)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN $col $sqlDef");
        }
    }
    
    // Core Table 2: mining_sessions
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS mining_sessions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            start_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            end_time DATETIME NOT NULL,
            end_time_unix BIGINT NOT NULL,
            base_hashrate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            effective_hashrate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            booster_multiplier DECIMAL(5,2) NOT NULL DEFAULT 1.00,
            claimed TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_claimed (user_id, claimed),
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Core Table 3: referrals
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS referrals (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            referrer_id VARCHAR(32) NOT NULL,
            referee_id VARCHAR(32) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            joined_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reward_earned DECIMAL(20,8) NOT NULL DEFAULT 0.00000000,
            UNIQUE KEY uk_referee (referee_id),
            INDEX idx_referrer (referrer_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Core Table 4: email_verifications
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS email_verifications (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(191) NOT NULL,
            otp VARCHAR(10) NOT NULL,
            action VARCHAR(30) NOT NULL DEFAULT 'register',
            first_name VARCHAR(64) NULL,
            last_name VARCHAR(64) NULL,
            password_hash VARCHAR(255) NULL,
            referral_code VARCHAR(32) NULL,
            is_verified TINYINT(1) NOT NULL DEFAULT 0,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_email_action (email, action)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Core Table 5: notifications
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS notifications (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            title VARCHAR(255) NOT NULL,
            body TEXT NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_notifications (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Core Table 6: announcements
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS announcements (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            category VARCHAR(50) NOT NULL DEFAULT 'Announcement',
            content TEXT NOT NULL,
            image_url TEXT NULL,
            external_url TEXT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Core Table 7: system_settings
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS system_settings (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            maintenance_mode TINYINT(1) NOT NULL DEFAULT 0,
            announcement_message TEXT NULL,
            base_mining_rate DECIMAL(10,4) NOT NULL DEFAULT 1.0000,
            session_duration_hours INT NOT NULL DEFAULT 25,
            season_name VARCHAR(100) NOT NULL DEFAULT 'Genesis Mining Pool',
            season_pool_balance DECIMAL(20,8) NOT NULL DEFAULT 10000000.00000000,
            min_app_version VARCHAR(20) NOT NULL DEFAULT '1.0.0',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Seed default announcements if empty
    $aCount = $pdo->query("SELECT COUNT(*) FROM announcements")->fetchColumn();
    if ($aCount == 0) {
        $insA = $pdo->prepare("INSERT INTO announcements (title, category, content, external_url) VALUES (?, ?, ?, ?)");
        $insA->execute([
            'SkyBridge Whitepaper Released',
            'Ecosystem',
            'Read the official SkyBridge Network whitepaper detailing tokenomics and mining schedule.',
            'https://skybridge.linexware.net.ng/whitepaper/'
        ]);
        $insA->execute([
            'Genesis Mining Phase Live',
            'Mining',
            'Genesis mining pool is now live. Earn 25 SB every 25 hours with active boosts.',
            'https://skybridge.linexware.net.ng'
        ]);
    }

    $finalTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    jsonResponse('success', 'Tables successfully verified and cleaned', [
        'tables' => $finalTables,
        'count'  => count($finalTables)
    ]);
} catch (Exception $e) {
    jsonResponse('error', $e->getMessage(), null, 500);
}
?>"""

save_file('/home/linexwar/skybridge.linexware.net.ng/api', 'apply_schema.php', migration_sql_php)
print("Schema script uploaded")
