package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import org.json.JSONObject

class AuthActivity : AppCompatActivity() {

    private val GOOGLE_WEB_CLIENT_ID = "216894085731-epf2o124l9i36b048866g082ebg00d9e.apps.googleusercontent.com"

    private lateinit var rootAuth: LinearLayout
    private lateinit var linear7: LinearLayout
    private lateinit var imageview1: ImageView
    private lateinit var textview2: TextView
    private lateinit var textview3: TextView
    private lateinit var linearContinueEmail: LinearLayout
    private lateinit var ivEmailIcon: ImageView
    private lateinit var tvEmailBtnText: TextView
    private lateinit var linear5: LinearLayout
    private lateinit var imageview2: ImageView
    private lateinit var textview5: TextView
    private lateinit var textview6: TextView

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false
    private var isTokenModeAttempted = false

    private val legacyGoogleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account: GoogleSignInAccount = task.getResult(ApiException::class.java)
                val email = account.email ?: ""
                val displayName = account.displayName ?: ""
                val photoUrl = account.photoUrl?.toString() ?: ""
                val idToken = account.idToken ?: ""

                if (email.isNotEmpty()) {
                    completeGoogleSignIn(email, displayName, photoUrl, idToken)
                } else {
                    dismissLoading()
                    CustomToast.showError(this, "Sign-In Error", "No email account was returned by Google.")
                }
            } catch (e: ApiException) {
                if (isTokenModeAttempted) {
                    launchLegacyGoogleSignIn(withToken = false)
                } else {
                    handleGoogleSignInFailure(e)
                }
            }
        } else {
            dismissLoading()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.auth)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        rootAuth = findViewById(R.id.rootAuth)
        linear7 = findViewById(R.id.linear7)
        imageview1 = findViewById(R.id.imageview1)
        textview2 = findViewById(R.id.textview2)
        textview3 = findViewById(R.id.textview3)
        linearContinueEmail = findViewById(R.id.linearContinueEmail)
        ivEmailIcon = findViewById(R.id.ivEmailIcon)
        tvEmailBtnText = findViewById(R.id.tvEmailBtnText)
        linear5 = findViewById(R.id.linear5)
        imageview2 = findViewById(R.id.imageview2)
        textview5 = findViewById(R.id.textview5)
        textview6 = findViewById(R.id.textview6)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        // Continue with Email -> Opens Bottom Sheet Dialog (Login or Create Account)
        linearContinueEmail.setOnClickListener {
            AuthEmailBottomSheetHelper.show(this@AuthActivity)
        }

        // Continue with Google
        linear5.setOnClickListener {
            initiateGoogleLogin()
        }

        // Terms and Privacy links
        textview6.setOnClickListener {
            val options = arrayOf("Terms of Service", "Privacy Policy")
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Legal Documents")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> _chromeTab("https://skybridge.linexware.net.ng/terms-conditions.html")
                        1 -> _chromeTab("https://skybridge.linexware.net.ng/privacy-policy.html")
                    }
                }
                .show()
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = rootAuth
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        applyFonts()
        applyTheme()
    }

    private fun showLoading(message: String = "Connecting...") {
        BlurLoadingOverlay.show(this, message, rootAuth)
    }

    private fun dismissLoading() {
        BlurLoadingOverlay.dismiss(this)
    }

    private fun initiateGoogleLogin() {
        showLoading("Connecting to Google...")
        lifecycleScope.launch {
            try {
                val credentialManager = CredentialManager.create(this@AuthActivity)
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(GOOGLE_WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(this@AuthActivity, request)
                handleCredentialSuccess(result.credential)
            } catch (e: Exception) {
                launchLegacyGoogleSignIn()
            }
        }
    }

    private fun launchLegacyGoogleSignIn(withToken: Boolean = true) {
        try {
            val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()

            if (withToken) {
                isTokenModeAttempted = true
                builder.requestIdToken(GOOGLE_WEB_CLIENT_ID)
            } else {
                isTokenModeAttempted = false
            }

            val gso = builder.build()
            val googleSignInClient: GoogleSignInClient = GoogleSignIn.getClient(this, gso)
            googleSignInClient.signOut().addOnCompleteListener {
                val signInIntent = googleSignInClient.signInIntent
                legacyGoogleSignInLauncher.launch(signInIntent)
            }
        } catch (e: Exception) {
            if (withToken) {
                launchLegacyGoogleSignIn(withToken = false)
            } else {
                handleGoogleSignInFailure(e)
            }
        }
    }

    private fun handleCredentialSuccess(credential: Credential) {
        try {
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val email = googleIdTokenCredential.id
                val displayName = googleIdTokenCredential.displayName ?: ""
                val photoUrl = googleIdTokenCredential.profilePictureUri?.toString() ?: ""
                val idToken = googleIdTokenCredential.idToken

                completeGoogleSignIn(email, displayName, photoUrl, idToken)
            } else {
                launchLegacyGoogleSignIn(withToken = false)
            }
        } catch (e: Exception) {
            launchLegacyGoogleSignIn(withToken = false)
        }
    }

    private fun handleGoogleSignInFailure(exception: Exception) {
        dismissLoading()
        CustomToast.showError(this, "Sign-In Error", "Google Sign-In failed. Please try again.")
    }

    private fun completeGoogleSignIn(
        email: String,
        displayName: String,
        photoUrl: String,
        idToken: String
    ) {
        val googleId = idToken.ifEmpty { "gid_" + Math.abs(email.hashCode()) }
        val finalName = displayName.ifEmpty { email.substringBefore("@") }

        SkybridgeApiClient.googleLogin(
            email = email,
            name = finalName,
            googleId = googleId,
            profileImage = photoUrl,
            referralCode = "",
            idToken = idToken,
            callback = object : SkybridgeApiClient.ApiCallback {
                override fun onSuccess(response: JSONObject) {
                    runOnUiThread {
                        dismissLoading()
                        val data = response.optJSONObject("data") ?: JSONObject()
                        persistUserSession(data)

                        val isNewUser = data.optBoolean("is_new_user", false) || response.optString("message").contains("registration", ignoreCase = true)
                        val hasReferrer = data.optBoolean("has_referrer", false)
                        val referredBy = data.optString("referred_by", "")
                        val needsReferral = isNewUser || (!hasReferrer && (referredBy.isEmpty() || referredBy == "null"))

                        if (needsReferral) {
                            CustomToast.showSuccess(this@AuthActivity, "Welcome to Skybridge!", "Account created. Enter an invitation code if you have one.")
                            val intent = Intent(applicationContext, InvitationActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            }
                            startActivity(intent)
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                            finish()
                        } else {
                            CustomToast.showSuccess(this@AuthActivity, "Welcome Back", "Signed in with Google")
                            val intent = Intent(applicationContext, DashboardActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                putExtra("show_notification_dialog", true)
                            }
                            startActivity(intent)
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                            finish()
                        }
                    }
                }

                override fun onError(errorMessage: String) {
                    runOnUiThread {
                        dismissLoading()
                        CustomToast.showError(this@AuthActivity, "Google Sign In Error", errorMessage)
                    }
                }
            }
        )
    }

    private fun persistUserSession(data: JSONObject) {
        val uid = data.optString("user_id", "")
        val accId = data.optString("account_id", uid)
        val email = data.optString("email", "")
        val name = data.optString("name", data.optString("display_name", ""))
        val refCode = data.optString("referral_code", "")
        val token = data.optString("auth_token", "")
        val pic = data.optString("profile_image", "")

        val editor = d_.edit()
        if (uid.isNotEmpty()) editor.putString("user_id", uid)
        if (accId.isNotEmpty()) editor.putString("account_id", accId)
        if (email.isNotEmpty()) {
            editor.putString("email", email)
            editor.putString("authentication", email)
        }
        if (name.isNotEmpty()) editor.putString("display_name", name)
        if (refCode.isNotEmpty()) editor.putString("referral_code", refCode)
        if (token.isNotEmpty()) editor.putString("auth_token", token)
        if (pic.isNotEmpty()) editor.putString("profile_image", pic)

        editor.putString("user", data.toString())
        editor.apply()

        SkybridgeNotificationScheduler.subscribeUserTopics(this@AuthActivity)
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
            val fontR = Typeface.createFromAsset(assets, "fonts/font.ttf")

            textview2.typeface = fontB
            textview3.typeface = fontR
            tvEmailBtnText.typeface = fontSb
            textview5.typeface = fontSb
            textview6.typeface = fontR
        } catch (ignored: Exception) {}
    }

    private fun roundedDrawable(radiusDp: Int, color: Long, strokeColor: Long? = null, strokeWidthDp: Float = 1.0f): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * density
            setColor(color.toInt())
            if (strokeColor != null) {
                setStroke((strokeWidthDp * density).toInt(), strokeColor.toInt())
            }
        }
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF111827.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF6B7280.toInt()

        // Exact profile view & bottom sheet stroke colors and curved corner radius
        val cornerRadiusDp = 14

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = 0xFF000000.toInt()
            window.navigationBarColor = 0xFF000000.toInt()
            rootAuth.setBackgroundResource(R.drawable.bgn_2)
            imageview1.setImageResource(R.drawable.icc_1)

            // Continue with Email: Fully white button, black text and black icon
            linearContinueEmail.background = roundedDrawable(cornerRadiusDp, 0xFFFFFFFFL, null)
            tvEmailBtnText.setTextColor(0xFF000000.toInt())
            ivEmailIcon.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)

            // Continue with Google: Transparent background with light stroke
            linear5.background = roundedDrawable(cornerRadiusDp, 0x00FFFFFFL, 0x40FFFFFFL, 1.0f)
            textview5.setTextColor(0xFFFFFFFF.toInt())
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = 0xFFFFFFFF.toInt()
            window.navigationBarColor = 0xFFFFFFFF.toInt()
            rootAuth.setBackgroundResource(R.drawable.bgn_1)
            imageview1.setImageResource(R.drawable.icc_2)

            val lightButtonBg = 0xFFFFFFFFL
            val lightStrokeColor = 0xFFE5E7EBL // Matching bottom sheet & profile view exact light gray

            // Continue with Email: Edged curved corners, soft light gray stroke (not pure black)
            linearContinueEmail.background = roundedDrawable(cornerRadiusDp, lightButtonBg, lightStrokeColor, 1.0f)
            tvEmailBtnText.setTextColor(0xFF111827.toInt())
            ivEmailIcon.setColorFilter(0xFF111827.toInt(), PorterDuff.Mode.SRC_IN)

            // Continue with Google: Edged curved corners, soft light gray stroke
            linear5.background = roundedDrawable(cornerRadiusDp, lightButtonBg, lightStrokeColor, 1.0f)
            textview5.setTextColor(0xFF111827.toInt())
        }

        textview2.setTextColor(textPrimary)
        textview3.setTextColor(textSecondary)

        setupLegalDisclaimer(textSecondary)
    }

    private fun setupLegalDisclaimer(defaultColor: Int) {
        val disclaimer = "On continue clicked you've agreed to our Terms & Conditions and read our Privacy & Policy ."
        val spannable = android.text.SpannableString(disclaimer)
        val termsStart = disclaimer.indexOf("Terms & Conditions")
        val termsEnd = if (termsStart != -1) termsStart + "Terms & Conditions".length else -1
        val privacyStart = disclaimer.indexOf("Privacy & Policy")
        val privacyEnd = if (privacyStart != -1) privacyStart + "Privacy & Policy".length else -1

        val linkColor = if (isDarkMode) Color.WHITE else Color.parseColor("#111827")

        if (termsStart != -1) {
            spannable.setSpan(object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    _chromeTab("https://skybridge.linexware.net.ng/terms-conditions.html")
                }
                override fun updateDrawState(ds: android.text.TextPaint) {
                    super.updateDrawState(ds)
                    ds.color = linkColor
                    ds.isUnderlineText = true
                }
            }, termsStart, termsEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        if (privacyStart != -1) {
            spannable.setSpan(object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    _chromeTab("https://skybridge.linexware.net.ng/privacy-policy.html")
                }
                override fun updateDrawState(ds: android.text.TextPaint) {
                    super.updateDrawState(ds)
                    ds.color = linkColor
                    ds.isUnderlineText = true
                }
            }, privacyStart, privacyEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        textview6.text = spannable
        textview6.movementMethod = android.text.method.LinkMovementMethod.getInstance()
    }

    private fun _chromeTab(link: String) {
        val color = if (isDarkMode) Color.parseColor("#000000") else Color.parseColor("#FFFFFF")
        val colorSchemeParams = CustomTabColorSchemeParams.Builder()
            .setToolbarColor(color)
            .build()
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setDefaultColorSchemeParams(colorSchemeParams)
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(this, Uri.parse(link))
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                startActivity(intent)
            } catch (ignored: Exception) {}
        }
    }
}
