package com.skybridg.linexware.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class OnboardingActivity : AppCompatActivity() {

    private lateinit var d_: SharedPreferences
    private lateinit var rootOnboarding: View
    private lateinit var tvSkip: TextView
    private lateinit var ivOnboardingIcon: ImageView
    private lateinit var tvOnboardingTitle: TextView
    private lateinit var tvOnboardingDesc: TextView
    private lateinit var dot1: View
    private lateinit var dot2: View
    private lateinit var dot3: View
    private lateinit var dot4: View
    private lateinit var btnNext: LinearLayout
    private lateinit var tvBtnText: TextView

    private var currentStep = 1

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        completeOnboarding()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)
        setContentView(R.layout.activity_onboarding)

        rootOnboarding = findViewById(R.id.rootOnboarding)
        tvSkip = findViewById(R.id.tvSkip)
        ivOnboardingIcon = findViewById(R.id.ivOnboardingIcon)
        tvOnboardingTitle = findViewById(R.id.tvOnboardingTitle)
        tvOnboardingDesc = findViewById(R.id.tvOnboardingDesc)
        dot1 = findViewById(R.id.dot1)
        dot2 = findViewById(R.id.dot2)
        dot3 = findViewById(R.id.dot3)
        dot4 = findViewById(R.id.dot4)
        btnNext = findViewById(R.id.btnNext)
        tvBtnText = findViewById(R.id.tvBtnText)

        updateStepUi()

        tvSkip.setOnClickListener {
            completeOnboarding()
        }

        btnNext.setOnClickListener {
            if (currentStep < 4) {
                currentStep++
                updateStepUi()
            } else {
                // Request Notification Permission if needed on Android 13+
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    completeOnboarding()
                }
            }
        }
    }

    private fun updateStepUi() {
        val density = resources.displayMetrics.density
        fun createDotDrawable(isActive: Boolean): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 4 * density
                setColor(if (isActive) 0xFFFFFFFF.toInt() else 0xFF374151.toInt())
            }
        }

        fun createButtonDrawable(): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14 * density
                setColor(0xFFFFFFFF.toInt())
            }
        }

        btnNext.background = createButtonDrawable()

        // Reset all dots
        val inactiveWidth = (8 * density).toInt()
        val activeWidth = (24 * density).toInt()

        val dots = listOf(dot1, dot2, dot3, dot4)
        dots.forEachIndexed { index, view ->
            val isActive = (index + 1) == currentStep
            view.background = createDotDrawable(isActive)
            val params = view.layoutParams
            params.width = if (isActive) activeWidth else inactiveWidth
            view.layoutParams = params
        }

        when (currentStep) {
            1 -> {
                tvOnboardingTitle.text = "Welcome to Skybridge"
                tvOnboardingDesc.text = "The next-generation decentralized network & token mining protocol."
                tvBtnText.text = "Next"
            }
            2 -> {
                tvOnboardingTitle.text = "Daily Network Mining"
                tvOnboardingDesc.text = "Activate your daily 24-hour mining session with one tap and earn tokens continuously."
                tvBtnText.text = "Next"
            }
            3 -> {
                tvOnboardingTitle.text = "Bank-Grade Security"
                tvOnboardingDesc.text = "Protect your account and mining balance with custom passcode lock and biometric authentication."
                tvBtnText.text = "Next"
            }
            4 -> {
                tvOnboardingTitle.text = "Real-Time Network Alerts"
                tvOnboardingDesc.text = "Receive instant alerts when your mining cycle ends so you never miss a reward."
                tvBtnText.text = "Get Started"
            }
        }
    }

    private fun completeOnboarding() {
        d_.edit().putBoolean("has_completed_onboarding", true).apply()

        val userId = d_.getString("user_id", "") ?: ""
        val accountId = d_.getString("account_id", "") ?: ""
        val email = d_.getString("email", "") ?: ""
        val isLoggedIn = d_.contains("authentication") || userId.isNotEmpty() || accountId.isNotEmpty() || email.isNotEmpty()

        val targetActivity = if (isLoggedIn) {
            DashboardActivity::class.java
        } else {
            AuthActivity::class.java
        }

        val intent = Intent(this, targetActivity).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
