package com.skybridg.linexware.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog

object SocialsBottomSheet {

    data class SocialChannel(
        val name: String,
        val iconRes: Int,
        val url: String,
        val iconTint: Int? = null
    )

    fun show(context: Context) {
        val dialog = BottomSheetDialog(context)
        val density = context.resources.displayMetrics.density

        val prefs: SharedPreferences = context.getSharedPreferences("d_", Context.MODE_PRIVATE)
        val isDark = if (prefs.contains("theme")) {
            prefs.getString("theme", "") == "dark"
        } else {
            (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val fontB = try {
            Typeface.createFromAsset(context.assets, "fonts/font_b.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        val fontSb = try {
            Typeface.createFromAsset(context.assets, "fonts/font_sb.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        val fontR = try {
            Typeface.createFromAsset(context.assets, "fonts/font.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }

        val sheetContent = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            val pad = (24 * density).toInt()
            setPadding(pad, (14 * density).toInt(), pad, (28 * density).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(if (isDark) Color.parseColor("#171717") else Color.parseColor("#FFFFFF"))
                cornerRadii = floatArrayOf(
                    24 * density, 24 * density,
                    24 * density, 24 * density,
                    0f, 0f,
                    0f, 0f
                )
            }
        }

        // Top drag handle indicator
        val handle = View(context).apply {
            val hW = (40 * density).toInt()
            val hH = (4 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(hW, hH).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = (16 * density).toInt()
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 2 * density
                setColor(if (isDark) Color.parseColor("#424242") else Color.parseColor("#D6D6D6"))
            }
        }
        sheetContent.addView(handle)

        // Title: "Join our Community"
        val title = TextView(context).apply {
            text = "Join our Community"
            textSize = 19f
            typeface = fontB
            setTextColor(if (isDark) Color.WHITE else Color.BLACK)
        }
        sheetContent.addView(title)

        // Subtitle
        val subtitle = TextView(context).apply {
            text = "Connect with other miners and stay updated."
            textSize = 13f
            typeface = fontR
            setTextColor(if (isDark) Color.parseColor("#9E9E9E") else Color.parseColor("#757575"))
            setPadding(0, (4 * density).toInt(), 0, (20 * density).toInt())
        }
        sheetContent.addView(subtitle)

        // Verified social channels (Facebook, Twitter/X, Telegram, Website - YouTube removed)
        val channels = listOf(
            SocialChannel("Telegram", R.drawable.ic_telegram, "https://t.me/skybridgenetwork"),
            SocialChannel("X", R.drawable.ic_x_twitter, "https://x.com/skybridgenetwork", if (isDark) Color.WHITE else Color.BLACK),
            SocialChannel("Facebook", R.drawable.ic_facebook, "https://facebook.com/skybridgenetwork"),
            SocialChannel("Website", R.drawable.ic_globe_website, "https://skybridge.linexware.net.ng")
        )

        val iconsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        for (item in channels) {
            val itemContainer = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins((4 * density).toInt(), 0, (4 * density).toInt(), 0)
                }
                layoutParams = lp
                isClickable = true
                isFocusable = true
            }

            val iconBox = LinearLayout(context).apply {
                gravity = Gravity.CENTER
                val size = (58 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 16 * density
                    setColor(if (isDark) Color.parseColor("#222222") else Color.parseColor("#F3F3F3"))
                    setStroke((1 * density).toInt(), if (isDark) Color.parseColor("#333333") else Color.parseColor("#E0E0E0"))
                }
            }

            val iv = ImageView(context).apply {
                val iconSize = (28 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
                setImageResource(item.iconRes)
                if (item.iconTint != null) {
                    setColorFilter(item.iconTint)
                }
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            iconBox.addView(iv)

            val label = TextView(context).apply {
                text = item.name
                textSize = 12f
                typeface = fontSb
                gravity = Gravity.CENTER
                setTextColor(if (isDark) Color.parseColor("#E0E0E0") else Color.parseColor("#424242"))
                setPadding(0, (6 * density).toInt(), 0, 0)
            }

            itemContainer.addView(iconBox)
            itemContainer.addView(label)

            itemContainer.setOnClickListener {
                try {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                    context.startActivity(browserIntent)
                } catch (e: Exception) {
                    CustomToast.showError(context as? android.app.Activity, "Error", "Could not open link")
                }
                dialog.dismiss()
            }

            iconsRow.addView(itemContainer)
        }

        sheetContent.addView(iconsRow)

        dialog.setContentView(sheetContent)
        dialog.setOnShowListener {
            dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }
}
