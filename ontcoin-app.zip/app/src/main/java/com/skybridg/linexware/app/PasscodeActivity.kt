package com.skybridg.linexware.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.security.MessageDigest

class PasscodeActivity : AppCompatActivity() {

    private lateinit var d_: SharedPreferences
    private lateinit var tvPasscodeTitle: TextView
    private lateinit var tvPasscodeSubtitle: TextView
    private lateinit var dotPass1: View
    private lateinit var dotPass2: View
    private lateinit var dotPass3: View
    private lateinit var dotPass4: View
    private lateinit var btnKeyBiometric: TextView

    private val inputCode = StringBuilder()
    private var mode = "VERIFY" // "SET" or "VERIFY"
    private var firstAttemptCode = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)
        setContentView(R.layout.activity_passcode)

        mode = intent.getStringExtra("mode") ?: if (d_.contains("passcode_hash")) "VERIFY" else "SET"

        tvPasscodeTitle = findViewById(R.id.tvPasscodeTitle)
        tvPasscodeSubtitle = findViewById(R.id.tvPasscodeSubtitle)
        dotPass1 = findViewById(R.id.dotPass1)
        dotPass2 = findViewById(R.id.dotPass2)
        dotPass3 = findViewById(R.id.dotPass3)
        dotPass4 = findViewById(R.id.dotPass4)
        btnKeyBiometric = findViewById(R.id.btnKeyBiometric)

        val keys = listOf(
            findViewById<TextView>(R.id.btnKey0),
            findViewById<TextView>(R.id.btnKey1),
            findViewById<TextView>(R.id.btnKey2),
            findViewById<TextView>(R.id.btnKey3),
            findViewById<TextView>(R.id.btnKey4),
            findViewById<TextView>(R.id.btnKey5),
            findViewById<TextView>(R.id.btnKey6),
            findViewById<TextView>(R.id.btnKey7),
            findViewById<TextView>(R.id.btnKey8),
            findViewById<TextView>(R.id.btnKey9)
        )

        val density = resources.displayMetrics.density
        fun keyBg(): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1F2937.toInt())
            }
        }

        keys.forEach { key ->
            key.background = keyBg()
            key.setOnClickListener {
                if (inputCode.length < 4) {
                    inputCode.append(key.text.toString())
                    updateDots()
                    if (inputCode.length == 4) {
                        handlePasscodeComplete()
                    }
                }
            }
        }

        val btnBackspace = findViewById<TextView>(R.id.btnKeyBackspace)
        btnBackspace.background = keyBg()
        btnBackspace.setOnClickListener {
            if (inputCode.isNotEmpty()) {
                inputCode.deleteCharAt(inputCode.length - 1)
                updateDots()
            }
        }

        btnKeyBiometric.background = keyBg()
        val canBio = canUseBiometrics()
        if (canBio && mode == "VERIFY") {
            btnKeyBiometric.visibility = View.VISIBLE
            btnKeyBiometric.setOnClickListener {
                showBiometricPrompt()
            }
            // Auto prompt biometrics on launch in VERIFY mode
            showBiometricPrompt()
        } else {
            btnKeyBiometric.visibility = View.INVISIBLE
        }

        setupModeText()
    }

    private fun setupModeText() {
        if (mode == "SET") {
            tvPasscodeTitle.text = "Create Passcode"
            tvPasscodeSubtitle.text = "Set a 4-digit security PIN to protect your Skybridge account"
        } else {
            tvPasscodeTitle.text = "Enter Passcode"
            tvPasscodeSubtitle.text = "Enter your 4-digit security code to unlock Skybridge"
        }
        updateDots()
    }

    private fun updateDots() {
        val density = resources.displayMetrics.density
        fun dotDrawable(filled: Boolean): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (filled) 0xFF38BDF8.toInt() else 0xFF374151.toInt())
            }
        }

        val dots = listOf(dotPass1, dotPass2, dotPass3, dotPass4)
        dots.forEachIndexed { index, view ->
            val isFilled = index < inputCode.length
            view.background = dotDrawable(isFilled)
        }
    }

    private fun handlePasscodeComplete() {
        val code = inputCode.toString()
        if (mode == "SET") {
            if (firstAttemptCode.isEmpty()) {
                firstAttemptCode = code
                inputCode.clear()
                tvPasscodeTitle.text = "Confirm Passcode"
                tvPasscodeSubtitle.text = "Re-enter your 4-digit code to confirm"
                updateDots()
            } else {
                if (code == firstAttemptCode) {
                    savePasscode(code)
                    Toast.makeText(this, "Passcode set successfully!", Toast.LENGTH_SHORT).show()
                    unlockAndProceed()
                } else {
                    Toast.makeText(this, "Passcodes do not match. Please try again.", Toast.LENGTH_SHORT).show()
                    firstAttemptCode = ""
                    inputCode.clear()
                    tvPasscodeTitle.text = "Create Passcode"
                    tvPasscodeSubtitle.text = "Set a 4-digit security PIN"
                    updateDots()
                }
            }
        } else {
            val savedHash = d_.getString("passcode_hash", "") ?: ""
            if (hashPasscode(code) == savedHash) {
                unlockAndProceed()
            } else {
                Toast.makeText(this, "Incorrect passcode. Please try again.", Toast.LENGTH_SHORT).show()
                inputCode.clear()
                updateDots()
            }
        }
    }

    private fun savePasscode(code: String) {
        val hash = hashPasscode(code)
        d_.edit().putString("passcode_hash", hash).putBoolean("passcode_enabled", true).apply()
    }

    private fun hashPasscode(code: String): String {
        val salt = "skybridge_security_salt_2026"
        val bytes = MessageDigest.getInstance("SHA-256").digest((salt + code).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun canUseBiometrics(): Boolean {
        val biometricManager = BiometricManager.from(this)
        return biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun showBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Skybridge")
            .setSubtitle("Use your fingerprint or face recognition")
            .setNegativeButtonText("Use Passcode")
            .build()

        val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                unlockAndProceed()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
            }
        })

        biometricPrompt.authenticate(promptInfo)
    }

    private fun unlockAndProceed() {
        val intent = Intent(this, DashboardActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
