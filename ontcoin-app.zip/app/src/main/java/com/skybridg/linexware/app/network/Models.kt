package com.skybridg.linexware.app.network

import com.google.gson.annotations.SerializedName

// Generic API Response Envelope
data class ApiResponse<T>(
    @SerializedName("status") val status: String = "",
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("message") val message: String = "",
    @SerializedName("data") val data: T? = null,
    @SerializedName("timestamp") val timestamp: String = ""
)

// System Status Data
data class SystemStatusData(
    @SerializedName("maintenance_mode") val maintenanceMode: Boolean = false,
    @SerializedName("min_app_version") val minAppVersion: String = "1.0.0",
    @SerializedName("announcement_message") val announcementMessage: String = "",
    @SerializedName("base_mining_rate") val baseMiningRate: Double = 1.0,
    @SerializedName("session_duration_hours") val sessionDurationHours: Int = 25,
    @SerializedName("min_withdrawal") val minWithdrawal: Double = 100.0,
    @SerializedName("server_time") val serverTime: String = "",
    @SerializedName("server_time_unix") val serverTimeUnix: Long = 0L
)

// User Data
data class UserData(
    @SerializedName("user_id") val userId: String = "",
    @SerializedName("account_id") val accountId: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("first_name") val firstName: String = "",
    @SerializedName("last_name") val lastName: String = "",
    @SerializedName("email") val email: String = "",
    @SerializedName("profile_image") val profileImage: String = "",
    @SerializedName("referral_code") val referralCode: String = "",
    @SerializedName("status") val status: String = "active",
    @SerializedName("kyc_status") val kycStatus: String = "unverified",
    @SerializedName("balance") val balance: Double = 0.0,
    @SerializedName("mined_token_balance") val minedBalance: Double = 0.0,
    @SerializedName("referral_balance") val referralBalance: Double = 0.0,
    @SerializedName("id_token") val idToken: String = ""
)

// Mining Status Data
data class MiningStatusData(
    @SerializedName("is_mining") val isMining: Boolean = false,
    @SerializedName("can_claim") val canClaim: Boolean = false,
    @SerializedName("end_time_unix") val endTimeUnix: Long = 0L,
    @SerializedName("mining_rate") val miningRate: Double = 1.0,
    @SerializedName("cycle_hours") val cycleHours: Int = 25,
    @SerializedName("current_cycle_accumulated") val currentCycleAccumulated: Double = 0.0,
    @SerializedName("session_id") val sessionId: Long? = null,
    @SerializedName("status") val status: String = "none"
)

// Mining Session Start Data
data class MiningSessionData(
    @SerializedName("session_id") val sessionId: Long = 0L,
    @SerializedName("status") val status: String = "mining",
    @SerializedName("start_time") val startTime: String = "",
    @SerializedName("end_time") val endTime: String = "",
    @SerializedName("end_time_unix") val endTimeUnix: Long = 0L,
    @SerializedName("mining_rate") val miningRate: Double = 1.0,
    @SerializedName("cycle_hours") val cycleHours: Int = 25
)

// Mining Claim Data
data class MiningClaimData(
    @SerializedName("claimed_amount") val claimedAmount: Double = 0.0,
    @SerializedName("new_balance") val newBalance: Double = 0.0,
    @SerializedName("previous_balance") val previousBalance: Double = 0.0,
    @SerializedName("wallet") val wallet: Map<String, Any>? = null
)

// Boosters Data
data class BoostersData(
    @SerializedName("boosters") val boosters: List<BoosterItem> = emptyList(),
    @SerializedName("active_boosters") val activeBoosters: List<ActiveBoosterItem> = emptyList()
)

data class BoosterItem(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("title") val title: String = "",
    @SerializedName("multiplier") val multiplier: Double = 1.0,
    @SerializedName("duration_seconds") val durationSeconds: Long = 0L,
    @SerializedName("cost") val cost: Double = 0.0,
    @SerializedName("booster_type") val boosterType: String = ""
)

data class ActiveBoosterItem(
    @SerializedName("booster_id") val boosterId: Int = 0,
    @SerializedName("multiplier") val multiplier: Double = 1.0,
    @SerializedName("expires_at") val expiresAt: String = ""
)

// Season Stats Data
data class SeasonStatsData(
    @SerializedName("season_number") val seasonNumber: Int = 1,
    @SerializedName("title") val title: String = "",
    @SerializedName("pool_reward_pool") val poolRewardPool: Double = 0.0,
    @SerializedName("end_date") val endDate: String = "",
    @SerializedName("is_active") val isActive: Boolean = true
)

// Tasks Data
data class TasksListData(
    @SerializedName("daily_streak") val dailyStreak: Int = 0,
    @SerializedName("tasks") val tasks: List<TaskItem> = emptyList()
)

data class TaskItem(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("title") val title: String = "",
    @SerializedName("reward_amount") val rewardAmount: Double = 0.0,
    @SerializedName("task_type") val taskType: String = "",
    @SerializedName("action_url") val actionUrl: String = "",
    @SerializedName("is_completed") val isCompleted: Boolean = false
)

data class TaskVerifyData(
    @SerializedName("task_id") val taskId: Int = 0,
    @SerializedName("reward_credited") val rewardCredited: Double = 0.0,
    @SerializedName("new_balance") val newBalance: Double = 0.0
)

// Referral Dashboard Data
data class ReferralDashboardData(
    @SerializedName("referral_code") val referralCode: String = "",
    @SerializedName("referral_balance") val referralBalance: Double = 0.0,
    @SerializedName("total_friends") val totalFriends: Int = 0,
    @SerializedName("active_miners") val activeMiners: Int = 0,
    @SerializedName("total_earned") val totalEarned: Double = 0.0,
    @SerializedName("friends") val friends: List<ReferralFriendItem> = emptyList()
)

data class ReferralFriendItem(
    @SerializedName("name") val name: String = "",
    @SerializedName("status") val status: String = "",
    @SerializedName("amount") val amount: String = "",
    @SerializedName("is_active") val isActive: Boolean = false,
    @SerializedName("avatar") val avatar: String = "",
    @SerializedName("avatar_url") val avatarUrl: String = "",
    @SerializedName("joined_at") val joinedAt: String = ""
)

data class ReferralClaimData(
    @SerializedName("claimed_amount") val claimedAmount: Double = 0.0,
    @SerializedName("new_main_balance") val newMainBalance: Double = 0.0,
    @SerializedName("remaining_referral_balance") val remainingReferralBalance: Double = 0.0
)

// Leaderboard Data
data class LeaderboardData(
    @SerializedName("season_number") val seasonNumber: Int = 1,
    @SerializedName("my_rank") val myRank: LeaderboardRankItem? = null,
    @SerializedName("leaderboard") val leaderboard: List<LeaderboardRankItem> = emptyList()
)

data class LeaderboardRankItem(
    @SerializedName("rank") val rank: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("subtitle") val subtitle: String = "",
    @SerializedName("score") val score: String = "",
    @SerializedName("mined_amount") val minedAmount: Double = 0.0,
    @SerializedName("avatar") val avatar: String = "",
    @SerializedName("avatar_url") val avatarUrl: String = "",
    @SerializedName("user_id") val userId: String = ""
)

// Wallet Data
data class WalletBalanceData(
    @SerializedName("mined_token_balance") val minedBalance: Double = 0.0,
    @SerializedName("locked_balance") val lockedBalance: Double = 0.0,
    @SerializedName("bonus_balance") val bonusBalance: Double = 0.0,
    @SerializedName("referral_balance") val referralBalance: Double = 0.0,
    @SerializedName("total_balance") val totalBalance: Double = 0.0,
    @SerializedName("total_claimed") val totalClaimed: Double = 0.0,
    @SerializedName("total_withdrawn") val totalWithdrawn: Double = 0.0
)

data class WalletHistoryData(
    @SerializedName("transactions") val transactions: List<TransactionItem> = emptyList()
)

data class TransactionItem(
    @SerializedName("id") val id: Long = 0L,
    @SerializedName("tx_hash") val txHash: String = "",
    @SerializedName("type") val type: String = "",
    @SerializedName("amount") val amount: Double = 0.0,
    @SerializedName("fee") val fee: Double = 0.0,
    @SerializedName("status") val status: String = "",
    @SerializedName("created_at") val createdAt: String = ""
)

data class WithdrawalData(
    @SerializedName("tx_hash") val txHash: String = "",
    @SerializedName("amount") val amount: Double = 0.0,
    @SerializedName("status") val status: String = "pending"
)

// KYC Data
data class KycData(
    @SerializedName("status") val status: String = "unverified",
    @SerializedName("kyc_tier") val kycTier: Int = 0,
    @SerializedName("message") val message: String = ""
)

// Notifications & FCM
data class RegisterDeviceRequest(
    @SerializedName("fcm_token") val fcmToken: String,
    @SerializedName("device_fingerprint") val deviceFingerprint: String = ""
)

data class NotificationItem(
    @SerializedName("id") val id: Long = 0L,
    @SerializedName("title") val title: String = "",
    @SerializedName("message") val message: String = "",
    @SerializedName("type") val type: String = "system",
    @SerializedName("is_read") val isRead: Boolean = false,
    @SerializedName("created_at") val createdAt: String = ""
)

