package com.skybridg.linexware.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FeedsActivity : AppCompatActivity() {

    data class FeedItem(
        val id: String,
        val category: String,
        val title: String,
        val description: String,
        val timestamp: String,
        val imageRes: Int? = null,
        val externalUrl: String = "https://skybridge.linexware.net.ng"
    )

    private lateinit var linear1: LinearLayout
    private lateinit var linear2: LinearLayout
    private lateinit var imageview1: ImageView
    private lateinit var textview2: TextView
    private lateinit var linearChips: LinearLayout
    private lateinit var chipAll: TextView
    private lateinit var chipAnnouncements: TextView
    private lateinit var chipEcosystem: TextView
    private lateinit var chipMining: TextView
    private lateinit var vscroll1: ScrollView
    private lateinit var linearFeedsContainer: LinearLayout

    private lateinit var d_: SharedPreferences
    private var selectedCategory: String = "All"

    private val allFeeds = listOf(
        FeedItem(
            id = "feed_1",
            category = "Announcements",
            title = "SkyBridge Mainnet Phase 1 Roadmap Unveiled",
            description = "We are thrilled to announce the official roadmap towards SkyBridge Mainnet. In this phase, node distribution metrics and smart validator incentives are being rolled out to ensure global decentralization.",
            timestamp = "2 hours ago",
            imageRes = R.drawable.carousel_im,
            externalUrl = "https://skybridge.linexware.net.ng/whitepaper/"
        ),
        FeedItem(
            id = "feed_2",
            category = "Mining",
            title = "Cloud Hashrate Optimization Protocol v2.4",
            description = "Our mining algorithm has received an efficiency boost. Active nodes will experience 15% smoother mining yields and reduced device battery usage during active sessions.",
            timestamp = "Yesterday",
            imageRes = null,
            externalUrl = "https://skybridge.linexware.net.ng"
        ),
        FeedItem(
            id = "feed_3",
            category = "Ecosystem",
            title = "Global Ambassador & Referral Milestone Achieved",
            description = "Over 100,000 miners have officially joined the SkyBridge network. Top referrers will receive exclusive Tier 3 Ambassador badges and an extra 5% mining bonus this month.",
            timestamp = "2 days ago",
            imageRes = R.drawable.bgn_1,
            externalUrl = "https://skybridge.linexware.net.ng"
        ),
        FeedItem(
            id = "feed_4",
            category = "Announcements",
            title = "Security & Smart Contract Audit Completed",
            description = "Independent security review has been completed with top remarks on transparency, cryptographic integrity, and token distribution safety.",
            timestamp = "3 days ago",
            imageRes = R.drawable.bgn_2,
            externalUrl = "https://skybridge.linexware.net.ng"
        ),
        FeedItem(
            id = "feed_5",
            category = "Mining",
            title = "Upcoming Halving Schedule & Tokenomics Update",
            description = "Learn more about the planned coin halving schedule designed to ensure long-term token scarcity, value retention, and sustainable validator incentives.",
            timestamp = "5 days ago",
            imageRes = null,
            externalUrl = "https://skybridge.linexware.net.ng"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.feeds)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        linear1 = findViewById(R.id.linear1)
        linear2 = findViewById(R.id.linear2)
        imageview1 = findViewById(R.id.imageview1)
        textview2 = findViewById(R.id.textview2)
        linearChips = findViewById(R.id.linear_chips)
        chipAll = findViewById(R.id.chip_all)
        chipAnnouncements = findViewById(R.id.chip_announcements)
        chipEcosystem = findViewById(R.id.chip_ecosystem)
        chipMining = findViewById(R.id.chip_mining)
        vscroll1 = findViewById(R.id.vscroll1)
        linearFeedsContainer = findViewById(R.id.linear_feeds_container)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        imageview1.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        chipAll.setOnClickListener { selectCategory("All") }
        chipAnnouncements.setOnClickListener { selectCategory("Announcements") }
        chipEcosystem.setOnClickListener { selectCategory("Ecosystem") }
        chipMining.setOnClickListener { selectCategory("Mining") }
    }

    private fun selectCategory(cat: String) {
        selectedCategory = cat
        updateChipsUI()
        renderFeeds()
    }

    private fun updateChipsUI() {
        val isDark = isDarkMode()
        val chips = listOf(
            chipAll to "All",
            chipAnnouncements to "Announcements",
            chipEcosystem to "Ecosystem",
            chipMining to "Mining"
        )

        for ((chip, cat) in chips) {
            val isSelected = selectedCategory == cat
            if (isSelected) {
                chip.setTextColor(if (isDark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                chip.background = roundedDrawable(16, if (isDark) 0xFFFFFFFFL else 0xFF000000L)
            } else {
                chip.setTextColor(0xFF9E9E9E.toInt())
                chip.background = roundedDrawable(16, if (isDark) 0xFF212121L else 0xFFEEEEEEL)
            }
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = linear1
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        _font_()
        _theme_()
        updateChipsUI()
        renderFeeds()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onStart() {
        super.onStart()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onResume() {
        super.onResume()
        _theme_()
    }

    private fun isDarkMode(): Boolean {
        return if (d_.contains("theme")) {
            d_.getString("theme", "") == "dark"
        } else {
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
    }

    fun _font_() {
        textview2.typeface = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
        chipAll.typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
        chipAnnouncements.typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
        chipEcosystem.typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
        chipMining.typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
    }

    private fun roundedDrawable(radiusDp: Int, color: Long): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = SketchwareUtil.getDip(applicationContext, radiusDp)
            setColor(color.toInt())
        }
    }

    fun _theme_() {
        if (isDarkMode()) {
            _dark_()
        } else {
            _light_()
        }
    }

    fun _dark_() {
        window.decorView.systemUiVisibility = 0
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF000000.toInt()
        linear1.setBackgroundColor(0xFF000000.toInt())

        imageview1.setColorFilter(0xFFFFFFFF.toInt(), PorterDuff.Mode.MULTIPLY)
        imageview1.background = roundedDrawable(18, 0xFF212121L)
        textview2.setTextColor(0xFFFFFFFF.toInt())
        updateChipsUI()
    }

    fun _light_() {
        var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
        window.statusBarColor = 0xFFFFFFFF.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        linear1.setBackgroundColor(0xFFFFFFFF.toInt())

        imageview1.setColorFilter(0xFF000000.toInt(), PorterDuff.Mode.MULTIPLY)
        imageview1.background = roundedDrawable(18, 0xFFEEEEEEL)
        textview2.setTextColor(0xFF000000.toInt())
        updateChipsUI()
    }

    private fun renderFeeds() {
        linearFeedsContainer.removeAllViews()
        val isDark = isDarkMode()
        val density = resources.displayMetrics.density

        val filtered = if (selectedCategory == "All") {
            allFeeds
        } else {
            allFeeds.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }

        for (item in filtered) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.setMargins(0, (density * 6).toInt(), 0, (density * 12).toInt())
                layoutParams = lp
                background = roundedDrawable(18, if (isDark) 0xFF212121L else 0xFFF5F5F5L)
                setPadding((density * 16).toInt(), (density * 16).toInt(), (density * 16).toInt(), (density * 16).toInt())
            }

            // Category tag and timestamp row
            val metaRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                gravity = Gravity.CENTER_VERTICAL
            }

            val categoryTag = TextView(this).apply {
                text = item.category.uppercase()
                textSize = 10f
                typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
                setPadding(16, 6, 16, 6)
                val badgeColor = when (item.category) {
                    "Announcements" -> 0xFF2196F3.toInt()
                    "Mining" -> 0xFF00E676.toInt()
                    else -> 0xFFFF9800.toInt()
                }
                setTextColor(badgeColor)
                background = roundedDrawable(6, if (badgeColor == 0xFF00E676.toInt()) 0x2000E676L else 0x202196F3L)
            }

            val spacer = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            }

            val timestamp = TextView(this).apply {
                text = item.timestamp
                textSize = 11f
                typeface = Typeface.createFromAsset(assets, "fonts/font.ttf")
                setTextColor(0xFF9E9E9E.toInt())
            }

            metaRow.addView(categoryTag)
            metaRow.addView(spacer)
            metaRow.addView(timestamp)
            card.addView(metaRow)

            val openDetailAction = View.OnClickListener {
                val intent = Intent(this@FeedsActivity, FeedDetailActivity::class.java).apply {
                    putExtra("title", item.title)
                    putExtra("description", item.description)
                    putExtra("category", item.category)
                    putExtra("timestamp", item.timestamp)
                    putExtra("imageRes", item.imageRes ?: 0)
                    putExtra("url", item.externalUrl)
                }
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }

            card.setOnClickListener(openDetailAction)

            // Feed Image if present
            if (item.imageRes != null) {
                val imageContainer = ImageView(this).apply {
                    val imgLp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        (density * 160).toInt()
                    )
                    imgLp.setMargins(0, (density * 12).toInt(), 0, (density * 8).toInt())
                    layoutParams = imgLp
                    setImageResource(item.imageRes)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    DashUtils.setRoundedClip(this, density * 12)
                    setOnClickListener(openDetailAction)
                }
                card.addView(imageContainer)
            }

            // Title
            val title = TextView(this).apply {
                val titleLp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                titleLp.setMargins(0, (density * 10).toInt(), 0, (density * 6).toInt())
                layoutParams = titleLp
                text = item.title
                textSize = 16f
                typeface = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
                setTextColor(if (isDark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
            }
            card.addView(title)

            // Description
            val desc = TextView(this).apply {
                val descLp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                descLp.setMargins(0, 0, 0, (density * 12).toInt())
                layoutParams = descLp
                text = item.description
                textSize = 13f
                setLineSpacing(0f, 1.15f)
                typeface = Typeface.createFromAsset(assets, "fonts/font.ttf")
                setTextColor(if (isDark) 0xFFBDBDBD.toInt() else 0xFF616161.toInt())
            }
            card.addView(desc)

            // Footer row with Read More & Share
            val footerRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                gravity = Gravity.CENTER_VERTICAL
            }

            val readMore = TextView(this).apply {
                text = "Read More →"
                textSize = 13f
                typeface = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
                setTextColor(0xFF2196F3.toInt())
                setOnClickListener(openDetailAction)
            }

            val footerSpacer = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            }

            val shareIcon = ImageView(this).apply {
                val sz = (density * 32).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz)
                setPadding((density * 6).toInt(), (density * 6).toInt(), (density * 6).toInt(), (density * 6).toInt())
                setImageResource(R.drawable.icon_share_round)
                setColorFilter(if (isDark) 0xFF9E9E9E.toInt() else 0xFF616161.toInt(), PorterDuff.Mode.MULTIPLY)
                setOnClickListener {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${item.title}\n\n${item.description}\n\nRead on SkyBridge: ${item.externalUrl}")
                    }
                    startActivity(Intent.createChooser(shareIntent, "Share SkyBridge Feed"))
                }
            }

            footerRow.addView(readMore)
            footerRow.addView(footerSpacer)
            footerRow.addView(shareIcon)
            card.addView(footerRow)

            linearFeedsContainer.addView(card)
        }
    }
}
