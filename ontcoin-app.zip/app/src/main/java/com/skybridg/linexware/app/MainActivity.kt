package com.skybridg.linexware.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp

/**
 * Clean Splash Screen:
 * Displays brand logo for exactly 2.8 seconds.
 * STRICT REQUIREMENT: Zero loading dialogs or overlays on splash screen.
 * Seamlessly routes to DashboardActivity (if authenticated) or AuthActivity.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var linear1: LinearLayout
    private lateinit var splashImage: ImageView
    private lateinit var d_: SharedPreferences
    private val mainHandler = Handler(Looper.getMainLooper())
    private var transitionRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)
        setContentView(R.layout.main)
        initialize(savedInstanceState)
        _theme_()
        FirebaseApp.initializeApp(this)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        linear1 = findViewById(R.id.linear1)
        splashImage = findViewById(R.id.splash_image)
        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = linear1
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        _theme_()

        val userId = d_.getString("user_id", "") ?: ""
        val accountId = d_.getString("account_id", "") ?: ""
        val email = d_.getString("email", "") ?: ""
        val isLoggedIn = d_.contains("authentication") || userId.isNotEmpty() || accountId.isNotEmpty() || email.isNotEmpty()
        val hasCompletedOnboarding = d_.getBoolean("has_completed_onboarding", false)
        val passcodeEnabled = d_.getBoolean("passcode_enabled", false)

        // Clean, unobstructed splash screen: Exactly 2800ms display time
        transitionRunnable = Runnable {
            if (!isFinishing) {
                val targetActivity = when {
                    !hasCompletedOnboarding -> OnboardingActivity::class.java
                    isLoggedIn && passcodeEnabled -> PasscodeActivity::class.java
                    isLoggedIn -> DashboardActivity::class.java
                    else -> AuthActivity::class.java
                }
                val intent = Intent(applicationContext, targetActivity).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    if (targetActivity == PasscodeActivity::class.java) {
                        putExtra("mode", "VERIFY")
                    }
                }
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        }
        mainHandler.postDelayed(transitionRunnable!!, 2800L)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent dismissal during splash display
    }

    override fun onStart() {
        super.onStart()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onResume() {
        super.onResume()
        _theme_()
    }

    override fun onDestroy() {
        super.onDestroy()
        transitionRunnable?.let { mainHandler.removeCallbacks(it) }
    }

    fun _theme_() {
        if (d_.contains("theme")) {
            if (d_.getString("theme", "") == "dark") {
                _dark_()
            } else {
                _light_()
            }
        } else {
            val nightMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (nightMode) {
                _dark_()
            } else {
                _light_()
            }
        }
    }

    fun _dark_() {
        window.decorView.systemUiVisibility = 0
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF000000.toInt()
        linear1.setBackgroundColor(0xFF000000.toInt())
        splashImage.setImageResource(R.drawable.icc_1)
    }

    fun _light_() {
        var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
        window.statusBarColor = 0xFFFFFFFF.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        linear1.setBackgroundColor(0xFFFFFFFF.toInt())
        splashImage.setImageResource(R.drawable.icc_2)
    }
}
