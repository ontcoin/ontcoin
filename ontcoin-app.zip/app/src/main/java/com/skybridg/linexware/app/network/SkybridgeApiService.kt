package com.skybridg.linexware.app.network

import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface SkybridgeApiService {

    // 1. System
    @GET("system/status.php")
    suspend fun getSystemStatus(): Response<ApiResponse<SystemStatusData>>

    // 2. Auth
    @FormUrlEncoded
    @POST("auth/google-login.php")
    suspend fun googleLogin(
        @FieldMap params: Map<String, String>
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("auth/session-verify.php")
    suspend fun verifySession(
        @Field("user_id") userId: String
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("auth/email-register-init.php")
    suspend fun emailRegisterInit(
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("referral_code") referralCode: String = ""
    ): Response<ApiResponse<Map<String, Any>>>

    @FormUrlEncoded
    @POST("auth/verify-email-otp.php")
    suspend fun verifyEmailOtp(
        @Field("email") email: String,
        @Field("otp") otp: String,
        @Field("fcm_token") fcmToken: String = "",
        @Field("device_fingerprint") deviceFingerprint: String = ""
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("auth/email-login.php")
    suspend fun emailLogin(
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("fcm_token") fcmToken: String = "",
        @Field("device_fingerprint") deviceFingerprint: String = ""
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("auth/forgot-password.php")
    suspend fun forgotPassword(
        @Field("email") email: String
    ): Response<ApiResponse<Map<String, Any>>>

    @FormUrlEncoded
    @POST("auth/reset-password.php")
    suspend fun resetPassword(
        @Field("email") email: String,
        @Field("otp") otp: String,
        @Field("new_password") newPassword: String
    ): Response<ApiResponse<Map<String, Any>>>

    // 3. User & KYC
    @GET("user/profile.php")
    suspend fun getProfile(
        @Query("user_id") userId: String
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("user/update-profile.php")
    suspend fun updateProfile(
        @FieldMap params: Map<String, String>
    ): Response<ApiResponse<UserData>>

    @FormUrlEncoded
    @POST("user/kyc-submit.php")
    suspend fun submitKyc(
        @FieldMap params: Map<String, String>
    ): Response<ApiResponse<KycData>>

    @GET("user/kyc-status.php")
    suspend fun getKycStatus(
        @Query("user_id") userId: String
    ): Response<ApiResponse<KycData>>

    // 4. Mining
    @GET("mining/status.php")
    suspend fun getMiningStatus(
        @Query("user_id") userId: String
    ): Response<ApiResponse<MiningStatusData>>

    @FormUrlEncoded
    @POST("mining/start.php")
    suspend fun startMining(
        @Field("user_id") userId: String,
        @Field("base_hashrate") rate: String = "1.0"
    ): Response<ApiResponse<MiningSessionData>>

    @FormUrlEncoded
    @POST("mining/heartbeat.php")
    suspend fun miningHeartbeat(
        @Field("user_id") userId: String
    ): Response<ApiResponse<Map<String, Any>>>

    @FormUrlEncoded
    @POST("mining/claim.php")
    suspend fun claimMining(
        @Field("user_id") userId: String
    ): Response<ApiResponse<MiningClaimData>>

    @GET("mining/boosters.php")
    suspend fun getBoosters(
        @Query("user_id") userId: String
    ): Response<ApiResponse<BoostersData>>

    @GET("mining/season-stats.php")
    suspend fun getSeasonStats(): Response<ApiResponse<SeasonStatsData>>

    // 5. Tasks
    @GET("tasks/list.php")
    suspend fun getTasksList(
        @Query("user_id") userId: String
    ): Response<ApiResponse<TasksListData>>

    @FormUrlEncoded
    @POST("tasks/verify-task.php")
    suspend fun verifyTask(
        @Field("user_id") userId: String,
        @Field("task_id") taskId: String
    ): Response<ApiResponse<TaskVerifyData>>

    // 6. Referral
    @GET("referral/dashboard.php")
    suspend fun getReferralDashboard(
        @Query("user_id") userId: String
    ): Response<ApiResponse<ReferralDashboardData>>

    @FormUrlEncoded
    @POST("referral/claim-commission.php")
    suspend fun claimReferralCommission(
        @Field("user_id") userId: String
    ): Response<ApiResponse<ReferralClaimData>>

    // 7. Leaderboard
    @GET("leaderboard/global.php")
    suspend fun getGlobalLeaderboard(
        @Query("user_id") userId: String = ""
    ): Response<ApiResponse<LeaderboardData>>

    // 8. Wallet
    @GET("wallet/balance.php")
    suspend fun getWalletBalance(
        @Query("user_id") userId: String
    ): Response<ApiResponse<WalletBalanceData>>

    @GET("wallet/history.php")
    suspend fun getWalletHistory(
        @Query("user_id") userId: String
    ): Response<ApiResponse<WalletHistoryData>>

    @FormUrlEncoded
    @POST("wallet/withdraw.php")
    suspend fun requestWithdrawal(
        @FieldMap params: Map<String, String>
    ): Response<ApiResponse<WithdrawalData>>

    // 9. Notifications & FCM
    @POST("notifications/register-device.php")
    suspend fun registerDevice(
        @retrofit2.http.Body request: RegisterDeviceRequest
    ): Response<ApiResponse<Map<String, String>>>

    @GET("notifications/list.php")
    suspend fun getNotifications(
        @Query("user_id") userId: String
    ): Response<ApiResponse<List<NotificationItem>>>

    @FormUrlEncoded
    @POST("notifications/mark-read.php")
    suspend fun markNotificationRead(
        @Field("user_id") userId: String,
        @Field("notification_id") notificationId: String
    ): Response<ApiResponse<Map<String, Any>>>
}
