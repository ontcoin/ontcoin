package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

object AuthEmailBottomSheetHelper {

    fun show(activity: Activity) {
        val d_: SharedPreferences = activity.getSharedPreferences("d_", Context.MODE_PRIVATE)
        val isDarkMode = if (d_.contains("theme")) {
            d_.getString("theme", "") == "dark"
        } else {
            (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = activity.resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val fontB = try { Typeface.createFromAsset(activity.assets, "fonts/font_b.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontSb = try { Typeface.createFromAsset(activity.assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(activity.assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        val sheetBg = if (isDarkMode) 0xFF181818.toInt() else 0xFFFFFFFF.toInt()
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF111827.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF6B7280.toInt()
        val handleColor = if (isDarkMode) 0xFF404040.toInt() else 0xFFE5E7EB.toInt()

        val dialog = BottomSheetDialog(activity, R.style.AppBottomSheetDialogTheme)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(12), dp(24), dp(28))
            val bgDrawable = GradientDrawable().apply {
                setColor(sheetBg)
                cornerRadii = floatArrayOf(
                    dp(24).toFloat(), dp(24).toFloat(),
                    dp(24).toFloat(), dp(24).toFloat(),
                    0f, 0f, 0f, 0f
                )
            }
            background = bgDrawable
        }

        // Top drag handle notch
        val handle = View(activity).apply {
            val hBg = GradientDrawable().apply {
                setColor(handleColor)
                cornerRadius = dp(3).toFloat()
            }
            background = hBg
        }
        val handleParams = LinearLayout.LayoutParams(dp(44), dp(5)).apply {
            bottomMargin = dp(20)
        }
        root.addView(handle, handleParams)

        // Rounded badge icon container at the top (profile section design)
        val iconBadge = LinearLayout(activity).apply {
            gravity = Gravity.CENTER
            val iconBg = GradientDrawable().apply {
                setColor(if (isDarkMode) 0xFF262626.toInt() else 0xFFF3F4F6.toInt())
                shape = GradientDrawable.OVAL
            }
            background = iconBg
        }
        val iconBadgeParams = LinearLayout.LayoutParams(dp(60), dp(60)).apply {
            bottomMargin = dp(16)
        }

        val iconIv = ImageView(activity).apply {
            setImageResource(R.drawable.envelope)
            setColorFilter(textPrimary, PorterDuff.Mode.SRC_IN)
        }
        val ivParams = LinearLayout.LayoutParams(dp(28), dp(28))
        iconBadge.addView(iconIv, ivParams)
        root.addView(iconBadge, iconBadgeParams)

        // Title
        val tvTitle = TextView(activity).apply {
            text = "Continue with Email"
            textSize = 20f
            typeface = fontB
            setTextColor(textPrimary)
            gravity = Gravity.CENTER
        }
        val titleParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(6)
        }
        root.addView(tvTitle, titleParams)

        // Subtitle message
        val tvSubtitle = TextView(activity).apply {
            text = "Create a new Skybridge account or sign in to access your wallet and miner."
            textSize = 14f
            typeface = fontR
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
            setLineSpacing(dp(2).toFloat(), 1.15f)
        }
        val subParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(24)
        }
        root.addView(tvSubtitle, subParams)

        // Button 1: "Create Account" -> Thick black button, completely rounded (pill)
        val btnCreateAccount = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val cBg = GradientDrawable().apply {
                setColor(if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
                cornerRadius = dp(26).toFloat()
            }
            background = cBg
            isClickable = true
            isFocusable = true
        }
        val createParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(52)
        ).apply {
            bottomMargin = dp(12)
        }
        val tvCreateText = TextView(activity).apply {
            text = "Create Account"
            textSize = 15f
            typeface = fontSb
            setTextColor(if (isDarkMode) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
        btnCreateAccount.addView(tvCreateText)
        btnCreateAccount.setOnClickListener {
            dialog.dismiss()
            val intent = Intent(activity, RegisterActivity::class.java)
            activity.startActivity(intent)
            activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        root.addView(btnCreateAccount, createParams)

        // Button 2: "Sign In" -> Stroked with inside transparent, completely rounded (pill)
        val btnSignIn = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val sBg = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(26).toFloat()
                setStroke((1.5f * density).toInt(), if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF111827.toInt())
            }
            background = sBg
            isClickable = true
            isFocusable = true
        }
        val signInParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(52)
        )
        val tvSignInText = TextView(activity).apply {
            text = "Sign In"
            textSize = 15f
            typeface = fontSb
            setTextColor(textPrimary)
        }
        btnSignIn.addView(tvSignInText)
        btnSignIn.setOnClickListener {
            dialog.dismiss()
            val intent = Intent(activity, LoginActivity::class.java)
            activity.startActivity(intent)
            activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        root.addView(btnSignIn, signInParams)

        dialog.setContentView(root)
        dialog.window?.let { win ->
            win.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { sheet ->
                sheet.setBackgroundColor(Color.TRANSPARENT)
                val behavior = BottomSheetBehavior.from(sheet)
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }
        dialog.show()
    }
}
