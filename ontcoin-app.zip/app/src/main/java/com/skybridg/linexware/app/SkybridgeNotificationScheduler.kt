package com.skybridg.linexware.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessaging
import java.util.Random

object SkybridgeNotificationScheduler {

    private const val TAG = "SkybridgeScheduler"
    const val CHANNEL_ID = "skybridge_alerts"
    const val CHANNEL_NAME = "Skybridge Mining & Reward Alerts"
    private const val PREFS_SCHEDULER = "skybridge_scheduler_prefs"
    private const val KEY_FIRST_TEST_SENT = "key_first_deploy_test_sent"
    private const val KEY_LAST_SENT_INDEX = "key_last_sent_notif_index"

    val RANDOM_MINING_MESSAGES = arrayOf(
        Pair("🎁 Hourly Node Airdrop Live!", "Skybridge network just generated new block rewards. Tap to claim your share before the pool resets!"),
        Pair("⚡ Hashrate Surge Detected!", "Global network hashrate is peaking. Boost your rig speed with a quick ad multiplier now!"),
        Pair("🔥 Don't Break Your Mining Streak!", "Your daily sync multiplier increases every 24h. Check your node to keep your 2x bonus alive."),
        Pair("👥 Referral Squad Rewards Available!", "Miners in your referral tree are actively earning. Collect your passive squad commissions today!"),
        Pair("🌐 Genesis Season 1 Pool Update", "Over 1.5M tokens minted this week! Check the live season leaderboard and your current rank."),
        Pair("⛏️ Mining Rig Status Check", "Is your node actively hashing? Open Skybridge to verify your current block progress and hashrate."),
        Pair("🚀 20% Hashrate Booster Ready", "A temporary speed booster has become available for your account. Activate it to maximize your yield!"),
        Pair("🛡️ Decentralized Node Heartbeat", "Your account security status is verified. Complete a daily ping to validate your proof-of-uptime."),
        Pair("📈 100,000+ Active Miners Milestone!", "The Skybridge Network is expanding rapidly. Invite friends to unlock higher mining tiers together."),
        Pair("💎 Double Your Hourly Yield", "Watch a short sponsor video to instantly add bonus hashrate to your active mining session."),
        Pair("⏳ Halving Countdown in Progress", "Block reward halving approaches as pool thresholds are reached. Accumulate tokens while rewards are highest!"),
        Pair("🔐 Balance Synchronization", "Your mined balance is safeguarded. Review your wallet and verify your backup recovery key."),
        Pair("🏆 Community Hashrate Challenge", "Join today's mining blitz! The top 50 active miners this session receive an exclusive token bonus."),
        Pair("🌙 Evening Mining Cycle Active", "Overnight mining ensures uninterrupted token generation. Ensure your session stays active tonight!"),
        Pair("🌟 Golden Block Discovered!", "Bonus mining rewards are distributed for the next 60 minutes. Open Skybridge and check your balance!")
    )

    fun init(context: Context) {
        createNotificationChannel(context)
        scheduleRepeating15Minutes(context)

        // Trigger immediate test notification 5 seconds after launch on test deployment
        val prefs = context.getSharedPreferences(PREFS_SCHEDULER, Context.MODE_PRIVATE)
        val hasSentTest = prefs.getBoolean(KEY_FIRST_TEST_SENT, false)
        if (!hasSentTest) {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val userEmail = getUserEmail(context)
                    val title = "⚡ Skybridge Mining Active"
                    val desc = if (userEmail.isNotEmpty()) {
                        "Connected to FCM topic for $userEmail. Real-time 15-min mining alerts are active!"
                    } else {
                        "Skybridge node initialized. Ready for automatic 15-minute mining updates!"
                    }
                    showNotification(context, title, desc, 1001)
                    prefs.edit().putBoolean(KEY_FIRST_TEST_SENT, true).apply()
                } catch (e: Exception) {
                    Log.w(TAG, "Test deploy notification handled: ${e.message}")
                }
            }, 5000L)
        }
    }

    fun subscribeUserTopics(context: Context) {
        try {
            val email = getUserEmail(context)
            val accountId = getUserAccountId(context)

            val sanitizedEmail = if (email.isNotEmpty()) {
                sanitizeTopic("user_" + email.lowercase().replace("@", "_at_").replace(".", "_"))
            } else ""

            val sanitizedAccount = if (accountId.isNotEmpty()) {
                sanitizeTopic("acc_$accountId")
            } else ""

            val topicsList = mutableListOf("all", "all_miners", "skybridge_miners", "mining_alerts")
            if (sanitizedEmail.isNotEmpty()) topicsList.add(sanitizedEmail)
            if (sanitizedAccount.isNotEmpty()) topicsList.add(sanitizedAccount)

            val topicsSignature = topicsList.sorted().joinToString(",")

            val prefs = context.getSharedPreferences(PREFS_SCHEDULER, Context.MODE_PRIVATE)
            val savedSignature = prefs.getString("fcm_subscribed_signature", "")

            if (savedSignature == topicsSignature) {
                Log.d(TAG, "Already subscribed to topics: $topicsSignature. Skipping resubscription to prevent TOO_MANY_REGISTRATIONS.")
                return
            }

            val fcm = FirebaseMessaging.getInstance()
            for (topic in topicsList) {
                fcm.subscribeToTopic(topic)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Log.d(TAG, "Successfully subscribed to topic: $topic")
                        } else {
                            Log.w(TAG, "Failed to subscribe to topic: $topic, error: ${task.exception?.message}")
                        }
                    }
            }

            prefs.edit().putString("fcm_subscribed_signature", topicsSignature).apply()
            Log.d(TAG, "Dispatched subscription requests for signature: $topicsSignature")
        } catch (e: Exception) {
            Log.w(TAG, "Topic subscription error: ${e.message}")
        }
    }

    private fun sanitizeTopic(raw: String): String {
        return raw.filter { it.isLetterOrDigit() || it == '_' || it == '-' || it == '~' || it == '%' }
            .take(800)
    }

    private fun getUserEmail(context: Context): String {
        val d_ = context.getSharedPreferences("d_", Context.MODE_PRIVATE)
        return d_.getString("email", "") ?: d_.getString("authentication", "") ?: ""
    }

    private fun getUserAccountId(context: Context): String {
        val d_ = context.getSharedPreferences("d_", Context.MODE_PRIVATE)
        return d_.getString("account_id", "") ?: d_.getString("user_id", "") ?: ""
    }

    fun scheduleRepeating15Minutes(context: Context) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, SkybridgeNotificationReceiver::class.java).apply {
                action = SkybridgeNotificationReceiver.ACTION_PERIODIC_ALERT
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getBroadcast(context, 7788, intent, flags)

            val intervalMillis = 15 * 60 * 1000L // 15 minutes
            val triggerAtMillis = System.currentTimeMillis() + intervalMillis

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerAtMillis, intervalMillis, pendingIntent)
            }
            Log.d(TAG, "15-minute notification alarm successfully scheduled")
        } catch (e: Exception) {
            Log.w(TAG, "Alarm scheduling error: ${e.message}")
        }
    }

    fun scheduleRepeating20Minutes(context: Context) {
        scheduleRepeating15Minutes(context)
    }

    fun dispatchRandomMiningNotification(context: Context) {
        try {
            createNotificationChannel(context)
            val prefs = context.getSharedPreferences(PREFS_SCHEDULER, Context.MODE_PRIVATE)
            val lastIndex = prefs.getInt(KEY_LAST_SENT_INDEX, -1)

            // Select a random index different from the last sent index
            var nextIndex = Random().nextInt(RANDOM_MINING_MESSAGES.size)
            if (RANDOM_MINING_MESSAGES.size > 1 && nextIndex == lastIndex) {
                nextIndex = (nextIndex + 1) % RANDOM_MINING_MESSAGES.size
            }
            prefs.edit().putInt(KEY_LAST_SENT_INDEX, nextIndex).apply()

            val randomPair = RANDOM_MINING_MESSAGES[nextIndex]
            val notifId = (System.currentTimeMillis() % 100000).toInt() + 2000
            showNotification(context, randomPair.first, randomPair.second, notifId)
        } catch (e: Exception) {
            Log.w(TAG, "Dispatch notification error: ${e.message}")
        }
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Real-time Skybridge node and mining updates"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun showNotification(context: Context, title: String, message: String, notificationId: Int) {
        try {
            val intent = Intent(context, DashboardActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("source", "periodic_notification")
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getActivity(context, notificationId, intent, flags)
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setVibrate(longArrayOf(0, 250, 150, 250))
                .setContentIntent(pendingIntent)

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(notificationId, builder.build())
        } catch (e: Exception) {
            Log.w(TAG, "Failed to display notification: ${e.message}")
        }
    }
}
