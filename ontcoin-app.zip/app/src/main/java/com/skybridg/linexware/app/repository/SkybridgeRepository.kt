package com.skybridg.linexware.app.repository

import android.content.Context
import com.skybridg.linexware.app.CustomToast
import com.skybridg.linexware.app.network.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class SkybridgeRepository(private val context: Context) {

    private val api: SkybridgeApiService = NetworkClient.apiService

    init {
        NetworkClient.init(context)
    }

    private suspend fun <T> safeApiCall(apiCall: suspend () -> Response<ApiResponse<T>>): Result<T?> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiCall()
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null && (body.status == "success" || body.success)) {
                        Result.success(body.data)
                    } else {
                        val errMsg = body?.message ?: "Server returned error: ${response.code()}"
                        Result.failure(Exception(errMsg))
                    }
                } else {
                    val errorBody = response.errorBody()?.string() ?: "HTTP error: ${response.code()}"
                    Result.failure(Exception(errorBody))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // 1. System
    suspend fun getSystemStatus(): Result<SystemStatusData?> {
        return safeApiCall { api.getSystemStatus() }
    }

    // 2. Auth
    suspend fun googleLogin(params: Map<String, String>): Result<UserData?> {
        return safeApiCall { api.googleLogin(params) }
    }

    suspend fun verifySession(userId: String): Result<UserData?> {
        return safeApiCall { api.verifySession(userId) }
    }

    // 3. User & KYC
    suspend fun getProfile(userId: String): Result<UserData?> {
        return safeApiCall { api.getProfile(userId) }
    }

    suspend fun updateProfile(params: Map<String, String>): Result<UserData?> {
        return safeApiCall { api.updateProfile(params) }
    }

    suspend fun submitKyc(params: Map<String, String>): Result<KycData?> {
        return safeApiCall { api.submitKyc(params) }
    }

    suspend fun getKycStatus(userId: String): Result<KycData?> {
        return safeApiCall { api.getKycStatus(userId) }
    }

    // 4. Mining
    suspend fun getMiningStatus(userId: String): Result<MiningStatusData?> {
        return safeApiCall { api.getMiningStatus(userId) }
    }

    suspend fun startMining(userId: String, baseRate: String = "1.0"): Result<MiningSessionData?> {
        return safeApiCall { api.startMining(userId, baseRate) }
    }

    suspend fun claimMining(userId: String): Result<MiningClaimData?> {
        return safeApiCall { api.claimMining(userId) }
    }

    suspend fun sendHeartbeat(userId: String): Result<Map<String, Any>?> {
        return safeApiCall { api.miningHeartbeat(userId) }
    }

    suspend fun getBoosters(userId: String): Result<BoostersData?> {
        return safeApiCall { api.getBoosters(userId) }
    }

    suspend fun getSeasonStats(): Result<SeasonStatsData?> {
        return safeApiCall { api.getSeasonStats() }
    }

    // 5. Tasks
    suspend fun getTasksList(userId: String): Result<TasksListData?> {
        return safeApiCall { api.getTasksList(userId) }
    }

    suspend fun verifyTask(userId: String, taskId: String): Result<TaskVerifyData?> {
        return safeApiCall { api.verifyTask(userId, taskId) }
    }

    // 6. Referral
    suspend fun getReferralDashboard(userId: String): Result<ReferralDashboardData?> {
        return safeApiCall { api.getReferralDashboard(userId) }
    }

    suspend fun claimReferralCommission(userId: String): Result<ReferralClaimData?> {
        return safeApiCall { api.claimReferralCommission(userId) }
    }

    // 7. Leaderboard
    suspend fun getGlobalLeaderboard(userId: String = ""): Result<LeaderboardData?> {
        return safeApiCall { api.getGlobalLeaderboard(userId) }
    }

    // 8. Wallet
    suspend fun getWalletBalance(userId: String): Result<WalletBalanceData?> {
        return safeApiCall { api.getWalletBalance(userId) }
    }

    suspend fun getWalletHistory(userId: String): Result<WalletHistoryData?> {
        return safeApiCall { api.getWalletHistory(userId) }
    }

    suspend fun requestWithdrawal(params: Map<String, String>): Result<WithdrawalData?> {
        return safeApiCall { api.requestWithdrawal(params) }
    }
}
