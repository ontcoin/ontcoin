package com.skybridg.linexware.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FeedDetailActivity : AppCompatActivity() {

    private lateinit var linear1: LinearLayout
    private lateinit var linear2: LinearLayout
    private lateinit var imageviewBack: ImageView
    private lateinit var textviewHeader: TextView
    private lateinit var imageviewShare: ImageView

    private lateinit var ivDetailImage: ImageView
    private lateinit var tvDetailCategory: TextView
    private lateinit var tvDetailTimestamp: TextView
    private lateinit var tvDetailTitle: TextView
    private lateinit var tvDetailContent: TextView
    private lateinit var btnOpenArticleLink: LinearLayout
    private lateinit var tvBtnOpenText: TextView
    private lateinit var ivLinkArrow: ImageView

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false

    private var feedTitle: String = ""
    private var feedDesc: String = ""
    private var feedCategory: String = "Announcements"
    private var feedTime: String = ""
    private var feedImageRes: Int = 0
    private var feedUrl: String = "https://skybridge.linexware.net.ng"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.feed_detail)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        linear1 = findViewById(R.id.linear1)
        linear2 = findViewById(R.id.linear2)
        imageviewBack = findViewById(R.id.imageviewBack)
        textviewHeader = findViewById(R.id.textviewHeader)
        imageviewShare = findViewById(R.id.imageviewShare)

        ivDetailImage = findViewById(R.id.ivDetailImage)
        tvDetailCategory = findViewById(R.id.tvDetailCategory)
        tvDetailTimestamp = findViewById(R.id.tvDetailTimestamp)
        tvDetailTitle = findViewById(R.id.tvDetailTitle)
        tvDetailContent = findViewById(R.id.tvDetailContent)
        btnOpenArticleLink = findViewById(R.id.btnOpenArticleLink)
        tvBtnOpenText = findViewById(R.id.tvBtnOpenText)
        ivLinkArrow = findViewById(R.id.ivLinkArrow)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        feedTitle = intent.getStringExtra("title") ?: "Feed Update"
        feedDesc = intent.getStringExtra("description") ?: ""
        feedCategory = intent.getStringExtra("category") ?: "Announcements"
        feedTime = intent.getStringExtra("timestamp") ?: ""
        feedImageRes = intent.getIntExtra("imageRes", 0)
        feedUrl = intent.getStringExtra("url") ?: "https://skybridge.linexware.net.ng"

        imageviewBack.setOnClickListener {
            finish()
        }

        imageviewShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "$feedTitle\n\n$feedDesc\n\nRead more: $feedUrl")
            }
            startActivity(Intent.createChooser(shareIntent, "Share SkyBridge Feed"))
        }

        btnOpenArticleLink.setOnClickListener {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(feedUrl))
                startActivity(browserIntent)
            } catch (e: Exception) {
                CustomToast.showError(this, "Error", "Could not open link: $feedUrl")
            }
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = linear1
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
            rootView.requestApplyInsets()
        }

        applyFonts()
        bindFeedData()
        applyTheme()
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
            val fontR = Typeface.createFromAsset(assets, "fonts/font.ttf")

            textviewHeader.typeface = fontB
            tvDetailCategory.typeface = fontSb
            tvDetailTimestamp.typeface = fontR
            tvDetailTitle.typeface = fontB
            tvDetailContent.typeface = fontR
            tvBtnOpenText.typeface = fontSb
        } catch (ignored: Exception) {}
    }

    private fun bindFeedData() {
        val density = resources.displayMetrics.density

        tvDetailTitle.text = feedTitle
        tvDetailContent.text = feedDesc
        tvDetailCategory.text = feedCategory.uppercase()
        tvDetailTimestamp.text = feedTime

        if (feedImageRes != 0) {
            ivDetailImage.visibility = View.VISIBLE
            ivDetailImage.setImageResource(feedImageRes)
            DashUtils.setRoundedClip(ivDetailImage, density * 18)
        } else {
            ivDetailImage.visibility = View.GONE
        }

        if (feedUrl.isNotEmpty()) {
            btnOpenArticleLink.visibility = View.VISIBLE
        } else {
            btnOpenArticleLink.visibility = View.GONE
        }
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = resources.displayMetrics.density

        val badgeColor = when (feedCategory.lowercase()) {
            "announcements" -> Color.parseColor("#3B82F6")
            "mining" -> Color.parseColor("#10B981")
            else -> Color.parseColor("#8B5CF6")
        }

        tvDetailCategory.setTextColor(badgeColor)
        tvDetailCategory.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 8 * density
            setColor(if (isDarkMode) Color.parseColor("#1F2937") else Color.parseColor("#EEF2FF"))
        }

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = Color.BLACK
            window.navigationBarColor = Color.BLACK
            linear1.setBackgroundColor(Color.BLACK)

            imageviewBack.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#212121"))
            }
            imageviewBack.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)

            imageviewShare.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#212121"))
            }
            imageviewShare.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)

            textviewHeader.setTextColor(Color.WHITE)
            tvDetailTitle.setTextColor(Color.WHITE)
            tvDetailContent.setTextColor(Color.parseColor("#D1D5DB"))
            tvDetailTimestamp.setTextColor(Color.parseColor("#9CA3AF"))

            btnOpenArticleLink.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16 * density
                setColor(Color.parseColor("#212121"))
                setStroke((1 * density).toInt(), Color.parseColor("#374151"))
            }
            tvBtnOpenText.setTextColor(Color.WHITE)
            ivLinkArrow.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = Color.WHITE
            window.navigationBarColor = Color.WHITE
            linear1.setBackgroundColor(Color.WHITE)

            imageviewBack.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#F5F5F5"))
            }
            imageviewBack.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)

            imageviewShare.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#F5F5F5"))
            }
            imageviewShare.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)

            textviewHeader.setTextColor(Color.BLACK)
            tvDetailTitle.setTextColor(Color.BLACK)
            tvDetailContent.setTextColor(Color.parseColor("#4B5563"))
            tvDetailTimestamp.setTextColor(Color.parseColor("#6B7280"))

            btnOpenArticleLink.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16 * density
                setColor(Color.parseColor("#F3F4F6"))
                setStroke((1 * density).toInt(), Color.parseColor("#E5E7EB"))
            }
            tvBtnOpenText.setTextColor(Color.BLACK)
            ivLinkArrow.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
        }
    }
}
