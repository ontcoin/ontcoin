package com.skybridg.linexware.app

import android.content.Context
import android.content.res.Configuration
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable

/**
 * Theme-aware Lottie animation helper.
 * Selects loading_light.json for Dark Mode and loading_dark.json for Light Mode.
 */
object LottieThemeHelper {
    @JvmStatic
    fun isDarkTheme(context: Context): Boolean {
        val prefs = context.getSharedPreferences("d_", Context.MODE_PRIVATE)
        if (prefs.contains("theme")) {
            val t = prefs.getString("theme", "")
            if (t == "dark") return true
            if (t == "light") return false
        }
        return (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    @JvmStatic
    fun getLoadingAnimationAsset(context: Context): String {
        return if (isDarkTheme(context)) "loading_light.json" else "loading_dark.json"
    }

    @JvmStatic
    fun setupAnimation(view: LottieAnimationView) {
        val asset = getLoadingAnimationAsset(view.context)
        view.setAnimation(asset)
        view.repeatCount = LottieDrawable.INFINITE
    }
}
