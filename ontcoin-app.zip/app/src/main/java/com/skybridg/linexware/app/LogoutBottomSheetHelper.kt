package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

object LogoutBottomSheetHelper {

    fun show(activity: Activity) {
        val d_: SharedPreferences = activity.getSharedPreferences("d_", Context.MODE_PRIVATE)
        val isDarkMode = if (d_.contains("theme")) {
            d_.getString("theme", "") == "dark"
        } else {
            (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = activity.resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val fontB = try { Typeface.createFromAsset(activity.assets, "fonts/font_b.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontSb = try { Typeface.createFromAsset(activity.assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(activity.assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        val sheetBg = if (isDarkMode) 0xFF181818.toInt() else 0xFFFFFFFF.toInt()
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF111827.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF6B7280.toInt()
        val cancelBtnBg = if (isDarkMode) 0xFF262626.toInt() else 0xFFF3F4F6.toInt()
        val handleColor = if (isDarkMode) 0xFF404040.toInt() else 0xFFE5E7EB.toInt()

        val dialog = BottomSheetDialog(activity, R.style.AppBottomSheetDialogTheme)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(12), dp(24), dp(28))
            val bgDrawable = GradientDrawable().apply {
                setColor(sheetBg)
                cornerRadii = floatArrayOf(
                    dp(24).toFloat(), dp(24).toFloat(),
                    dp(24).toFloat(), dp(24).toFloat(),
                    0f, 0f, 0f, 0f
                )
            }
            background = bgDrawable
        }

        // Top drag handle
        val handle = View(activity).apply {
            val hBg = GradientDrawable().apply {
                setColor(handleColor)
                cornerRadius = dp(3).toFloat()
            }
            background = hBg
        }
        val handleParams = LinearLayout.LayoutParams(dp(44), dp(5)).apply {
            bottomMargin = dp(20)
        }
        root.addView(handle, handleParams)

        // Logout icon container
        val iconBadge = LinearLayout(activity).apply {
            gravity = Gravity.CENTER
            val iconBg = GradientDrawable().apply {
                setColor(0x22EF4444.toInt())
                shape = GradientDrawable.OVAL
            }
            background = iconBg
        }
        val iconBadgeParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply {
            bottomMargin = dp(16)
        }

        val iconIv = ImageView(activity).apply {
            setImageResource(R.drawable.icon_logout_round)
            setColorFilter(0xFFEF4444.toInt(), PorterDuff.Mode.SRC_IN)
        }
        val ivParams = LinearLayout.LayoutParams(dp(32), dp(32))
        iconBadge.addView(iconIv, ivParams)
        root.addView(iconBadge, iconBadgeParams)

        // Title
        val tvTitle = TextView(activity).apply {
            text = "Sign Out"
            textSize = 20f
            typeface = fontB
            setTextColor(textPrimary)
            gravity = Gravity.CENTER
        }
        val titleParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(8)
        }
        root.addView(tvTitle, titleParams)

        // Subtitle message
        val tvMessage = TextView(activity).apply {
            text = "Are you sure you want to sign out of your Skybridge account? You will need to sign in again to access your wallet and mining sessions."
            textSize = 14f
            typeface = fontR
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
            setLineSpacing(dp(2).toFloat(), 1.15f)
        }
        val msgParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(24)
        }
        root.addView(tvMessage, msgParams)

        // Sign Out confirm button (Red)
        val btnConfirm = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val cBg = GradientDrawable().apply {
                setColor(0xFFEF4444.toInt())
                cornerRadius = dp(14).toFloat()
            }
            background = cBg
            isClickable = true
            isFocusable = true
        }
        val confirmParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(50)
        ).apply {
            bottomMargin = dp(12)
        }
        val tvConfirmText = TextView(activity).apply {
            text = "Yes, Sign Out"
            textSize = 15f
            typeface = fontSb
            setTextColor(Color.WHITE)
        }
        btnConfirm.addView(tvConfirmText)
        root.addView(btnConfirm, confirmParams)

        // Cancel button
        val btnCancel = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val canBg = GradientDrawable().apply {
                setColor(cancelBtnBg)
                cornerRadius = dp(14).toFloat()
            }
            background = canBg
            isClickable = true
            isFocusable = true
        }
        val cancelParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(50)
        )
        val tvCancelText = TextView(activity).apply {
            text = "Cancel"
            textSize = 15f
            typeface = fontSb
            setTextColor(textPrimary)
        }
        btnCancel.addView(tvCancelText)
        root.addView(btnCancel, cancelParams)

        // Click listeners
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        btnConfirm.setOnClickListener {
            dialog.dismiss()
            performSignOut(activity, d_)
        }

        dialog.setContentView(root)
        dialog.window?.let { win ->
            win.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { sheet ->
                sheet.setBackgroundColor(Color.TRANSPARENT)
                BottomSheetBehavior.from(sheet).state = BottomSheetBehavior.STATE_EXPANDED
            }
        }
        dialog.show()
    }

    private fun performSignOut(activity: Activity, sharedPreferences: SharedPreferences) {
        val savedTheme = sharedPreferences.getString("theme", "")
        sharedPreferences.edit().clear().apply()
        if (!savedTheme.isNullOrEmpty()) {
            sharedPreferences.edit().putString("theme", savedTheme).apply()
        }

        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
            GoogleSignIn.getClient(activity, gso).signOut()
        } catch (ignored: Exception) {}

        CustomToast.showSuccess(activity, "Signed Out", "You have been logged out successfully.")

        val intent = Intent(activity, AuthActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        activity.startActivity(intent)
        activity.finishAffinity()
    }
}
