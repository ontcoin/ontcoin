package com.skybridg.linexware.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.skybridg.linexware.app.network.NetworkClient
import com.skybridg.linexware.app.network.RegisterDeviceRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "SkybridgeFCM"
        const val CHANNEL_ID = "skybridge_alerts"
        const val CHANNEL_NAME = "Skybridge Mining & Reward Alerts"
        private const val PREFS_FCM = "skybridge_fcm_prefs"
        private const val KEY_LAST_TOKEN_SYNC = "fcm_last_token_sync_timestamp"

        fun initializeAndSubscribe(context: Context) {
            try {
                // Clear any lingering topic queues from internal Firebase/GMS preferences
                try {
                    val gmsPrefs = context.getSharedPreferences("com.google.android.gms.appid", Context.MODE_PRIVATE)
                    gmsPrefs.edit().remove("topic_operation_queue").remove("topic_operations_queue").apply()
                } catch (ignored: Throwable) {}

                try {
                    val fcmInternalPrefs = context.getSharedPreferences("com.google.firebase.messaging", Context.MODE_PRIVATE)
                    fcmInternalPrefs.edit().remove("topic_operation_queue").remove("topic_operations_queue").apply()
                } catch (ignored: Throwable) {}

                val prefs = context.getSharedPreferences(PREFS_FCM, Context.MODE_PRIVATE)

                // Retrieve device registration token safely
                FirebaseMessaging.getInstance().token
                    .addOnCompleteListener { task ->
                        try {
                            if (task.isSuccessful && task.result != null) {
                                val token = task.result
                                Log.d(TAG, "FCM Token retrieved successfully: $token")
                                NetworkClient.saveFcmToken(context, token)
                                if (NetworkClient.isLoggedIn(context)) {
                                    syncTokenWithBackend(context, token)
                                }
                            } else {
                                Log.d(TAG, "FCM token retrieval deferred: ${task.exception?.message}")
                            }
                        } catch (e: Throwable) {
                            Log.w(TAG, "FCM token completion handled: ${e.message}")
                        }
                    }

                // Subscribe user to broadcast and personalized topics
                SkybridgeNotificationScheduler.subscribeUserTopics(context)

                // If already cached and logged in, sync periodically
                val cachedToken = NetworkClient.getFcmToken(context)
                if (!cachedToken.isNullOrEmpty() && NetworkClient.isLoggedIn(context)) {
                    val lastSync = prefs.getLong(KEY_LAST_TOKEN_SYNC, 0L)
                    val now = System.currentTimeMillis()
                    if (now - lastSync > 6 * 3600 * 1000) { // Sync once every 6 hours max
                        syncTokenWithBackend(context, cachedToken)
                    }
                }
            } catch (e: Throwable) {
                Log.w(TAG, "FCM initialization handled gracefully: ${e.message}")
            }
        }

        fun syncTokenWithBackend(context: Context, token: String) {
            if (token.isEmpty()) return
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val api = NetworkClient.getApiService(context)
                    val deviceFingerprint = "${Build.MANUFACTURER}_${Build.MODEL}_${Build.VERSION.SDK_INT}"
                    val response = api.registerDevice(RegisterDeviceRequest(token, deviceFingerprint))
                    if (response.isSuccessful && response.body()?.status == "success") {
                        val prefs = context.getSharedPreferences(PREFS_FCM, Context.MODE_PRIVATE)
                        prefs.edit().putLong(KEY_LAST_TOKEN_SYNC, System.currentTimeMillis()).apply()
                        Log.d(TAG, "FCM Token synced with Skybridge server successfully")
                    } else {
                        Log.w(TAG, "FCM Token sync response code: ${response.code()}")
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "FCM Token sync network warning: ${e.message}")
                }
            }
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "FCM onNewToken received")
        try {
            NetworkClient.saveFcmToken(applicationContext, token)

            if (NetworkClient.isLoggedIn(applicationContext)) {
                syncTokenWithBackend(applicationContext, token)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "onNewToken handling warning: ${e.message}")
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        val notification = remoteMessage.notification

        val title = notification?.title ?: data["title"] ?: "Skybridge Mining Alert"
        val body = notification?.body ?: data["message"] ?: data["body"] ?: "Check your mining rig and claim tokens!"
        val action = data["action"] ?: data["category"] ?: "general"

        createNotificationChannel()
        displayNotification(title, body, action, data)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = "Real-time alerts for completed mining cycles, airdrops, and squad rewards"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun displayNotification(title: String, body: String, action: String, data: Map<String, String>) {
        val targetClass = if (NetworkClient.isLoggedIn(applicationContext)) {
            DashboardActivity::class.java
        } else {
            MainActivity::class.java
        }

        val intent = Intent(this, targetClass).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("push_action", action)
            for ((key, value) in data) {
                putExtra(key, value)
            }
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(this, System.currentTimeMillis().toInt(), intent, pendingIntentFlags)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)

        val notificationManager = NotificationManagerCompat.from(this)
        try {
            notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), notificationBuilder.build())
        } catch (e: SecurityException) {
            Log.w(TAG, "Notification permission missing on Android 13+", e)
        }
    }
}
