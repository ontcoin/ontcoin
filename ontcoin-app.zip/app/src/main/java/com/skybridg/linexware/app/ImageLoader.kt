package com.skybridg.linexware.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

object ImageLoader {
    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cache = ConcurrentHashMap<String, Bitmap>()

    fun load(url: String, imageView: ImageView, fallbackResId: Int = R.drawable.icc_2) {
        if (url.isBlank()) {
            if (fallbackResId != 0) {
                imageView.setImageResource(fallbackResId)
            }
            return
        }

        if (cache.containsKey(url)) {
            val bmp = cache[url]
            if (bmp != null) {
                imageView.setImageBitmap(bmp)
                return
            }
        }

        executor.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.instanceFollowRedirects = true
                conn.connect()
                val input = conn.inputStream
                val bitmap = BitmapFactory.decodeStream(input)
                input.close()

                if (bitmap != null) {
                    cache[url] = bitmap
                    mainHandler.post {
                        imageView.setImageBitmap(bitmap)
                    }
                } else if (fallbackResId != 0) {
                    mainHandler.post {
                        imageView.setImageResource(fallbackResId)
                    }
                }
            } catch (e: Exception) {
                if (fallbackResId != 0) {
                    mainHandler.post {
                        imageView.setImageResource(fallbackResId)
                    }
                }
            } finally {
                conn?.disconnect()
            }
        }
    }
}
