package com.skybridg.linexware.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.skybridg.linexware.app.network.LeaderboardData
import com.skybridg.linexware.app.repository.SkybridgeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class LeaderboardUiState {
    object Idle : LeaderboardUiState()
    object Loading : LeaderboardUiState()
    data class Loaded(val data: LeaderboardData) : LeaderboardUiState()
    data class Error(val message: String) : LeaderboardUiState()
}

class LeaderboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SkybridgeRepository(application)

    private val _leaderboardState = MutableStateFlow<LeaderboardUiState>(LeaderboardUiState.Idle)
    val leaderboardState: StateFlow<LeaderboardUiState> = _leaderboardState.asStateFlow()

    fun loadLeaderboard(userId: String = "") {
        viewModelScope.launch {
            _leaderboardState.value = LeaderboardUiState.Loading
            val result = repository.getGlobalLeaderboard(userId)
            result.onSuccess { data ->
                if (data != null) {
                    _leaderboardState.value = LeaderboardUiState.Loaded(data)
                } else {
                    _leaderboardState.value = LeaderboardUiState.Error("No leaderboard data returned")
                }
            }.onFailure { err ->
                _leaderboardState.value = LeaderboardUiState.Error(err.localizedMessage ?: "Failed loading leaderboard")
            }
        }
    }
}
