package com.skybridg.linexware.app.network

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import com.google.gson.GsonBuilder
import com.skybridg.linexware.app.AuthActivity
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClient {

    private const val BASE_URL = "https://skybridge.linexware.net.ng/api/"
    private const val PREFS_NAME = "d_"
    private const val KEY_ID_TOKEN = "id_token"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_FCM_TOKEN = "fcm_token"

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun getApiService(context: Context? = null): SkybridgeApiService {
        if (appContext == null && context != null) {
            appContext = context.applicationContext
        }
        return apiService
    }

    fun saveFcmToken(context: Context, token: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_FCM_TOKEN, token).apply()
    }

    fun getFcmToken(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_FCM_TOKEN, null)
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(KEY_ID_TOKEN, "") ?: ""
        val userId = prefs.getString(KEY_USER_ID, "") ?: ""
        return token.isNotEmpty() || userId.isNotEmpty()
    }

    fun clearSession(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .remove(KEY_ID_TOKEN)
            .remove(KEY_USER_ID)
            .remove("display_name")
            .remove("avatar")
            .remove("email")
            .apply()
    }

    private class BearerAuthInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            val original = chain.request()
            val requestBuilder = original.newBuilder()

            // Attach user agent
            requestBuilder.header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) SkybridgeApp/1.0.0")
            requestBuilder.header("Accept", "application/json, text/plain, */*")

            // Attach Bearer token from SharedPreferences if available
            appContext?.let { ctx ->
                val prefs: SharedPreferences = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val token = prefs.getString(KEY_ID_TOKEN, "") ?: ""
                val userId = prefs.getString(KEY_USER_ID, "") ?: ""
                if (token.isNotEmpty()) {
                    requestBuilder.header("Authorization", "Bearer $token")
                } else if (userId.isNotEmpty()) {
                    requestBuilder.header("Authorization", "Bearer $userId")
                }
            }

            val response = chain.proceed(requestBuilder.build())

            // Global 401 Unauthorized handling: clear session and return to AuthActivity
            if (response.code == 401) {
                appContext?.let { ctx ->
                    clearSession(ctx)
                    val loginIntent = Intent(ctx, AuthActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    ctx.startActivity(loginIntent)
                }
            }

            return response
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        OkHttpClient.Builder()
            .addInterceptor(BearerAuthInterceptor())
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private val gson = GsonBuilder()
        .setLenient()
        .create()

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    val apiService: SkybridgeApiService by lazy {
        retrofit.create(SkybridgeApiService::class.java)
    }
}
