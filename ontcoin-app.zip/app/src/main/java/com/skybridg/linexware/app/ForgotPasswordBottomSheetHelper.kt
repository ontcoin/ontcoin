package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.CountDownTimer
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject

object ForgotPasswordBottomSheetHelper {

    fun show(activity: Activity, prefilledEmail: String = "", onPasswordResetSuccess: ((String) -> Unit)? = null) {
        val d_: SharedPreferences = activity.getSharedPreferences("d_", Context.MODE_PRIVATE)
        val isDarkMode = if (d_.contains("theme")) {
            d_.getString("theme", "") == "dark"
        } else {
            (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = activity.resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val fontB = try { Typeface.createFromAsset(activity.assets, "fonts/font_b.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontSb = try { Typeface.createFromAsset(activity.assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(activity.assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        val sheetBg = if (isDarkMode) 0xFF181818.toInt() else 0xFFFFFFFF.toInt()
        val inputBg = if (isDarkMode) 0xFF212121.toInt() else 0xFFEEEEEE.toInt()
        val inputStroke = if (isDarkMode) 0xFF333333.toInt() else 0xFFE0E0E0.toInt()
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF111827.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF6B7280.toInt()
        val btnBg = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        val btnTextColor = if (isDarkMode) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        val handleColor = if (isDarkMode) 0xFF404040.toInt() else 0xFFE5E7EB.toInt()

        val dialog = BottomSheetDialog(activity, R.style.AppBottomSheetDialogTheme)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(28))
            background = GradientDrawable().apply {
                setColor(sheetBg)
                cornerRadii = floatArrayOf(
                    dp(24).toFloat(), dp(24).toFloat(),
                    dp(24).toFloat(), dp(24).toFloat(),
                    0f, 0f, 0f, 0f
                )
            }
        }

        // Handle
        val handle = View(activity).apply {
            background = GradientDrawable().apply {
                setColor(handleColor)
                cornerRadius = dp(3).toFloat()
            }
        }
        val handleParams = LinearLayout.LayoutParams(dp(44), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(18)
        }
        root.addView(handle, handleParams)

        // Title
        val tvTitle = TextView(activity).apply {
            text = "Reset Password"
            textSize = 20f
            typeface = fontB
            setTextColor(textPrimary)
        }
        root.addView(tvTitle)

        // Subtitle
        val tvSubtitle = TextView(activity).apply {
            text = "Enter your registered email address and we'll send you a 6-digit code to reset your password."
            textSize = 13f
            typeface = fontR
            setTextColor(textSecondary)
            setLineSpacing(dp(2).toFloat(), 1.1f)
        }
        val subParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(4)
            bottomMargin = dp(20)
        }
        root.addView(tvSubtitle, subParams)

        // Container Step 1
        val step1Container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
        }

        val etEmail = EditText(activity).apply {
            hint = "name@example.com"
            inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setText(prefilledEmail)
            setPadding(dp(16), 0, dp(16), 0)
            setTextColor(textPrimary)
            setHintTextColor(textSecondary)
            textSize = 14f
            typeface = fontR
            background = GradientDrawable().apply {
                setColor(inputBg)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), inputStroke)
            }
        }
        step1Container.addView(etEmail, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))

        val btnSendCode = Button(activity).apply {
            text = "Send Reset Code"
            isAllCaps = false
            textSize = 15f
            typeface = fontB
            setTextColor(btnTextColor)
            background = GradientDrawable().apply {
                setColor(btnBg)
                cornerRadius = dp(14).toFloat()
            }
        }
        val btnSendParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
            topMargin = dp(16)
        }
        step1Container.addView(btnSendCode, btnSendParams)
        root.addView(step1Container)

        // Container Step 2 (Reset password with OTP)
        val step2Container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        val etOtp = EditText(activity).apply {
            hint = "6-Digit Code"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0)
            setTextColor(textPrimary)
            setHintTextColor(textSecondary)
            textSize = 18f
            letterSpacing = 0.3f
            typeface = fontB
            background = GradientDrawable().apply {
                setColor(inputBg)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), inputStroke)
            }
        }
        val otpParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
            bottomMargin = dp(12)
        }
        step2Container.addView(etOtp, otpParams)

        val etNewPass = EditText(activity).apply {
            hint = "New Password (min 6 chars)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
            setPadding(dp(16), 0, dp(16), 0)
            setTextColor(textPrimary)
            setHintTextColor(textSecondary)
            textSize = 14f
            typeface = fontR
            background = GradientDrawable().apply {
                setColor(inputBg)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), inputStroke)
            }
        }
        val newPassParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
            bottomMargin = dp(12)
        }
        step2Container.addView(etNewPass, newPassParams)

        val etConfirmPass = EditText(activity).apply {
            hint = "Confirm New Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
            setPadding(dp(16), 0, dp(16), 0)
            setTextColor(textPrimary)
            setHintTextColor(textSecondary)
            textSize = 14f
            typeface = fontR
            background = GradientDrawable().apply {
                setColor(inputBg)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), inputStroke)
            }
        }
        val confirmPassParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
            bottomMargin = dp(18)
        }
        step2Container.addView(etConfirmPass, confirmPassParams)

        val btnResetSubmit = Button(activity).apply {
            text = "Update Password"
            isAllCaps = false
            textSize = 15f
            typeface = fontB
            setTextColor(btnTextColor)
            background = GradientDrawable().apply {
                setColor(btnBg)
                cornerRadius = dp(14).toFloat()
            }
        }
        step2Container.addView(btnResetSubmit, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))
        root.addView(step2Container)

        var activeEmail = prefilledEmail

        btnSendCode.setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                CustomToast.showError(activity, "Validation", "Please enter a valid email address.")
                return@setOnClickListener
            }
            activeEmail = email
            btnSendCode.isEnabled = false
            btnSendCode.text = "Sending..."

            SkybridgeApiClient.forgotPassword(email, object : SkybridgeApiClient.ApiCallback {
                override fun onSuccess(response: JSONObject) {
                    btnSendCode.isEnabled = true
                    btnSendCode.text = "Send Reset Code"
                    tvSubtitle.text = "Enter the 6-digit code sent to $email and your new password."
                    step1Container.visibility = View.GONE
                    step2Container.visibility = View.VISIBLE
                    CustomToast.showSuccess(activity, "Code Sent", "We sent a 6-digit reset code to $email")
                }

                override fun onError(errorMessage: String) {
                    btnSendCode.isEnabled = true
                    btnSendCode.text = "Send Reset Code"
                    CustomToast.showError(activity, "Error", errorMessage)
                }
            })
        }

        btnResetSubmit.setOnClickListener {
            val otp = etOtp.text.toString().trim()
            val newPass = etNewPass.text.toString()
            val confirmPass = etConfirmPass.text.toString()

            if (otp.length != 6) {
                CustomToast.showError(activity, "Validation", "Please enter the 6-digit code.")
                return@setOnClickListener
            }
            if (newPass.length < 6) {
                CustomToast.showError(activity, "Validation", "Password must be at least 6 characters.")
                return@setOnClickListener
            }
            if (newPass != confirmPass) {
                CustomToast.showError(activity, "Validation", "Passwords do not match.")
                return@setOnClickListener
            }

            btnResetSubmit.isEnabled = false
            btnResetSubmit.text = "Updating..."

            SkybridgeApiClient.resetPassword(activeEmail, otp, newPass, confirmPass, object : SkybridgeApiClient.ApiCallback {
                override fun onSuccess(response: JSONObject) {
                    btnResetSubmit.isEnabled = true
                    btnResetSubmit.text = "Update Password"
                    dialog.dismiss()
                    CustomToast.showSuccess(activity, "Password Reset", "Password updated successfully! You can now sign in.")
                    onPasswordResetSuccess?.invoke(activeEmail)
                }

                override fun onError(errorMessage: String) {
                    btnResetSubmit.isEnabled = true
                    btnResetSubmit.text = "Update Password"
                    CustomToast.showError(activity, "Reset Failed", errorMessage)
                }
            })
        }

        dialog.setContentView(root)
        dialog.window?.let { win ->
            win.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { sheet ->
                sheet.setBackgroundColor(Color.TRANSPARENT)
                BottomSheetBehavior.from(sheet).state = BottomSheetBehavior.STATE_EXPANDED
            }
        }
        dialog.show()
    }
}
