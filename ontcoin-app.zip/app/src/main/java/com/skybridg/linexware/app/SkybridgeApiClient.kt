package com.skybridg.linexware.app

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object SkybridgeApiClient {

    private const val BASE_URL = "https://skybridge.linexware.net.ng/api/"
    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    interface ApiCallback {
        fun onSuccess(response: JSONObject)
        fun onError(errorMessage: String)
    }

    private fun postRequest(endpoint: String, params: Map<String, String>, callback: ApiCallback) {
        executor.execute {
            var urlConnection: HttpURLConnection? = null
            try {
                val url = URL(BASE_URL + endpoint)
                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.requestMethod = "POST"
                urlConnection.connectTimeout = 14000
                urlConnection.readTimeout = 14000
                urlConnection.doInput = true
                urlConnection.doOutput = true

                // Add standard headers for compatibility
                urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) SkybridgeApp/1.0.0")
                urlConnection.setRequestProperty("Accept", "application/json, text/plain, */*")
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                val postData = StringBuilder()
                for ((key, value) in params) {
                    if (postData.isNotEmpty()) postData.append("&")
                    postData.append(URLEncoder.encode(key, "UTF-8"))
                    postData.append("=")
                    postData.append(URLEncoder.encode(value, "UTF-8"))
                }

                val writer = OutputStreamWriter(urlConnection.outputStream)
                writer.write(postData.toString())
                writer.flush()
                writer.close()

                val responseCode = urlConnection.responseCode
                val reader = if (responseCode in 200..299) {
                    BufferedReader(InputStreamReader(urlConnection.inputStream))
                } else {
                    BufferedReader(InputStreamReader(urlConnection.errorStream ?: urlConnection.inputStream))
                }

                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()

                val json = JSONObject(response.toString())
                mainHandler.post {
                    if (json.optString("status") == "success" || json.optBoolean("success", false)) {
                        callback.onSuccess(json)
                    } else {
                        callback.onError(json.optString("message", "API request failed"))
                    }
                }

            } catch (e: Exception) {
                mainHandler.post {
                    callback.onError(e.localizedMessage ?: "Network connection error")
                }
            } finally {
                urlConnection?.disconnect()
            }
        }
    }

    // 1. Google Login / User Registration
    fun googleLogin(
        email: String,
        name: String,
        googleId: String,
        profileImage: String,
        referralCode: String,
        idToken: String = "",
        callback: ApiCallback
    ) {
        val params = mapOf(
            "email" to email,
            "name" to name,
            "google_id" to googleId,
            "profile_image" to profileImage,
            "referral_code" to referralCode,
            "id_token" to idToken
        )
        postRequest("google-login.php", params, callback)
    }

    // 2. Email Authentication Suite
    fun emailRegisterInit(
        firstName: String,
        lastName: String,
        email: String,
        password: String,
        referralCode: String,
        callback: ApiCallback
    ) {
        val params = mapOf(
            "first_name" to firstName,
            "last_name" to lastName,
            "email" to email,
            "password" to password,
            "referral_code" to referralCode
        )
        postRequest("auth/email-register-init.php", params, callback)
    }

    fun verifyEmailOtp(
        email: String,
        otp: String,
        fcmToken: String = "",
        deviceFingerprint: String = "",
        callback: ApiCallback
    ) {
        val params = mapOf(
            "email" to email,
            "otp" to otp,
            "fcm_token" to fcmToken,
            "device_fingerprint" to deviceFingerprint
        )
        postRequest("auth/verify-email-otp.php", params, callback)
    }

    fun emailLogin(
        email: String,
        password: String,
        fcmToken: String = "",
        deviceFingerprint: String = "",
        callback: ApiCallback
    ) {
        val params = mapOf(
            "email" to email,
            "password" to password,
            "fcm_token" to fcmToken,
            "device_fingerprint" to deviceFingerprint
        )
        postRequest("auth/email-login.php", params, callback)
    }

    fun forgotPassword(email: String, callback: ApiCallback) {
        val params = mapOf("email" to email)
        postRequest("auth/forgot-password.php", params, callback)
    }

    fun resetPassword(
        email: String,
        otp: String,
        newPassword: String,
        confirmPassword: String = "",
        callback: ApiCallback
    ) {
        val params = mapOf(
            "email" to email,
            "otp" to otp,
            "new_password" to newPassword,
            "confirm_password" to confirmPassword
        )
        postRequest("auth/reset-password.php", params, callback)
    }

    // 3. Fetch User Profile & Balances
    fun fetchUser(userIdOrEmail: String, callback: ApiCallback) {
        val params = mapOf(
            "user_id" to userIdOrEmail,
            "search" to userIdOrEmail,
            "account_id" to userIdOrEmail,
            "email" to userIdOrEmail
        )
        postRequest("fetch-user.php", params, callback)
    }

    // 4. Mining Actions (status, start_mining, claim, heartbeat)
    fun getMiningStatus(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "status")
        postRequest("mining.php", params, callback)
    }

    fun startMining(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "start_mining")
        postRequest("mining.php", params, callback)
    }

    fun claimMining(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "claim")
        postRequest("mining.php", params, callback)
    }

    fun sendHeartbeat(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "heartbeat")
        postRequest("mining.php", params, callback)
    }

    // 5. Add Referral Code
    fun addReferral(userId: String, referralCode: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "referral_code" to referralCode)
        postRequest("add-referral.php", params, callback)
    }

    // 6. Get Referral Info & Friends List
    fun getReferralInfo(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId)
        postRequest("referral.php", params, callback)
    }

    // 7. Mining Season
    fun getMiningSeason(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "current")
        postRequest("mining-season.php", params, callback)
    }

    // 8. Get Leaderboard
    fun getLeaderboard(period: String = "all_time", callback: ApiCallback) {
        val params = mapOf("period" to period)
        postRequest("leaderboard.php", params, callback)
    }

    // 9. KYC Status / Submission
    fun getKycStatus(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "action" to "status")
        postRequest("kyc.php", params, callback)
    }

    fun submitKyc(userId: String, docType: String, docNumber: String, callback: ApiCallback) {
        val params = mapOf(
            "user_id" to userId,
            "action" to "submit",
            "document_type" to docType,
            "document_number" to docNumber
        )
        postRequest("kyc.php", params, callback)
    }

    // 10. Tasks & Missions
    fun getTasksList(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId)
        postRequest("tasks/list.php", params, callback)
    }

    fun verifyTask(userId: String, taskId: Int, callback: ApiCallback) {
        val params = mapOf("user_id" to userId, "task_id" to taskId.toString())
        postRequest("tasks/verify-task.php", params, callback)
    }

    // 11. System Status & Session Verification
    fun getSystemStatus(callback: ApiCallback) {
        postRequest("system-status.php", emptyMap(), callback)
    }

    fun verifySession(userId: String, callback: ApiCallback) {
        val params = mapOf("user_id" to userId)
        postRequest("auth/session-verify.php", params, callback)
    }
}
