package com.skybridg.linexware.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class VerifyOtpActivity : AppCompatActivity() {

    private lateinit var rootOtp: LinearLayout
    private lateinit var ivBack: ImageView
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var tvTargetEmail: TextView
    private lateinit var otpSlotsContainer: LinearLayout
    private lateinit var etOtp1: EditText
    private lateinit var etOtp2: EditText
    private lateinit var etOtp3: EditText
    private lateinit var etOtp4: EditText
    private lateinit var etOtp5: EditText
    private lateinit var etOtp6: EditText
    private lateinit var tvOtpTimer: TextView
    private lateinit var btnResendOtp: TextView
    private lateinit var btnVerifySubmit: Button

    private lateinit var otpBoxes: Array<EditText>

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false
    private var resendTimer: CountDownTimer? = null
    private var isAutoPasting = false

    private var email = ""
    private var firstName = ""
    private var lastName = ""
    private var password = ""
    private var referral = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_otp)

        email = intent.getStringExtra("extra_email") ?: ""
        firstName = intent.getStringExtra("extra_first_name") ?: ""
        lastName = intent.getStringExtra("extra_last_name") ?: ""
        password = intent.getStringExtra("extra_password") ?: ""
        referral = intent.getStringExtra("extra_referral") ?: ""

        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        rootOtp = findViewById(R.id.rootOtp)
        ivBack = findViewById(R.id.ivBack)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvSubtitle = findViewById(R.id.tvSubtitle)
        tvTargetEmail = findViewById(R.id.tvTargetEmail)
        otpSlotsContainer = findViewById(R.id.otpSlotsContainer)

        etOtp1 = findViewById(R.id.etOtp1)
        etOtp2 = findViewById(R.id.etOtp2)
        etOtp3 = findViewById(R.id.etOtp3)
        etOtp4 = findViewById(R.id.etOtp4)
        etOtp5 = findViewById(R.id.etOtp5)
        etOtp6 = findViewById(R.id.etOtp6)

        otpBoxes = arrayOf(etOtp1, etOtp2, etOtp3, etOtp4, etOtp5, etOtp6)

        tvOtpTimer = findViewById(R.id.tvOtpTimer)
        btnResendOtp = findViewById(R.id.btnResendOtp)
        btnVerifySubmit = findViewById(R.id.btnVerifySubmit)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        tvTargetEmail.text = email

        ivBack.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        btnResendOtp.setOnClickListener {
            resendOtp()
        }

        btnVerifySubmit.setOnClickListener {
            verifyOtp()
        }

        setupOtpInputLogic()
        startTimer()
    }

    private fun setupOtpInputLogic() {
        for (i in otpBoxes.indices) {
            val currentBox = otpBoxes[i]

            currentBox.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (isAutoPasting) return

                    val text = s?.toString() ?: ""
                    // Handle multi-digit paste in any box
                    if (text.length > 1) {
                        distributePastedText(text)
                        return
                    }

                    if (text.length == 1) {
                        if (i < otpBoxes.size - 1) {
                            otpBoxes[i + 1].requestFocus()
                        } else {
                            // Last box filled -> check if complete and auto submit
                            checkAndAutoSubmit()
                        }
                    }
                }

                override fun afterTextChanged(s: Editable?) {}
            })

            currentBox.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DEL) {
                    if (currentBox.text.isEmpty() && i > 0) {
                        otpBoxes[i - 1].text.clear()
                        otpBoxes[i - 1].requestFocus()
                        return@setOnKeyListener true
                    }
                }
                false
            }
        }

        // Focus first box automatically with keyboard
        etOtp1.postDelayed({
            etOtp1.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(etOtp1, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    private fun distributePastedText(rawText: String) {
        val digitsOnly = rawText.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) return

        isAutoPasting = true
        for (i in otpBoxes.indices) {
            if (i < digitsOnly.length) {
                otpBoxes[i].setText(digitsOnly[i].toString())
            } else {
                otpBoxes[i].text.clear()
            }
        }
        isAutoPasting = false

        val targetIndex = (digitsOnly.length - 1).coerceIn(0, otpBoxes.size - 1)
        otpBoxes[targetIndex].requestFocus()
        otpBoxes[targetIndex].setSelection(otpBoxes[targetIndex].text.length)

        if (digitsOnly.length >= 6) {
            checkAndAutoSubmit()
        }
    }

    private fun getOtpCode(): String {
        val sb = StringBuilder()
        for (box in otpBoxes) {
            sb.append(box.text.toString().trim())
        }
        return sb.toString()
    }

    private fun checkAndAutoSubmit() {
        val code = getOtpCode()
        if (code.length == 6) {
            verifyOtp()
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = rootOtp
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        applyFonts()
        applyTheme()
    }

    private fun startTimer() {
        resendTimer?.cancel()
        btnResendOtp.visibility = View.GONE
        tvOtpTimer.visibility = View.VISIBLE

        resendTimer = object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = millisUntilFinished / 1000
                tvOtpTimer.text = "Resend code in ${seconds}s"
            }

            override fun onFinish() {
                tvOtpTimer.visibility = View.GONE
                btnResendOtp.visibility = View.VISIBLE
            }
        }.start()
    }

    private fun resendOtp() {
        BlurLoadingOverlay.show(this, "Resending code...", rootOtp)
        SkybridgeApiClient.emailRegisterInit(firstName, lastName, email, password, referral, object : SkybridgeApiClient.ApiCallback {
            override fun onSuccess(response: JSONObject) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@VerifyOtpActivity)
                    CustomToast.showSuccess(this@VerifyOtpActivity, "Code Resent", "A new 6-digit code was sent to $email")
                    for (box in otpBoxes) {
                        box.text.clear()
                    }
                    etOtp1.requestFocus()
                    startTimer()
                }
            }

            override fun onError(errorMessage: String) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@VerifyOtpActivity)
                    CustomToast.showError(this@VerifyOtpActivity, "Resend Failed", errorMessage)
                }
            }
        })
    }

    private fun verifyOtp() {
        val otp = getOtpCode()
        if (otp.length != 6) {
            CustomToast.showError(this, "Validation", "Please enter the complete 6-digit code.")
            return
        }

        // Hide keyboard
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(rootOtp.windowToken, 0)

        BlurLoadingOverlay.show(this, "Verifying code...", rootOtp)
        SkybridgeApiClient.verifyEmailOtp(
            email = email,
            otp = otp,
            callback = object : SkybridgeApiClient.ApiCallback {
                override fun onSuccess(response: JSONObject) {
                    runOnUiThread {
                        BlurLoadingOverlay.dismiss(this@VerifyOtpActivity)
                        val data = response.optJSONObject("data") ?: JSONObject()
                        persistUserSession(data)
                        CustomToast.showSuccess(this@VerifyOtpActivity, "Account Verified!", "Welcome to Skybridge.")

                        val hasReferrer = referral.isNotEmpty() || data.optBoolean("has_referrer", false)
                        val targetActivity = if (!hasReferrer) {
                            InvitationActivity::class.java
                        } else {
                            DashboardActivity::class.java
                        }

                        val intent = Intent(applicationContext, targetActivity).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            putExtra("show_notification_dialog", true)
                        }
                        startActivity(intent)
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish()
                    }
                }

                override fun onError(errorMessage: String) {
                    runOnUiThread {
                        BlurLoadingOverlay.dismiss(this@VerifyOtpActivity)
                        CustomToast.showError(this@VerifyOtpActivity, "Verification Failed", errorMessage)
                    }
                }
            }
        )
    }

    private fun persistUserSession(data: JSONObject) {
        val uid = data.optString("user_id", "")
        val accId = data.optString("account_id", uid)
        val email = data.optString("email", "")
        val name = data.optString("name", data.optString("display_name", ""))
        val refCode = data.optString("referral_code", "")
        val token = data.optString("auth_token", "")
        val pic = data.optString("profile_image", "")

        val editor = d_.edit()
        if (uid.isNotEmpty()) editor.putString("user_id", uid)
        if (accId.isNotEmpty()) editor.putString("account_id", accId)
        if (email.isNotEmpty()) {
            editor.putString("email", email)
            editor.putString("authentication", email)
        }
        if (name.isNotEmpty()) editor.putString("display_name", name)
        if (refCode.isNotEmpty()) editor.putString("referral_code", refCode)
        if (token.isNotEmpty()) editor.putString("auth_token", token)
        if (pic.isNotEmpty()) editor.putString("profile_image", pic)

        editor.putString("user", data.toString())
        editor.apply()

        SkybridgeNotificationScheduler.subscribeUserTopics(this@VerifyOtpActivity)
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
            val fontR = Typeface.createFromAsset(assets, "fonts/font.ttf")

            tvHeaderTitle.typeface = fontB
            tvSubtitle.typeface = fontR
            tvTargetEmail.typeface = fontSb
            for (box in otpBoxes) {
                box.typeface = fontB
            }
            tvOtpTimer.typeface = fontR
            btnResendOtp.typeface = fontSb
            btnVerifySubmit.typeface = fontB
        } catch (ignored: Exception) {}
    }

    private fun roundedDrawable(radiusDp: Int, color: Long, strokeColor: Long? = null): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            cornerRadius = radiusDp * density
            setColor(color.toInt())
            if (strokeColor != null) {
                setStroke((1.5f * density).toInt(), strokeColor.toInt())
            }
        }
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val inputBg = if (isDarkMode) 0xFF1E293BL else 0xFFF1F5F9L
        val inputStroke = if (isDarkMode) 0xFF334155L else 0xFFCBD5E1L
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF0F172A.toInt()
        val textSecondary = if (isDarkMode) 0xFF94A3B8.toInt() else 0xFF64748B.toInt()
        val btnBg = if (isDarkMode) 0xFFFFFFFFL else 0xFF0F172AL
        val btnTextColor = if (isDarkMode) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = 0xFF000000.toInt()
            window.navigationBarColor = 0xFF000000.toInt()
            rootOtp.setBackgroundColor(0xFF000000.toInt())
            ivBack.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFF1E293BL)
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = 0xFFFFFFFF.toInt()
            window.navigationBarColor = 0xFFFFFFFF.toInt()
            rootOtp.setBackgroundColor(0xFFFFFFFF.toInt())
            ivBack.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFFF1F5F9L)
        }

        tvHeaderTitle.setTextColor(textPrimary)
        tvSubtitle.setTextColor(textSecondary)
        tvTargetEmail.setTextColor(textPrimary)
        tvOtpTimer.setTextColor(textSecondary)
        btnResendOtp.setTextColor(textPrimary)

        for (box in otpBoxes) {
            box.background = roundedDrawable(12, inputBg, inputStroke)
            box.setTextColor(textPrimary)
            box.setHintTextColor(textSecondary)
        }

        btnVerifySubmit.background = roundedDrawable(14, btnBg)
        btnVerifySubmit.setTextColor(btnTextColor)
    }

    override fun onDestroy() {
        super.onDestroy()
        resendTimer?.cancel()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
