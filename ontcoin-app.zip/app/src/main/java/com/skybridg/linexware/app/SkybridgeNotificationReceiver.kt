package com.skybridg.linexware.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class SkybridgeNotificationReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_PERIODIC_ALERT = "com.skybridg.linexware.app.ACTION_PERIODIC_ALERT"
        private const val TAG = "SkybridgeReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        Log.d(TAG, "Notification alarm received: ${intent?.action}")

        // 1. Dispatch a random mining notification
        SkybridgeNotificationScheduler.dispatchRandomMiningNotification(context)

        // 2. Schedule next 20-minute notification cycle
        SkybridgeNotificationScheduler.scheduleRepeating20Minutes(context)
    }
}
