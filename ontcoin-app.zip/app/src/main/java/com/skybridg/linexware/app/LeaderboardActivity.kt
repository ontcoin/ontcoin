package com.skybridg.linexware.app

import android.app.Activity
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch

/**
 * Real Leaderboard Screen:
 * - Fetches real dynamic rankings strictly from api/leaderboard/top.php.
 * - Displays users' real Google avatars with fallback.
 * - Displays rank, name, and balance formatted to 3 decimal places (%.3f SB).
 * - Full frosted blur loading overlay while fetching rankings.
 */
class LeaderboardActivity : AppCompatActivity() {

    private lateinit var rootLeaderboard: RelativeLayout
    private lateinit var linear1: LinearLayout
    private lateinit var linear2: LinearLayout
    private lateinit var imageview1: ImageView
    private lateinit var textview2: TextView

    private lateinit var podiumContainer: LinearLayout
    private lateinit var ivAvatar1: ImageView
    private lateinit var badgeRank1: TextView
    private lateinit var tvNameRank1: TextView
    private lateinit var tvScoreRank1: TextView

    private lateinit var ivAvatar2: ImageView
    private lateinit var badgeRank2: TextView
    private lateinit var tvNameRank2: TextView
    private lateinit var tvScoreRank2: TextView

    private lateinit var ivAvatar3: ImageView
    private lateinit var badgeRank3: TextView
    private lateinit var tvNameRank3: TextView
    private lateinit var tvScoreRank3: TextView

    private lateinit var tvSectionTitle: TextView
    private lateinit var containerLeaderboardList: LinearLayout

    private lateinit var cardStickyYou: LinearLayout
    private lateinit var ivMyAvatar: ImageView
    private lateinit var tvMyLabel: TextView
    private lateinit var tvMyScore: TextView
    private lateinit var tvMyRankBadge: TextView

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leaderboard)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        rootLeaderboard = findViewById(R.id.rootLeaderboard)
        linear1 = findViewById(R.id.linear1)
        linear2 = findViewById(R.id.linear2)
        imageview1 = findViewById(R.id.imageview1)
        textview2 = findViewById(R.id.textview2)

        podiumContainer = findViewById(R.id.podiumContainer)
        ivAvatar1 = findViewById(R.id.ivAvatar1)
        badgeRank1 = findViewById(R.id.badgeRank1)
        tvNameRank1 = findViewById(R.id.tvNameRank1)
        tvScoreRank1 = findViewById(R.id.tvScoreRank1)

        ivAvatar2 = findViewById(R.id.ivAvatar2)
        badgeRank2 = findViewById(R.id.badgeRank2)
        tvNameRank2 = findViewById(R.id.tvNameRank2)
        tvScoreRank2 = findViewById(R.id.tvScoreRank2)

        ivAvatar3 = findViewById(R.id.ivAvatar3)
        badgeRank3 = findViewById(R.id.badgeRank3)
        tvNameRank3 = findViewById(R.id.tvNameRank3)
        tvScoreRank3 = findViewById(R.id.tvScoreRank3)

        tvSectionTitle = findViewById(R.id.tvSectionTitle)
        containerLeaderboardList = findViewById(R.id.containerLeaderboardList)

        cardStickyYou = findViewById(R.id.cardStickyYou)
        ivMyAvatar = findViewById(R.id.ivMyAvatar)
        tvMyLabel = findViewById(R.id.tvMyLabel)
        tvMyScore = findViewById(R.id.tvMyScore)
        tvMyRankBadge = findViewById(R.id.tvMyRankBadge)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        imageview1.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = rootLeaderboard
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
            rootView.requestApplyInsets()
        }

        applyFonts()
        loadUserData()
        applyTheme()
        fetchLiveLeaderboard()
    }

    private fun fetchLiveLeaderboard() {
        val userId = d_.getString("user_id", "") ?: (d_.getString("account_id", "") ?: "")
        
        // Show blurred frosted loading overlay
        BlurLoadingOverlay.show(this@LeaderboardActivity, "Fetching network rankings...", rootLeaderboard)

        lifecycleScope.launch {
            val repo = com.skybridg.linexware.app.repository.SkybridgeRepository(applicationContext)
            val result = repo.getGlobalLeaderboard(userId)
            
            runOnUiThread {
                BlurLoadingOverlay.dismiss(this@LeaderboardActivity)
            }

            result.onSuccess { data ->
                if (data != null) {
                    runOnUiThread {
                        updateLeaderboardUI(data)
                    }
                }
            }.onFailure {
                runOnUiThread {
                    showEmptyLeaderboard("No rankings recorded yet for this season")
                }
            }
        }
    }

    private fun showEmptyLeaderboard(message: String) {
        tvNameRank1.text = "---"
        tvScoreRank1.text = "0.000 SB"
        tvNameRank2.text = "---"
        tvScoreRank2.text = "0.000 SB"
        tvNameRank3.text = "---"
        tvScoreRank3.text = "0.000 SB"

        containerLeaderboardList.removeAllViews()
        val density = resources.displayMetrics.density
        val emptyTv = TextView(this@LeaderboardActivity).apply {
            text = message
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding((16 * density).toInt(), (32 * density).toInt(), (16 * density).toInt(), (32 * density).toInt())
            setTextColor(if (isDarkMode) Color.parseColor("#757575") else Color.parseColor("#9E9E9E"))
        }
        containerLeaderboardList.addView(emptyTv)
    }

    private fun updateLeaderboardUI(data: com.skybridg.linexware.app.network.LeaderboardData) {
        val list = data.leaderboard
        containerLeaderboardList.removeAllViews()

        if (list.isEmpty()) {
            showEmptyLeaderboard("No rankings recorded yet for this season")
            return
        }

        // Rank 1 Podium
        val r1 = list.getOrNull(0)
        if (r1 != null) {
            tvNameRank1.text = r1.name.ifEmpty { "Top Miner" }
            tvScoreRank1.text = formatScore(r1.score, r1.minedAmount)
            val av1 = r1.avatar.ifEmpty { r1.avatarUrl }
            if (av1.isNotEmpty()) {
                ImageLoader.load(av1, ivAvatar1, R.drawable.icc_1)
            } else {
                ivAvatar1.setImageResource(R.drawable.icc_1)
            }
        } else {
            tvNameRank1.text = "---"
            tvScoreRank1.text = "0.000 SB"
        }

        // Rank 2 Podium
        val r2 = list.getOrNull(1)
        if (r2 != null) {
            tvNameRank2.text = r2.name.ifEmpty { "Miner #2" }
            tvScoreRank2.text = formatScore(r2.score, r2.minedAmount)
            val av2 = r2.avatar.ifEmpty { r2.avatarUrl }
            if (av2.isNotEmpty()) {
                ImageLoader.load(av2, ivAvatar2, R.drawable.icc_2)
            } else {
                ivAvatar2.setImageResource(R.drawable.icc_2)
            }
        } else {
            tvNameRank2.text = "---"
            tvScoreRank2.text = "0.000 SB"
        }

        // Rank 3 Podium
        val r3 = list.getOrNull(2)
        if (r3 != null) {
            tvNameRank3.text = r3.name.ifEmpty { "Miner #3" }
            tvScoreRank3.text = formatScore(r3.score, r3.minedAmount)
            val av3 = r3.avatar.ifEmpty { r3.avatarUrl }
            if (av3.isNotEmpty()) {
                ImageLoader.load(av3, ivAvatar3, R.drawable.icon_1)
            } else {
                ivAvatar3.setImageResource(R.drawable.icon_1)
            }
        } else {
            tvNameRank3.text = "---"
            tvScoreRank3.text = "0.000 SB"
        }

        // Current User Sticky Card
        data.myRank?.let { my ->
            tvMyRankBadge.text = "#${my.rank}"
            tvMyScore.text = formatScore(my.score, my.minedAmount)
            if (my.name.isNotEmpty()) tvMyLabel.text = my.name
            val myAv = my.avatar.ifEmpty { my.avatarUrl }
            if (myAv.isNotEmpty()) {
                ImageLoader.load(myAv, ivMyAvatar, R.drawable.icc_2)
            }
        }

        // Rest of the ranks (#4+)
        if (list.size > 3) {
            populateDynamicRankings(list.drop(3))
        } else {
            val density = resources.displayMetrics.density
            val emptyTv = TextView(this).apply {
                text = "Keep mining to climb up the global network leaderboard!"
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding((16 * density).toInt(), (24 * density).toInt(), (16 * density).toInt(), (24 * density).toInt())
                setTextColor(if (isDarkMode) Color.parseColor("#757575") else Color.parseColor("#9E9E9E"))
            }
            containerLeaderboardList.addView(emptyTv)
        }
    }

    private fun formatScore(scoreStr: String, minedAmount: Double): String {
        return if (scoreStr.isNotBlank() && scoreStr.contains("SB")) {
            scoreStr
        } else {
            String.format(java.util.Locale.US, "%.3f SB", minedAmount)
        }
    }

    private fun populateDynamicRankings(items: List<com.skybridg.linexware.app.network.LeaderboardRankItem>) {
        containerLeaderboardList.removeAllViews()
        val density = resources.displayMetrics.density
        val fontB = try { Typeface.createFromAsset(assets, "fonts/font_b.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontSb = try { Typeface.createFromAsset(assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        for (item in items) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = (12 * density).toInt()
                }
                val padH = (16 * density).toInt()
                val padV = (14 * density).toInt()
                setPadding(padH, padV, padH, padV)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 20 * density
                    setColor(if (isDarkMode) Color.parseColor("#151515") else Color.parseColor("#F5F5F5"))
                    setStroke((1 * density).toInt(), if (isDarkMode) Color.parseColor("#262626") else Color.parseColor("#E5E5E5"))
                }
            }

            // Real Google Avatar or Fallback
            val avatarIv = ImageView(this).apply {
                val size = (46 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    rightMargin = (14 * density).toInt()
                }
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#2563EB"))
                }
                clipToOutline = true
            }

            val avUrl = item.avatar.ifEmpty { item.avatarUrl }
            if (avUrl.isNotEmpty()) {
                ImageLoader.load(avUrl, avatarIv, R.drawable.icc_2)
            } else {
                avatarIv.setImageResource(R.drawable.icc_2)
            }
            card.addView(avatarIv)

            val infoLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val tvName = TextView(this).apply {
                text = item.name.ifEmpty { "Miner #${item.rank}" }
                textSize = 15f
                typeface = fontSb
                setTextColor(if (isDarkMode) Color.WHITE else Color.BLACK)
            }
            infoLayout.addView(tvName)

            val tvSub = TextView(this).apply {
                text = if (item.subtitle.isNotEmpty()) item.subtitle else "#${item.rank} Overall"
                textSize = 12f
                typeface = fontR
                setTextColor(if (isDarkMode) Color.parseColor("#9E9E9E") else Color.parseColor("#757575"))
                setPadding(0, (2 * density).toInt(), 0, 0)
            }
            infoLayout.addView(tvSub)
            card.addView(infoLayout)

            val tvScore = TextView(this).apply {
                text = formatScore(item.score, item.minedAmount)
                textSize = 14f
                typeface = fontB
                gravity = Gravity.END
                setTextColor(if (isDarkMode) Color.parseColor("#9E9E9E") else Color.parseColor("#757575"))
            }
            card.addView(tvScore)

            containerLeaderboardList.addView(card)
        }
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")

            textview2.typeface = fontB
            tvNameRank1.typeface = fontB
            tvScoreRank1.typeface = fontSb
            badgeRank1.typeface = fontB

            tvNameRank2.typeface = fontB
            tvScoreRank2.typeface = fontSb
            badgeRank2.typeface = fontB

            tvNameRank3.typeface = fontB
            tvScoreRank3.typeface = fontSb
            badgeRank3.typeface = fontB

            tvSectionTitle.typeface = fontB
            tvMyLabel.typeface = fontB
            tvMyScore.typeface = fontSb
            tvMyRankBadge.typeface = fontB
        } catch (ignored: Exception) {}
    }

    private fun loadUserData() {
        val savedEmail = d_.getString("email", "") ?: ""
        var savedBalance = "0.000"

        val myAvatarUrl = d_.getString("profile_image", "") ?: (d_.getString("profile", "") ?: "")
        if (myAvatarUrl.isNotEmpty()) {
            ImageLoader.load(myAvatarUrl, ivMyAvatar, R.drawable.icc_2)
        } else {
            ivMyAvatar.setImageResource(R.drawable.icc_2)
        }

        if (d_.contains("backup")) {
            try {
                val type = object : TypeToken<HashMap<String, Any>>() {}.type
                val bData: HashMap<String, Any> = Gson().fromJson(d_.getString("backup", "{}"), type)
                savedBalance = bData["balance"]?.toString() ?: "0.000"
            } catch (e: Exception) {}
        }

        if (d_.contains("user")) {
            try {
                val type = object : TypeToken<HashMap<String, Any>>() {}.type
                val data: HashMap<String, Any> = Gson().fromJson(d_.getString("user", "{}"), type)
                val fName = data["first_name"]?.toString() ?: ""
                val lName = data["last_name"]?.toString() ?: ""
                val name = data["name"]?.toString() ?: ""
                val fullName = if (fName.isNotEmpty() && lName.isNotEmpty()) "$fName $lName" else (if (name.isNotEmpty()) name else "You")
                tvMyLabel.text = fullName
            } catch (e: Exception) {
                tvMyLabel.text = "You"
            }
        } else {
            val email = if (savedEmail.isNotEmpty()) savedEmail else "skybridgenetwork000@gmail.com"
            val prefix = email.substringBefore("@")
            val cleanName = prefix.replace(Regex("[0-9_.]"), " ").trim().split(Regex("\\s+"))
                .filter { it.isNotEmpty() }
                .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            tvMyLabel.text = if (cleanName.isNotEmpty()) cleanName else "You"
        }

        val balDouble = savedBalance.toDoubleOrNull() ?: 0.0
        tvMyScore.text = String.format(java.util.Locale.US, "%.3f SB", balDouble)
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = resources.displayMetrics.density

        // Setup podium avatar borders
        ivAvatar1.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke((3 * density).toInt(), Color.parseColor("#FFD700"))
        }
        badgeRank1.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#FFD700"))
        }

        ivAvatar2.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke((2.5f * density).toInt(), Color.parseColor("#C0C0C0"))
        }
        badgeRank2.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#C0C0C0"))
        }

        ivAvatar3.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke((2.5f * density).toInt(), Color.parseColor("#CD7F32"))
        }
        badgeRank3.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#CD7F32"))
        }

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = Color.BLACK
            window.navigationBarColor = Color.BLACK
            rootLeaderboard.setBackgroundColor(Color.BLACK)

            imageview1.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#212121"))
            }
            imageview1.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            textview2.setTextColor(Color.WHITE)

            tvNameRank1.setTextColor(Color.WHITE)
            tvNameRank2.setTextColor(Color.WHITE)
            tvNameRank3.setTextColor(Color.WHITE)
            tvSectionTitle.setTextColor(Color.WHITE)

            cardStickyYou.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#1C1C1E"))
                setStroke((1 * density).toInt(), Color.parseColor("#38383A"))
            }
            tvMyLabel.setTextColor(Color.WHITE)
            tvMyScore.setTextColor(Color.parseColor("#9E9E9E"))
            tvMyRankBadge.setTextColor(Color.WHITE)
            tvMyRankBadge.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14 * density
                setColor(Color.parseColor("#2C2C2E"))
            }
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = Color.WHITE
            window.navigationBarColor = Color.WHITE
            rootLeaderboard.setBackgroundColor(Color.WHITE)

            imageview1.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18 * density
                setColor(Color.parseColor("#F5F5F5"))
            }
            imageview1.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
            textview2.setTextColor(Color.BLACK)

            tvNameRank1.setTextColor(Color.BLACK)
            tvNameRank2.setTextColor(Color.BLACK)
            tvNameRank3.setTextColor(Color.BLACK)
            tvSectionTitle.setTextColor(Color.BLACK)

            cardStickyYou.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#FFFFFF"))
                setStroke((1 * density).toInt(), Color.parseColor("#E0E0E0"))
            }
            tvMyLabel.setTextColor(Color.BLACK)
            tvMyScore.setTextColor(Color.parseColor("#757575"))
            tvMyRankBadge.setTextColor(Color.BLACK)
            tvMyRankBadge.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14 * density
                setColor(Color.parseColor("#F0F0F0"))
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
