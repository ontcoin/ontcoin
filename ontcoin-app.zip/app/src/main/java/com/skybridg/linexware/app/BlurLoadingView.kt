package com.skybridg.linexware.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable

/**
 * Universal, theme-aware, frosted glass blur loading overlay component.
 * Uses Lottie animation (loading_light.json on dark mode, loading_dark.json on light mode).
 * Features RenderEffect backdrop blur on Android 12+ and high-contrast frosted translucent card.
 */
class BlurLoadingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val backdropView: View
    private val cardContainer: LinearLayout
    private val lottieAnimationView: LottieAnimationView
    private val tvMessage: TextView
    private val tvSub: TextView
    private var blurredTarget: View? = null

    init {
        isClickable = true
        isFocusable = true
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)

        val density = context.resources.displayMetrics.density

        backdropView = View(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        }
        addView(backdropView)

        cardContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val lp = LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
            }
            layoutParams = lp
            val padH = (32 * density).toInt()
            val padV = (28 * density).toInt()
            setPadding(padH, padV, padH, padV)
            minimumWidth = (220 * density).toInt()
        }

        lottieAnimationView = LottieAnimationView(context).apply {
            val size = (56 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
            repeatCount = LottieDrawable.INFINITE
        }
        cardContainer.addView(lottieAnimationView)

        val fontB = try { Typeface.createFromAsset(context.assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(context.assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        tvMessage = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (16 * density).toInt()
                gravity = Gravity.CENTER_HORIZONTAL
            }
            text = "Loading..."
            textSize = 14f
            typeface = fontB
            gravity = Gravity.CENTER
        }
        cardContainer.addView(tvMessage)

        tvSub = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (4 * density).toInt()
                gravity = Gravity.CENTER_HORIZONTAL
            }
            text = "Skybridge Network"
            textSize = 11f
            typeface = fontR
            gravity = Gravity.CENTER
        }
        cardContainer.addView(tvSub)

        addView(cardContainer)
        applyTheme(LottieThemeHelper.isDarkTheme(context))
    }

    fun applyTheme(isDark: Boolean) {
        val density = context.resources.displayMetrics.density

        // Apply theme-aware Lottie asset
        val assetName = if (isDark) "loading_light.json" else "loading_dark.json"
        try {
            lottieAnimationView.setAnimation(assetName)
            lottieAnimationView.playAnimation()
        } catch (e: Exception) {
            // Fallback
        }

        if (isDark) {
            // Dark Frosted Acrylic
            backdropView.setBackgroundColor(Color.parseColor("#CC080B11"))
            cardContainer.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#F0111827"))
                setStroke((1 * density).toInt(), Color.parseColor("#3338BDF8"))
            }
            tvMessage.setTextColor(Color.WHITE)
            tvSub.setTextColor(Color.parseColor("#94A3B8"))
        } else {
            // Light Frosted Acrylic
            backdropView.setBackgroundColor(Color.parseColor("#CCF1F5F9"))
            cardContainer.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24 * density
                setColor(Color.parseColor("#FAFFFFFF"))
                setStroke((1 * density).toInt(), Color.parseColor("#20000000"))
            }
            tvMessage.setTextColor(Color.parseColor("#0F172A"))
            tvSub.setTextColor(Color.parseColor("#64748B"))
        }
    }

    fun setMessage(message: String) {
        tvMessage.text = message
    }

    fun setBlurTarget(view: View?) {
        blurredTarget = view
        applyRenderBlur(view, true)
    }

    private fun applyRenderBlur(view: View?, enable: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && view != null) {
            try {
                if (enable) {
                    val blur = RenderEffect.createBlurEffect(24f, 24f, Shader.TileMode.CLAMP)
                    view.setRenderEffect(blur)
                } else {
                    view.setRenderEffect(null)
                }
            } catch (e: Exception) {
                // Graceful fallback
            }
        }
    }

    fun showSmooth() {
        alpha = 0f
        visibility = View.VISIBLE
        lottieAnimationView.playAnimation()
        animate()
            .alpha(1f)
            .setDuration(200)
            .setListener(null)
            .start()
    }

    fun dismiss(onDismissed: (() -> Unit)? = null) {
        applyRenderBlur(blurredTarget, false)
        blurredTarget = null
        animate()
            .alpha(0f)
            .setDuration(180)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    lottieAnimationView.cancelAnimation()
                    visibility = View.GONE
                    val parentGroup = parent as? ViewGroup
                    parentGroup?.removeView(this@BlurLoadingView)
                    onDismissed?.invoke()
                }
            })
            .start()
    }

    companion object {
        private const val TAG_OVERLAY = "SKYBRIDGE_BLUR_LOADING_OVERLAY"

        @JvmStatic
        fun show(activity: Activity, message: String = "Loading...", targetToBlur: View? = null): BlurLoadingView {
            val decorView = activity.window?.decorView as? ViewGroup
            val existing = decorView?.findViewWithTag<BlurLoadingView>(TAG_OVERLAY)
            if (existing != null) {
                existing.setMessage(message)
                existing.showSmooth()
                return existing
            }

            val overlay = BlurLoadingView(activity).apply {
                tag = TAG_OVERLAY
                setMessage(message)
                elevation = 999f
                setBlurTarget(targetToBlur ?: (decorView?.getChildAt(0)))
            }

            decorView?.addView(
                overlay,
                LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            )
            overlay.showSmooth()
            return overlay
        }

        @JvmStatic
        fun dismiss(activity: Activity, onDismissed: (() -> Unit)? = null) {
            val decorView = activity.window?.decorView as? ViewGroup
            val existing = decorView?.findViewWithTag<BlurLoadingView>(TAG_OVERLAY)
            if (existing != null) {
                existing.dismiss(onDismissed)
            } else {
                onDismissed?.invoke()
            }
        }
    }
}
