package com.skybridg.linexware.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.util.HashMap

/**
 * Profile Screen:
 * STRICT REQUIREMENT: No avatar or profile picture displayed.
 * Displays user credentials in clean, distinct 4-card columns:
 * Column 1: Full Name
 * Column 2: Email Address
 * Column 3: Account ID (with one-tap copy button)
 * Column 4: KYC Status -> Styled status pill: "Unverified (Coming Soon)"
 * All details loaded in a single API call on launch.
 */
class ProfileActivity : AppCompatActivity() {

    private var accountId = ""

    private lateinit var linear1: LinearLayout
    private lateinit var linear2: LinearLayout
    private lateinit var vscroll1: ScrollView
    private lateinit var imageview1: ImageView
    private lateinit var textview2: TextView

    private lateinit var cardFullName: LinearLayout
    private lateinit var lblFullName: TextView
    private lateinit var tvFullName: TextView

    private lateinit var cardEmail: LinearLayout
    private lateinit var lblEmail: TextView
    private lateinit var tvEmail: TextView

    private lateinit var cardAccountId: LinearLayout
    private lateinit var lblAccountId: TextView
    private lateinit var tvAccountId: TextView
    private lateinit var ivCopy: ImageView

    private lateinit var cardKyc: LinearLayout
    private lateinit var lblKyc: TextView
    private lateinit var tvKycStatus: TextView

    private lateinit var cardSignOut: LinearLayout

    private lateinit var d_: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        linear1 = findViewById(R.id.linear1)
        linear2 = findViewById(R.id.linear2)
        vscroll1 = findViewById(R.id.vscroll1)
        imageview1 = findViewById(R.id.imageview1)
        textview2 = findViewById(R.id.textview2)

        cardFullName = findViewById(R.id.card_full_name)
        lblFullName = findViewById(R.id.lbl_full_name)
        tvFullName = findViewById(R.id.textview5)

        cardEmail = findViewById(R.id.card_email)
        lblEmail = findViewById(R.id.lbl_email)
        tvEmail = findViewById(R.id.textview9)

        cardAccountId = findViewById(R.id.card_account_id)
        lblAccountId = findViewById(R.id.lbl_account_id)
        tvAccountId = findViewById(R.id.textview13)
        ivCopy = findViewById(R.id.imageview2)

        cardKyc = findViewById(R.id.card_kyc)
        lblKyc = findViewById(R.id.lbl_kyc)
        tvKycStatus = findViewById(R.id.textview11)

        cardSignOut = findViewById(R.id.card_sign_out)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        imageview1.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        cardSignOut.setOnClickListener {
            LogoutBottomSheetHelper.show(this@ProfileActivity)
        }

        ivCopy.setOnClickListener {
            if (accountId.isNotEmpty()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Account ID", accountId)
                clipboard.setPrimaryClip(clip)
                CustomToast.showSuccess(this@ProfileActivity, "Copied", "Account ID copied to clipboard!")
            }
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = linear1
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        applyFonts()
        applyTheme()
        loadLocalProfile()
        fetchLiveProfile()
    }

    private fun applyFonts() {
        val fontB = try { Typeface.createFromAsset(assets, "fonts/font_b.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontSb = try { Typeface.createFromAsset(assets, "fonts/font_sb.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val fontR = try { Typeface.createFromAsset(assets, "fonts/font.ttf") } catch (e: Exception) { Typeface.DEFAULT }

        textview2.typeface = fontB
        tvFullName.typeface = fontSb
        tvEmail.typeface = fontR
        tvAccountId.typeface = fontR
        tvKycStatus.typeface = fontSb

        lblFullName.typeface = fontR
        lblEmail.typeface = fontR
        lblAccountId.typeface = fontR
        lblKyc.typeface = fontR
    }

    private fun applyTheme() {
        val isDark = if (d_.contains("theme")) {
            d_.getString("theme", "") == "dark"
        } else {
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = resources.displayMetrics.density

        if (isDark) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = Color.BLACK
            window.navigationBarColor = Color.BLACK
            linear1.setBackgroundColor(Color.BLACK)
            textview2.setTextColor(Color.WHITE)
            imageview1.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            imageview1.background = roundedDrawable(16, Color.parseColor("#212121"))

            val cardBg = Color.parseColor("#151515")
            val cardStroke = Color.parseColor("#262626")
            setCardStyle(cardFullName, cardBg, cardStroke, density)
            setCardStyle(cardEmail, cardBg, cardStroke, density)
            setCardStyle(cardAccountId, cardBg, cardStroke, density)
            setCardStyle(cardKyc, cardBg, cardStroke, density)
            setCardStyle(cardSignOut, cardBg, cardStroke, density)

            val lblColor = Color.parseColor("#757575")
            lblFullName.setTextColor(lblColor)
            lblEmail.setTextColor(lblColor)
            lblAccountId.setTextColor(lblColor)
            lblKyc.setTextColor(lblColor)

            tvFullName.setTextColor(Color.WHITE)
            tvEmail.setTextColor(Color.parseColor("#CCCCCC"))
            tvAccountId.setTextColor(Color.parseColor("#CCCCCC"))
            ivCopy.setColorFilter(Color.parseColor("#3B82F6"), PorterDuff.Mode.SRC_IN)
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = Color.WHITE
            window.navigationBarColor = Color.WHITE
            linear1.setBackgroundColor(Color.WHITE)
            textview2.setTextColor(Color.BLACK)
            imageview1.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
            imageview1.background = roundedDrawable(16, Color.parseColor("#EEEEEE"))

            val cardBg = Color.parseColor("#F8F9FA")
            val cardStroke = Color.parseColor("#E5E7EB")
            setCardStyle(cardFullName, cardBg, cardStroke, density)
            setCardStyle(cardEmail, cardBg, cardStroke, density)
            setCardStyle(cardAccountId, cardBg, cardStroke, density)
            setCardStyle(cardKyc, cardBg, cardStroke, density)
            setCardStyle(cardSignOut, cardBg, cardStroke, density)

            val lblColor = Color.parseColor("#9E9E9E")
            lblFullName.setTextColor(lblColor)
            lblEmail.setTextColor(lblColor)
            lblAccountId.setTextColor(lblColor)
            lblKyc.setTextColor(lblColor)

            tvFullName.setTextColor(Color.BLACK)
            tvEmail.setTextColor(Color.parseColor("#374151"))
            tvAccountId.setTextColor(Color.parseColor("#374151"))
            ivCopy.setColorFilter(Color.parseColor("#2563EB"), PorterDuff.Mode.SRC_IN)
        }

        updateKycPill()
    }

    private fun setCardStyle(card: LinearLayout, bgColor: Int, strokeColor: Int, density: Float) {
        card.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 18 * density
            setColor(bgColor)
            setStroke((1 * density).toInt(), strokeColor)
        }
    }

    private fun roundedDrawable(radiusDp: Int, color: Int): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            cornerRadius = radiusDp * density
            setColor(color)
        }
    }

    private fun updateKycPill() {
        val density = resources.displayMetrics.density
        tvKycStatus.text = "Unverified (Coming Soon)"
        tvKycStatus.setTextColor(Color.parseColor("#D97706")) // Warm Amber Gold
        tvKycStatus.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 12 * density
            setColor(Color.parseColor("#1FF59E0B")) // Translucent amber pill
            setStroke((1 * density).toInt(), Color.parseColor("#4DF59E0B"))
        }
    }

    private fun loadLocalProfile() {
        val savedEmail = d_.getString("email", "") ?: ""
        val savedAccountId = d_.getString("account_id", "") ?: ""

        if (d_.contains("user")) {
            try {
                val type = object : TypeToken<HashMap<String, Any>>() {}.type
                val map: HashMap<String, Any> = Gson().fromJson(d_.getString("user", "{}"), type)
                val fName = map["first_name"]?.toString() ?: ""
                val lName = map["last_name"]?.toString() ?: ""
                val rawName = map["name"]?.toString() ?: ""
                val fullName = when {
                    fName.isNotEmpty() && lName.isNotEmpty() -> "$fName $lName"
                    rawName.isNotEmpty() -> rawName
                    else -> "Skybridge User"
                }
                tvFullName.text = fullName
                tvEmail.text = map["email"]?.toString() ?: savedEmail
                accountId = map["account_id"]?.toString() ?: savedAccountId
                tvAccountId.text = accountId
                return
            } catch (e: Exception) {}
        }

        if (savedEmail.isNotEmpty()) {
            tvEmail.text = savedEmail
            val prefix = savedEmail.substringBefore("@")
            val clean = prefix.replace(Regex("[0-9_.]"), " ").trim().split(Regex("\\s+"))
                .filter { it.isNotEmpty() }
                .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            tvFullName.text = if (clean.isNotEmpty()) clean else "Skybridge User"
            accountId = if (savedAccountId.isNotEmpty()) savedAccountId else prefix.replace(".", "_")
            tvAccountId.text = accountId
        }
    }

    private fun fetchLiveProfile() {
        val authKey = d_.getString("user_id", "") ?: (d_.getString("account_id", "") ?: (d_.getString("email", "") ?: ""))
        if (authKey.isEmpty()) return

        BlurLoadingOverlay.show(this@ProfileActivity, "Loading profile...", linear1)

        SkybridgeApiClient.fetchUser(authKey, object : SkybridgeApiClient.ApiCallback {
            override fun onSuccess(response: JSONObject) {
                val userData = response.optJSONObject("data") ?: return
                val serverName = userData.optString("name", "")
                val serverEmail = userData.optString("email", "")
                val serverAccId = userData.optString("account_id", "")

                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@ProfileActivity)
                    if (serverName.isNotEmpty()) {
                        tvFullName.text = serverName
                    }
                    if (serverEmail.isNotEmpty()) {
                        tvEmail.text = serverEmail
                    }
                    if (serverAccId.isNotEmpty()) {
                        accountId = serverAccId
                        tvAccountId.text = accountId
                        d_.edit().putString("account_id", serverAccId).apply()
                    }
                }
            }

            override fun onError(errorMessage: String) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@ProfileActivity)
                }
            }
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
