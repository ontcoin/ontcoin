package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var rootLogin: LinearLayout
    private lateinit var ivBack: ImageView
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var lblEmail: TextView
    private lateinit var etEmail: EditText
    private lateinit var lblPassword: TextView
    private lateinit var etPassword: EditText
    private lateinit var ivPasswordToggle: ImageView
    private lateinit var tvForgotPassword: TextView
    private lateinit var btnLoginSubmit: Button
    private lateinit var tvNoAccountText: TextView
    private lateinit var tvRegisterLink: TextView

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        rootLogin = findViewById(R.id.rootLogin)
        ivBack = findViewById(R.id.ivBack)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvSubtitle = findViewById(R.id.tvSubtitle)
        lblEmail = findViewById(R.id.lblEmail)
        etEmail = findViewById(R.id.etEmail)
        lblPassword = findViewById(R.id.lblPassword)
        etPassword = findViewById(R.id.etPassword)
        ivPasswordToggle = findViewById(R.id.ivPasswordToggle)
        tvForgotPassword = findViewById(R.id.tvForgotPassword)
        btnLoginSubmit = findViewById(R.id.btnLoginSubmit)
        tvNoAccountText = findViewById(R.id.tvNoAccountText)
        tvRegisterLink = findViewById(R.id.tvRegisterLink)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        ivBack.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        ivPasswordToggle.setOnClickListener {
            togglePasswordVisibility()
        }

        tvForgotPassword.setOnClickListener {
            val email = etEmail.text.toString().trim()
            ForgotPasswordBottomSheetHelper.show(this@LoginActivity, email) { updatedEmail ->
                etEmail.setText(updatedEmail)
                etPassword.setText("")
                etPassword.requestFocus()
            }
        }

        btnLoginSubmit.setOnClickListener {
            handleEmailLogin()
        }

        tvRegisterLink.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = rootLogin
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        applyFonts()
        applyTheme()
    }

    private fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
        if (isPasswordVisible) {
            etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            ivPasswordToggle.setImageResource(R.drawable.icon_visibility_off_round)
        } else {
            etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            ivPasswordToggle.setImageResource(R.drawable.icon_visibility_round)
        }
        etPassword.setSelection(etPassword.text.length)
    }

    private fun handleEmailLogin() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            CustomToast.showError(this, "Validation", "Please enter a valid email address.")
            return
        }
        if (password.isEmpty()) {
            CustomToast.showError(this, "Validation", "Please enter your password.")
            return
        }

        BlurLoadingOverlay.show(this, "Signing into Skybridge...", rootLogin)
        SkybridgeApiClient.emailLogin(email, password, callback = object : SkybridgeApiClient.ApiCallback {
            override fun onSuccess(response: JSONObject) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@LoginActivity)
                    val data = response.optJSONObject("data") ?: JSONObject()
                    persistUserSession(data)
                    CustomToast.showSuccess(this@LoginActivity, "Welcome Back!", "Signed in successfully.")
                    val intent = Intent(applicationContext, DashboardActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        putExtra("show_notification_dialog", true)
                    }
                    startActivity(intent)
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }
            }

            override fun onError(errorMessage: String) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@LoginActivity)
                    CustomToast.showError(this@LoginActivity, "Sign In Failed", errorMessage)
                }
            }
        })
    }

    private fun persistUserSession(data: JSONObject) {
        val uid = data.optString("user_id", "")
        val accId = data.optString("account_id", uid)
        val email = data.optString("email", "")
        val name = data.optString("name", data.optString("display_name", ""))
        val refCode = data.optString("referral_code", "")
        val token = data.optString("auth_token", "")
        val pic = data.optString("profile_image", "")

        val editor = d_.edit()
        if (uid.isNotEmpty()) editor.putString("user_id", uid)
        if (accId.isNotEmpty()) editor.putString("account_id", accId)
        if (email.isNotEmpty()) {
            editor.putString("email", email)
            editor.putString("authentication", email)
        }
        if (name.isNotEmpty()) editor.putString("display_name", name)
        if (refCode.isNotEmpty()) editor.putString("referral_code", refCode)
        if (token.isNotEmpty()) editor.putString("auth_token", token)
        if (pic.isNotEmpty()) editor.putString("profile_image", pic)

        editor.putString("user", data.toString())
        editor.apply()

        SkybridgeNotificationScheduler.subscribeUserTopics(this@LoginActivity)
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
            val fontR = Typeface.createFromAsset(assets, "fonts/font.ttf")

            tvHeaderTitle.typeface = fontB
            tvSubtitle.typeface = fontR
            lblEmail.typeface = fontSb
            etEmail.typeface = fontR
            lblPassword.typeface = fontSb
            etPassword.typeface = fontR
            tvForgotPassword.typeface = fontSb
            btnLoginSubmit.typeface = fontB
            tvNoAccountText.typeface = fontR
            tvRegisterLink.typeface = fontB
        } catch (ignored: Exception) {}
    }

    private fun roundedDrawable(radiusDp: Int, color: Long, strokeColor: Long? = null): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            cornerRadius = radiusDp * density
            setColor(color.toInt())
            if (strokeColor != null) {
                setStroke((1 * density).toInt(), strokeColor.toInt())
            }
        }
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val density = resources.displayMetrics.density
        val inputBg = if (isDarkMode) 0xFF212121L else 0xFFEEEEEEL
        val inputStroke = if (isDarkMode) 0xFF333333L else 0xFFE0E0E0L
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF757575.toInt()
        val btnBg = if (isDarkMode) 0xFFFFFFFFL else 0xFF000000L
        val btnTextColor = if (isDarkMode) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = 0xFF000000.toInt()
            window.navigationBarColor = 0xFF000000.toInt()
            rootLogin.setBackgroundColor(0xFF000000.toInt())
            ivBack.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFF212121L)
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = 0xFFFFFFFF.toInt()
            window.navigationBarColor = 0xFFFFFFFF.toInt()
            rootLogin.setBackgroundColor(0xFFFFFFFF.toInt())
            ivBack.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFFEEEEEEL)
        }

        tvHeaderTitle.setTextColor(textPrimary)
        tvSubtitle.setTextColor(textSecondary)
        lblEmail.setTextColor(textSecondary)
        lblPassword.setTextColor(textSecondary)
        tvForgotPassword.setTextColor(textPrimary)
        tvNoAccountText.setTextColor(textSecondary)
        tvRegisterLink.setTextColor(textPrimary)

        etEmail.background = roundedDrawable(14, inputBg, inputStroke)
        etEmail.setTextColor(textPrimary)
        etEmail.setHintTextColor(textSecondary)

        etPassword.background = roundedDrawable(14, inputBg, inputStroke)
        etPassword.setTextColor(textPrimary)
        etPassword.setHintTextColor(textSecondary)

        ivPasswordToggle.setColorFilter(textSecondary, PorterDuff.Mode.SRC_IN)

        btnLoginSubmit.background = roundedDrawable(14, btnBg)
        btnLoginSubmit.setTextColor(btnTextColor)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
