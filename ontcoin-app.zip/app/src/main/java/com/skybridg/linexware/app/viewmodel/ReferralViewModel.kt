package com.skybridg.linexware.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.skybridg.linexware.app.network.ReferralClaimData
import com.skybridg.linexware.app.network.ReferralDashboardData
import com.skybridg.linexware.app.repository.SkybridgeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ReferralUiState {
    object Idle : ReferralUiState()
    object Loading : ReferralUiState()
    data class Loaded(val data: ReferralDashboardData) : ReferralUiState()
    data class Claimed(val claim: ReferralClaimData) : ReferralUiState()
    data class Error(val message: String) : ReferralUiState()
}

class ReferralViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SkybridgeRepository(application)

    private val _referralState = MutableStateFlow<ReferralUiState>(ReferralUiState.Idle)
    val referralState: StateFlow<ReferralUiState> = _referralState.asStateFlow()

    fun loadReferralDashboard(userId: String) {
        if (userId.isEmpty()) return
        viewModelScope.launch {
            _referralState.value = ReferralUiState.Loading
            val result = repository.getReferralDashboard(userId)
            result.onSuccess { data ->
                if (data != null) {
                    _referralState.value = ReferralUiState.Loaded(data)
                } else {
                    _referralState.value = ReferralUiState.Error("No referral data returned")
                }
            }.onFailure { err ->
                _referralState.value = ReferralUiState.Error(err.localizedMessage ?: "Failed loading referral dashboard")
            }
        }
    }

    fun claimCommission(userId: String) {
        if (userId.isEmpty()) return
        viewModelScope.launch {
            _referralState.value = ReferralUiState.Loading
            val result = repository.claimReferralCommission(userId)
            result.onSuccess { claim ->
                if (claim != null) {
                    _referralState.value = ReferralUiState.Claimed(claim)
                } else {
                    _referralState.value = ReferralUiState.Error("No commission claim data returned")
                }
            }.onFailure { err ->
                _referralState.value = ReferralUiState.Error(err.localizedMessage ?: "Failed claiming commission")
            }
        }
    }
}
