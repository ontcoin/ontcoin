package com.skybridg.linexware.app

import android.app.Activity
import android.view.View

/**
 * Convenience helper class for BlurLoadingOverlay.
 */
object BlurLoadingOverlay {
    @JvmStatic
    fun show(activity: Activity, message: String = "Loading...", blurTarget: View? = null): BlurLoadingView {
        return BlurLoadingView.show(activity, message, blurTarget)
    }

    @JvmStatic
    fun dismiss(activity: Activity, onDismissed: (() -> Unit)? = null) {
        BlurLoadingView.dismiss(activity, onDismissed)
    }
}
