package com.skybridg.linexware.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.skybridg.linexware.app.network.MiningClaimData
import com.skybridg.linexware.app.network.MiningSessionData
import com.skybridg.linexware.app.network.MiningStatusData
import com.skybridg.linexware.app.network.SystemStatusData
import com.skybridg.linexware.app.repository.SkybridgeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class MiningUiState {
    object Idle : MiningUiState()
    object Loading : MiningUiState()
    data class StatusLoaded(val status: MiningStatusData) : MiningUiState()
    data class MiningStarted(val session: MiningSessionData) : MiningUiState()
    data class MiningClaimed(val claim: MiningClaimData) : MiningUiState()
    data class Error(val message: String) : MiningUiState()
}

class MiningViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SkybridgeRepository(application)

    private val _miningState = MutableStateFlow<MiningUiState>(MiningUiState.Idle)
    val miningState: StateFlow<MiningUiState> = _miningState.asStateFlow()

    private val _systemStatus = MutableStateFlow<SystemStatusData?>(null)
    val systemStatus: StateFlow<SystemStatusData?> = _systemStatus.asStateFlow()

    fun checkSystemStatus() {
        viewModelScope.launch {
            val result = repository.getSystemStatus()
            result.onSuccess { status ->
                _systemStatus.value = status
            }
        }
    }

    fun loadMiningStatus(userId: String) {
        if (userId.isEmpty()) return
        viewModelScope.launch {
            _miningState.value = MiningUiState.Loading
            val result = repository.getMiningStatus(userId)
            result.onSuccess { data ->
                if (data != null) {
                    _miningState.value = MiningUiState.StatusLoaded(data)
                } else {
                    _miningState.value = MiningUiState.Error("No mining session data returned")
                }
            }.onFailure { err ->
                _miningState.value = MiningUiState.Error(err.localizedMessage ?: "Failed loading mining status")
            }
        }
    }

    fun startMining(userId: String, baseRate: String = "1.0") {
        if (userId.isEmpty()) return
        viewModelScope.launch {
            _miningState.value = MiningUiState.Loading
            val result = repository.startMining(userId, baseRate)
            result.onSuccess { session ->
                if (session != null) {
                    _miningState.value = MiningUiState.MiningStarted(session)
                } else {
                    _miningState.value = MiningUiState.Error("Unable to start mining session")
                }
            }.onFailure { err ->
                _miningState.value = MiningUiState.Error(err.localizedMessage ?: "Failed starting mining")
            }
        }
    }

    fun claimMining(userId: String) {
        if (userId.isEmpty()) return
        viewModelScope.launch {
            _miningState.value = MiningUiState.Loading
            val result = repository.claimMining(userId)
            result.onSuccess { claim ->
                if (claim != null) {
                    _miningState.value = MiningUiState.MiningClaimed(claim)
                } else {
                    _miningState.value = MiningUiState.Error("Unable to claim mining rewards")
                }
            }.onFailure { err ->
                _miningState.value = MiningUiState.Error(err.localizedMessage ?: "Failed claiming rewards")
            }
        }
    }
}
