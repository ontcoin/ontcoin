package com.skybridg.linexware.app

import android.app.Application
import com.skybridg.linexware.app.network.NetworkClient

class SketchApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NetworkClient.init(this)
        MyFirebaseMessagingService.initializeAndSubscribe(this)
        SkybridgeNotificationScheduler.init(this)
    }
}
