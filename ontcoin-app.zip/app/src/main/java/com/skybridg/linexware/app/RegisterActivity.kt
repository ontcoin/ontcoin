package com.skybridg.linexware.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    private lateinit var rootRegister: LinearLayout
    private lateinit var ivBack: ImageView
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var lblFirstName: TextView
    private lateinit var etFirstName: EditText
    private lateinit var lblLastName: TextView
    private lateinit var etLastName: EditText
    private lateinit var lblEmail: TextView
    private lateinit var etEmail: EditText
    private lateinit var lblPassword: TextView
    private lateinit var etPassword: EditText
    private lateinit var ivPasswordToggle: ImageView
    private lateinit var lblReferral: TextView
    private lateinit var etReferral: EditText
    private lateinit var btnRegisterSubmit: Button
    private lateinit var tvHasAccountText: TextView
    private lateinit var tvLoginLink: TextView

    private lateinit var d_: SharedPreferences
    private var isDarkMode = false
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        initialize(savedInstanceState)
        initializeLogic()
    }

    private fun initialize(savedInstanceState: Bundle?) {
        rootRegister = findViewById(R.id.rootRegister)
        ivBack = findViewById(R.id.ivBack)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvSubtitle = findViewById(R.id.tvSubtitle)
        lblFirstName = findViewById(R.id.lblFirstName)
        etFirstName = findViewById(R.id.etFirstName)
        lblLastName = findViewById(R.id.lblLastName)
        etLastName = findViewById(R.id.etLastName)
        lblEmail = findViewById(R.id.lblEmail)
        etEmail = findViewById(R.id.etEmail)
        lblPassword = findViewById(R.id.lblPassword)
        etPassword = findViewById(R.id.etPassword)
        ivPasswordToggle = findViewById(R.id.ivPasswordToggle)
        lblReferral = findViewById(R.id.lblReferral)
        etReferral = findViewById(R.id.etReferral)
        btnRegisterSubmit = findViewById(R.id.btnRegisterSubmit)
        tvHasAccountText = findViewById(R.id.tvHasAccountText)
        tvLoginLink = findViewById(R.id.tvLoginLink)

        d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE)

        ivBack.setOnClickListener {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        ivPasswordToggle.setOnClickListener {
            togglePasswordVisibility()
        }

        btnRegisterSubmit.setOnClickListener {
            handleRegisterInit()
        }

        tvLoginLink.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }

    private fun initializeLogic() {
        if (Build.VERSION.SDK_INT >= 30) {
            val rootView: View = rootRegister
            val originalLeft = rootView.paddingLeft
            val originalTop = rootView.paddingTop
            val originalRight = rootView.paddingRight
            val originalBottom = rootView.paddingBottom

            rootView.setOnApplyWindowInsetsListener { v, insets ->
                val statusBarInsets = insets.getInsets(WindowInsets.Type.statusBars())
                val navigationBarInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                val finalLeft = originalLeft + statusBarInsets.left
                val finalTop = originalTop + statusBarInsets.top
                val finalRight = originalRight + statusBarInsets.right
                val finalBottom = originalBottom + navigationBarInsets.bottom
                v.setPadding(finalLeft, finalTop, finalRight, finalBottom)
                insets
            }
        }

        applyFonts()
        applyTheme()
    }

    private fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
        if (isPasswordVisible) {
            etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            ivPasswordToggle.setImageResource(R.drawable.icon_visibility_off_round)
        } else {
            etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            ivPasswordToggle.setImageResource(R.drawable.icon_visibility_round)
        }
        etPassword.setSelection(etPassword.text.length)
    }

    private fun handleRegisterInit() {
        val fName = etFirstName.text.toString().trim()
        val lName = etLastName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()
        val referral = etReferral.text.toString().trim()

        if (fName.isEmpty() || lName.isEmpty()) {
            CustomToast.showError(this, "Validation", "Please enter your first and last name.")
            return
        }
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            CustomToast.showError(this, "Validation", "Please enter a valid email address.")
            return
        }
        if (password.length < 6) {
            CustomToast.showError(this, "Validation", "Password must be at least 6 characters.")
            return
        }

        BlurLoadingOverlay.show(this, "Sending verification code...", rootRegister)
        SkybridgeApiClient.emailRegisterInit(fName, lName, email, password, referral, object : SkybridgeApiClient.ApiCallback {
            override fun onSuccess(response: JSONObject) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@RegisterActivity)
                    CustomToast.showSuccess(this@RegisterActivity, "Code Sent", "We sent a 6-digit code to $email")
                    val intent = Intent(this@RegisterActivity, VerifyOtpActivity::class.java).apply {
                        putExtra("extra_email", email)
                        putExtra("extra_first_name", fName)
                        putExtra("extra_last_name", lName)
                        putExtra("extra_password", password)
                        putExtra("extra_referral", referral)
                    }
                    startActivity(intent)
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }

            override fun onError(errorMessage: String) {
                runOnUiThread {
                    BlurLoadingOverlay.dismiss(this@RegisterActivity)
                    CustomToast.showError(this@RegisterActivity, "Registration Failed", errorMessage)
                }
            }
        })
    }

    private fun applyFonts() {
        try {
            val fontB = Typeface.createFromAsset(assets, "fonts/font_b.ttf")
            val fontSb = Typeface.createFromAsset(assets, "fonts/font_sb.ttf")
            val fontR = Typeface.createFromAsset(assets, "fonts/font.ttf")

            tvHeaderTitle.typeface = fontB
            tvSubtitle.typeface = fontR
            lblFirstName.typeface = fontSb
            etFirstName.typeface = fontR
            lblLastName.typeface = fontSb
            etLastName.typeface = fontR
            lblEmail.typeface = fontSb
            etEmail.typeface = fontR
            lblPassword.typeface = fontSb
            etPassword.typeface = fontR
            lblReferral.typeface = fontSb
            etReferral.typeface = fontR
            btnRegisterSubmit.typeface = fontB
            tvHasAccountText.typeface = fontR
            tvLoginLink.typeface = fontB
        } catch (ignored: Exception) {}
    }

    private fun roundedDrawable(radiusDp: Int, color: Long, strokeColor: Long? = null): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            cornerRadius = radiusDp * density
            setColor(color.toInt())
            if (strokeColor != null) {
                setStroke((1 * density).toInt(), strokeColor.toInt())
            }
        }
    }

    private fun applyTheme() {
        if (d_.contains("theme")) {
            isDarkMode = d_.getString("theme", "") == "dark"
        } else {
            isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }

        val inputBg = if (isDarkMode) 0xFF212121L else 0xFFEEEEEEL
        val inputStroke = if (isDarkMode) 0xFF333333L else 0xFFE0E0E0L
        val textPrimary = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        val textSecondary = if (isDarkMode) 0xFF9E9E9E.toInt() else 0xFF757575.toInt()
        val btnBg = if (isDarkMode) 0xFFFFFFFFL else 0xFF000000L
        val btnTextColor = if (isDarkMode) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()

        if (isDarkMode) {
            window.decorView.systemUiVisibility = 0
            window.statusBarColor = 0xFF000000.toInt()
            window.navigationBarColor = 0xFF000000.toInt()
            rootRegister.setBackgroundColor(0xFF000000.toInt())
            ivBack.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFF212121L)
        } else {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = 0xFFFFFFFF.toInt()
            window.navigationBarColor = 0xFFFFFFFF.toInt()
            rootRegister.setBackgroundColor(0xFFFFFFFF.toInt())
            ivBack.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)
            ivBack.background = roundedDrawable(16, 0xFFEEEEEEL)
        }

        tvHeaderTitle.setTextColor(textPrimary)
        tvSubtitle.setTextColor(textSecondary)
        lblFirstName.setTextColor(textSecondary)
        lblLastName.setTextColor(textSecondary)
        lblEmail.setTextColor(textSecondary)
        lblPassword.setTextColor(textSecondary)
        lblReferral.setTextColor(textSecondary)
        tvHasAccountText.setTextColor(textSecondary)
        tvLoginLink.setTextColor(textPrimary)

        val inputs = listOf(etFirstName, etLastName, etEmail, etPassword, etReferral)
        for (et in inputs) {
            et.background = roundedDrawable(14, inputBg, inputStroke)
            et.setTextColor(textPrimary)
            et.setHintTextColor(textSecondary)
        }

        ivPasswordToggle.setColorFilter(textSecondary, PorterDuff.Mode.SRC_IN)

        btnRegisterSubmit.background = roundedDrawable(14, btnBg)
        btnRegisterSubmit.setTextColor(btnTextColor)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
