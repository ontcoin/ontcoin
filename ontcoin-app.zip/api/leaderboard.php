<?php
// Skybridge Network Server-Authoritative Leaderboard Engine
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
checkMaintenance($pdo);

// Query top miners directly from user_wallets and users (Zero duplicate DB tables!)
$stmt = $pdo->query("SELECT u.account_id, u.display_name, u.avatar, w.current_balance, w.lifetime_total_earned
    FROM user_wallets w
    JOIN users u ON w.account_id = u.account_id
    WHERE u.account_status = 'active'
    ORDER BY w.lifetime_total_earned DESC, w.current_balance DESC
    LIMIT 100");

$leaderboard = [];
$rank = 1;
while ($row = $stmt->fetch()) {
    $leaderboard[] = [
        'rank'             => $rank++,
        'account_id'       => $row['account_id'],
        'display_name'     => $row['display_name'] ?: 'Skybridge Miner',
        'avatar'           => $row['avatar'] ?: '',
        'current_balance'  => (float)$row['current_balance'],
        'lifetime_earned'  => (float)$row['lifetime_total_earned']
    ];
}

jsonResponse('success', 'Leaderboard rankings retrieved.', [
    'total_miners' => count($leaderboard),
    'rankings'     => $leaderboard
]);
?>
