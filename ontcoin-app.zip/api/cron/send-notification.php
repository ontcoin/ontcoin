<?php
// Skybridge Network Cron Worker - Rotates through 15 pre-seeded random system notifications
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

$pdo = getDb();

try {
    // 1. Fetch total count of notifications from notifications table
    $stmtCount = $pdo->query("SELECT COUNT(*) FROM notifications");
    $totalNotifs = (int)$stmtCount->fetchColumn();

    if ($totalNotifs === 0) {
        jsonResponse('success', 'No notifications configured in database.', null);
    }

    // Pick a random notification or sequential one
    $stmtNotif = $pdo->query("SELECT * FROM notifications ORDER BY RAND() LIMIT 1");
    $notif = $stmtNotif->fetch();

    if ($notif) {
        // Increment sent_count and update last_sent_at
        $stmtUpd = $pdo->prepare("UPDATE notifications SET sent_count = sent_count + 1, last_sent_at = NOW() WHERE id = ?");
        $stmtUpd->execute([$notif['id']]);

        jsonResponse('success', 'FCM Cron notification cycle executed successfully.', [
            'selected_notification' => [
                'id'       => (int)$notif['id'],
                'title'    => $notif['title'],
                'subtitle' => $notif['subtitle'] ?? ($notif['category'] ?? 'System Update'),
                'message'  => $notif['message'],
                'category' => $notif['category'] ?? 'SYSTEM'
            ]
        ]);
    } else {
        jsonResponse('error', 'Notification record not found.', null, 404);
    }

} catch (Exception $e) {
    error_log("Cron Notification Worker Error: " . $e->getMessage());
    jsonResponse('error', 'Cron job failed: ' . $e->getMessage(), null, 500);
}
?>
