<?php
// ============================================================================
// Skybridge Network - Automated 10-15 Min Re-Engagement Cron Runner
// Tasks:
// 1. Resolve Expired Mining Sessions -> 'completed' + Send Direct Mining Push
// 2. Dynamic Engagement Dispatch -> Select random message & push via FCM v1
// ============================================================================

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers/fcm_v1.php';

$pdo = getDb();
$isCli = (php_sapi_name() === 'cli');

$summary = [
    'timestamp'             => date('Y-m-d H:i:s'),
    'completed_sessions'    => 0,
    'session_alerts_sent'   => 0,
    'engagement_sent'       => false,
    'engagement_message_id' => null,
    'engagement_title'      => null
];

try {
    // ------------------------------------------------------------------------
    // STEP 1: Process Expired Mining Cycles (ends_at <= NOW() AND status = 'mining')
    // ------------------------------------------------------------------------
    $stmt = $pdo->prepare("
        SELECT s.id, s.user_id, s.started_at, s.ends_at, s.effective_hashrate, u.display_name, u.fcm_token
        FROM mining_sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.status = 'mining' AND s.ends_at <= NOW()
        LIMIT 100
    ");
    $stmt->execute();
    $expiredSessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $updSession = $pdo->prepare("
        UPDATE mining_sessions 
        SET status = 'completed', 
            current_cycle_accumulated = ? 
        WHERE id = ?
    ");

    foreach ($expiredSessions as $sess) {
        $startUnix = strtotime($sess['started_at']);
        $endUnix   = strtotime($sess['ends_at']);
        $hashrate  = (float)$sess['effective_hashrate'];
        $accumulated = calculateMinedTokens($startUnix, $endUnix, $hashrate);

        $updSession->execute([$accumulated, $sess['id']]);
        $summary['completed_sessions']++;

        // Send FCM completion notification to miner
        $title = "⛏️ Mining Cycle Complete!";
        $body  = "Your Skybridge rig has completed its 24h block! Claim your " . number_format($accumulated, 2) . " SB tokens now.";
        
        $pushRes = sendPushToUser($pdo, $sess['user_id'], $title, $body, [
            'action'     => 'claim_mining',
            'session_id' => $sess['id'],
            'amount'     => (string)$accumulated
        ], 'mining_complete');

        if (!empty($pushRes['success'])) {
            $summary['session_alerts_sent']++;
        }
    }

    // ------------------------------------------------------------------------
    // STEP 2: Pick Random Active Engagement Message (Weighted / Least Recent)
    // ------------------------------------------------------------------------
    $msgStmt = $pdo->prepare("
        SELECT * FROM engagement_messages 
        WHERE is_active = 1 
        ORDER BY last_sent_at ASC, times_sent ASC, RAND() 
        LIMIT 1
    ");
    $msgStmt->execute();
    $engMsg = $msgStmt->fetch(PDO::FETCH_ASSOC);

    if ($engMsg) {
        $pushResult = broadcastPushToAll($pdo, $engMsg['title'], $engMsg['message'], [
            'category'   => $engMsg['category'],
            'message_id' => (string)$engMsg['id'],
            'timestamp'  => (string)time()
        ], 'reward');

        // Update message tracking
        $updMsg = $pdo->prepare("
            UPDATE engagement_messages 
            SET times_sent = times_sent + 1, last_sent_at = NOW() 
            WHERE id = ?
        ");
        $updMsg->execute([$engMsg['id']]);

        $summary['engagement_sent'] = true;
        $summary['engagement_message_id'] = (int)$engMsg['id'];
        $summary['engagement_title'] = $engMsg['title'];
        $summary['fcm_result'] = $pushResult;
    }

    if ($isCli) {
        echo json_encode(['success' => true, 'summary' => $summary], JSON_PRETTY_PRINT) . PHP_EOL;
    } else {
        jsonOk($summary, 'Engagement cron executed successfully');
    }

} catch (Exception $e) {
    if ($isCli) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]) . PHP_EOL;
    } else {
        jsonFail('Engagement cron failed: ' . $e->getMessage(), 500);
    }
}
