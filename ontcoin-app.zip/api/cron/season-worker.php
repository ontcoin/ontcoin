<?php
require_once __DIR__ . '/../config.php';

try {
    $pdo = getDb();

    // 1. Sweep expired mining sessions and set status to 'ready_to_claim'
    $updExpired = $pdo->prepare("
        UPDATE mining_sessions 
        SET status = 'ready_to_claim' 
        WHERE status IN ('active', 'mining') AND end_time_unix <= UNIX_TIMESTAMP()
    ");
    $updExpired->execute();
    $sweptCount = $updExpired->rowCount();

    // 2. Expire old boosters
    $updBoosters = $pdo->prepare("
        UPDATE user_boosters 
        SET status = 'expired' 
        WHERE status = 'active' AND expires_at <= NOW()
    ");
    $updBoosters->execute();
    $expiredBoostersCount = $updBoosters->rowCount();

    // 3. Update leaderboard cache
    $pdo->exec("
        INSERT INTO leaderboard_cache (user_id, season_id, total_mined, rank_position)
        SELECT u.user_id, 1, COALESCE(w.mined_token_balance + w.bonus_balance + w.referral_balance, 0.0), 0
        FROM users u
        LEFT JOIN wallets w ON u.user_id = w.user_id
        WHERE u.status = 'active'
        ON DUPLICATE KEY UPDATE total_mined = VALUES(total_mined)
    ");

    jsonResponse('success', 'Background cron worker executed successfully', [
        'sessions_swept'   => $sweptCount,
        'boosters_expired' => $expiredBoostersCount,
        'timestamp'        => date('Y-m-d H:i:s')
    ]);
} catch (Exception $e) {
    jsonResponse('error', 'Cron worker error: ' . $e->getMessage(), null, 500);
}
?>
