<?php
// ============================================================================
// Skybridge Automated Mining Cycle Cron Runner & Notification Dispatcher
// Triggered via cron job, server background worker, or secure API call
// ============================================================================

require_once __DIR__ . '/../config.php';

$pdo = getDb();

$cronKey = $_GET['cron_key'] ?? $_POST['cron_key'] ?? '';
$isCli = (php_sapi_name() === 'cli');

// Allow CLI execution without key, or require key via HTTP
if (!$isCli && $cronKey !== 'SkybridgeCron2026') {
    // If not matching key, check if local call
    $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($remoteAddr, ['127.0.0.1', '::1'])) {
        jsonFail('Unauthorized cron trigger', 401);
    }
}

$startTime = microtime(true);
$settings = getSystemSettings($pdo);
$fcmServerKey = $settings['fcm_server_key'] ?? '';

$sessionsCompleted = 0;
$notificationsCreated = 0;
$fcmDispatched = 0;
$boostersExpired = 0;

try {
    // 1. Find all active sessions where ends_at <= NOW() and status = 'mining'
    $stmt = $pdo->prepare("
        SELECT ms.*, u.display_name, u.fcm_token 
        FROM mining_sessions ms
        JOIN users u ON u.id = ms.user_id
        WHERE ms.ends_at <= NOW() AND ms.status = 'mining'
        LIMIT 500
    ");
    $stmt->execute();
    $completedSessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($completedSessions as $sess) {
        $sessionId = $sess['id'];
        $userId    = $sess['user_id'];
        $userName  = $sess['display_name'];
        $fcmToken  = $sess['fcm_token'];

        // Calculate final mined tokens for this cycle
        $startUnix = strtotime($sess['started_at']);
        $endUnix   = strtotime($sess['ends_at']);
        $rate      = (float)$sess['effective_hashrate'];
        $mined     = calculateMinedTokens($startUnix, $endUnix, $rate);

        // Update status to 'completed'
        $upd = $pdo->prepare("
            UPDATE mining_sessions 
            SET status = 'completed', current_cycle_accumulated = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $upd->execute([$mined, $sessionId]);
        $sessionsCompleted++;

        // If not yet notified, create in-app notification & push FCM
        if ((int)$sess['notified'] === 0) {
            $notifTitle = '⛏️ Mining Cycle Completed!';
            $notifMsg = 'Your mining session has finished! Open Skybridge now to claim your mined tokens and restart your rig.';

            $insNotif = $pdo->prepare("
                INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
                VALUES (?, ?, ?, 'mining_complete', 0, NOW())
            ");
            $insNotif->execute([$userId, $notifTitle, $notifMsg]);
            $notificationsCreated++;

            // FCM Push Notification
            if (!empty($fcmToken) && !empty($fcmServerKey)) {
                $fcmSent = sendFcmPushNotification(
                    $fcmServerKey,
                    $fcmToken,
                    $notifTitle,
                    $notifMsg,
                    [
                        'type'         => 'mining_complete',
                        'session_id'   => (string)$sessionId,
                        'accumulated'  => (string)$mined,
                        'click_action' => 'FLUTTER_NOTIFICATION_CLICK'
                    ]
                );
                if ($fcmSent) {
                    $fcmDispatched++;
                }
            }

            // Set notified = TRUE
            $updNotif = $pdo->prepare("UPDATE mining_sessions SET notified = 1 WHERE id = ?");
            $updNotif->execute([$sessionId]);
        }
    }

    // 2. Sweep expired boosters
    $expBoosterStmt = $pdo->query("
        UPDATE user_boosters 
        SET status = 'expired' 
        WHERE status = 'active' AND expires_at <= NOW()
    ");
    $boostersExpired = $expBoosterStmt->rowCount();

    $elapsedMs = round((microtime(true) - $startTime) * 1000, 2);

    $summary = [
        'sessions_completed'    => $sessionsCompleted,
        'notifications_created' => $notificationsCreated,
        'fcm_dispatched'        => $fcmDispatched,
        'boosters_expired'      => $boostersExpired,
        'execution_time_ms'     => $elapsedMs,
        'executed_at'           => date('Y-m-d H:i:s')
    ];

    if ($isCli) {
        echo json_encode($summary, JSON_PRETTY_PRINT) . PHP_EOL;
    } else {
        jsonOk($summary, 'Mining cron cycle executed successfully');
    }

} catch (Exception $e) {
    if ($isCli) {
        fwrite(STDERR, "Cron Error: " . $e->getMessage() . PHP_EOL);
        exit(1);
    } else {
        jsonFail('Cron execution error: ' . $e->getMessage(), 500);
    }
}
