<?php
// ============================================================================
// Skybridge Network - Automated 15-Minute Event Notification Cron Engine
// Frequency: Every 15 minutes (Scheduled via cPanel Cron & HTTP endpoint)
// Architecture:
// 1. Resolve Expired Mining Sessions -> Mark completed & send individual completion push
// 2. Select from 15 Distinct Engaging Events (Non-consecutive randomized rotation)
// 3. Dispatch Multi-Topic FCM HTTP v1 Broadcast ('all', 'all_miners', 'skybridge_miners')
// 4. Dispatch Direct Push to active device tokens
// 5. Record broadcast into MySQL notifications table for in-app inbox
// ============================================================================

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers/fcm_v1.php';

// Set JSON headers if executed via HTTP
$isCli = (php_sapi_name() === 'cli');
if (!$isCli) {
    header('Content-Type: application/json; charset=UTF-8');
}

$pdo = getDb();

$summary = [
    'status'                => 'success',
    'timestamp'             => date('Y-m-d H:i:s'),
    'cron_interval'         => '15 minutes',
    'completed_sessions'    => 0,
    'session_alerts_sent'   => 0,
    'selected_event_id'     => null,
    'selected_event_title'  => null,
    'selected_event_body'   => null,
    'fcm_dispatch_result'   => null
];

try {
    // ------------------------------------------------------------------------
    // STEP 1: Process Expired Mining Cycles (ends_at <= NOW() AND status = 'mining')
    // ------------------------------------------------------------------------
    try {
        $stmt = $pdo->prepare("
            SELECT s.id, s.user_id, s.started_at, s.ends_at, s.effective_hashrate, u.display_name, u.fcm_token
            FROM mining_sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.status = 'mining' AND s.ends_at <= NOW()
            LIMIT 50
        ");
        $stmt->execute();
        $expiredSessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $updSession = $pdo->prepare("
            UPDATE mining_sessions 
            SET status = 'completed', 
                current_cycle_accumulated = ? 
            WHERE id = ?
        ");

        foreach ($expiredSessions as $sess) {
            $startUnix = strtotime($sess['started_at']);
            $endUnix   = strtotime($sess['ends_at']);
            $hashrate  = (float)($sess['effective_hashrate'] ?: 1.0);
            $hours = max(1, ($endUnix - $startUnix) / 3600);
            $accumulated = round($hashrate * $hours * 0.5, 4);

            $updSession->execute([$accumulated, $sess['id']]);
            $summary['completed_sessions']++;

            // Send targeted completion alert to miner
            $title = "⛏️ Mining Cycle Complete!";
            $body  = "Your Skybridge node completed its 24h block! Claim your " . number_format($accumulated, 2) . " SB tokens now.";
            
            $pushRes = sendPushToUser($pdo, $sess['user_id'], $title, $body, [
                'action'     => 'claim_mining',
                'session_id' => (string)$sess['id'],
                'amount'     => (string)$accumulated
            ], 'mining_complete');

            if (!empty($pushRes['success'])) {
                $summary['session_alerts_sent']++;
            }
        }
    } catch (Exception $e) {
        error_log("[CRON] Session completion error: " . $e->getMessage());
    }

    // ------------------------------------------------------------------------
    // STEP 2: Pool of 15 Engaging, Non-Repetitive Event Notifications
    // ------------------------------------------------------------------------
    $events = [
        [
            'id' => 1,
            'event' => 'airdrop_distribution',
            'title' => '🎁 Hourly Node Airdrop Live!',
            'message' => 'Skybridge network just generated new block rewards. Tap to claim your share before the pool resets!',
            'category' => 'reward',
            'action' => 'open_wallet'
        ],
        [
            'id' => 2,
            'event' => 'hashrate_surge',
            'title' => '⚡ Hashrate Surge Detected!',
            'message' => 'Global network hashrate is peaking. Boost your rig speed with a quick ad multiplier now!',
            'category' => 'ad_boost',
            'action' => 'mining_boost'
        ],
        [
            'id' => 3,
            'event' => 'mining_streak',
            'title' => "🔥 Don't Break Your Mining Streak!",
            'message' => 'Your daily sync multiplier increases every 24h. Check your node to keep your 2x bonus alive.',
            'category' => 'system',
            'action' => 'check_streak'
        ],
        [
            'id' => 4,
            'event' => 'referral_commissions',
            'title' => '👥 Referral Squad Rewards Available!',
            'message' => 'Miners in your referral tree are actively earning. Collect your passive squad commissions today!',
            'category' => 'reward',
            'action' => 'view_squad'
        ],
        [
            'id' => 5,
            'event' => 'season_pool_update',
            'title' => '🌐 Genesis Season 1 Pool Update',
            'message' => 'Over 1.5M tokens minted this week! Check the live season leaderboard and your current rank.',
            'category' => 'system',
            'action' => 'season_leaderboard'
        ],
        [
            'id' => 6,
            'event' => 'rig_status_check',
            'title' => '⛏️ Mining Rig Status Check',
            'message' => 'Is your node actively hashing? Open Skybridge to verify your current block progress and hashrate.',
            'category' => 'mining_complete',
            'action' => 'dashboard'
        ],
        [
            'id' => 7,
            'event' => 'speed_booster_ready',
            'title' => '🚀 20% Hashrate Booster Ready',
            'message' => 'A temporary speed booster has become available for your account. Activate it to maximize your yield!',
            'category' => 'ad_boost',
            'action' => 'boost_node'
        ],
        [
            'id' => 8,
            'event' => 'node_heartbeat',
            'title' => '🛡️ Decentralized Node Heartbeat',
            'message' => 'Your account security status is verified. Complete a daily ping to validate your proof-of-uptime.',
            'category' => 'security',
            'action' => 'security_check'
        ],
        [
            'id' => 9,
            'event' => 'community_milestone',
            'title' => '📈 100,000+ Active Miners Milestone!',
            'message' => 'The Skybridge Network is expanding rapidly. Invite friends to unlock higher mining tiers together.',
            'category' => 'system',
            'action' => 'invite_friends'
        ],
        [
            'id' => 10,
            'event' => 'ad_multiplier_reward',
            'title' => '💎 Double Your Hourly Yield',
            'message' => 'Watch a short sponsor video to instantly add bonus hashrate to your active mining session.',
            'category' => 'ad_boost',
            'action' => 'watch_ad'
        ],
        [
            'id' => 11,
            'event' => 'halving_countdown',
            'title' => '⏳ Halving Countdown in Progress',
            'message' => 'Block reward halving approaches as pool thresholds are reached. Accumulate tokens while rewards are highest!',
            'category' => 'system',
            'action' => 'view_pool'
        ],
        [
            'id' => 12,
            'event' => 'wallet_backup_sync',
            'title' => '🔐 Balance Synchronization',
            'message' => 'Your mined balance is safeguarded. Review your wallet and verify your backup recovery key.',
            'category' => 'security',
            'action' => 'wallet'
        ],
        [
            'id' => 13,
            'event' => 'hashrate_challenge',
            'title' => '🏆 Community Hashrate Challenge',
            'message' => "Join today's mining blitz! The top 50 active miners this session receive an exclusive token bonus.",
            'category' => 'reward',
            'action' => 'leaderboard'
        ],
        [
            'id' => 14,
            'event' => 'evening_cycle',
            'title' => '🌙 Evening Mining Cycle Active',
            'message' => 'Overnight mining ensures uninterrupted token generation. Ensure your session stays active tonight!',
            'category' => 'system',
            'action' => 'check_mining'
        ],
        [
            'id' => 15,
            'event' => 'golden_block',
            'title' => '🌟 Golden Block Discovered!',
            'message' => 'Bonus mining rewards are distributed for the next 60 minutes. Open Skybridge and check your balance!',
            'category' => 'reward',
            'action' => 'claim_bonus'
        ]
    ];

    // ------------------------------------------------------------------------
    // STEP 3: Anti-Repetition Randomization Logic
    // Store recent history so messages do not repeat consecutively
    // ------------------------------------------------------------------------
    $historyFile = sys_get_temp_dir() . '/skybridge_recent_cron_events.json';
    $recentIds = [];
    if (file_exists($historyFile)) {
        $recentIds = json_decode(@file_get_contents($historyFile), true) ?: [];
    }

    // Filter available candidates that were not sent in the last 7 cycles
    $candidates = array_values(array_filter($events, function($e) use ($recentIds) {
        return !in_array($e['id'], $recentIds);
    }));

    // If all events have been used, reset the history
    if (empty($candidates)) {
        $candidates = $events;
        $recentIds = [];
    }

    // Pick random candidate
    $chosenIndex = mt_rand(0, count($candidates) - 1);
    $selectedEvent = $candidates[$chosenIndex];

    // Update history (keep max 7 recent items)
    $recentIds[] = $selectedEvent['id'];
    if (count($recentIds) > 7) {
        array_shift($recentIds);
    }
    @file_put_contents($historyFile, json_encode($recentIds));

    $summary['selected_event_id']    = $selectedEvent['id'];
    $summary['selected_event_title'] = $selectedEvent['title'];
    $summary['selected_event_body']  = $selectedEvent['message'];

    // ------------------------------------------------------------------------
    // STEP 4: Dispatch FCM HTTP v1 Broadcast Across Topics & Active Tokens
    // ------------------------------------------------------------------------
    $payloadData = [
        'event_id'   => (string)$selectedEvent['id'],
        'event_name' => $selectedEvent['event'],
        'action'     => $selectedEvent['action'],
        'timestamp'  => (string)time()
    ];

    $fcmResult = broadcastPushToAll(
        $pdo,
        $selectedEvent['title'],
        $selectedEvent['message'],
        $payloadData,
        $selectedEvent['category']
    );

    $summary['fcm_dispatch_result'] = $fcmResult;

} catch (Exception $e) {
    $summary['status'] = 'error';
    $summary['error_message'] = $e->getMessage();
}

if ($isCli) {
    echo "[CRON " . $summary['timestamp'] . "] Status: " . $summary['status'] . "\n";
    echo "Event #" . $summary['selected_event_id'] . " Dispatched: " . $summary['selected_event_title'] . "\n";
    echo "Body: " . $summary['selected_event_body'] . "\n";
    echo "Completed Sessions: " . $summary['completed_sessions'] . "\n";
} else {
    echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
?>
