<?php
require_once __DIR__ . '/../register-fcm-token.php';
?>
