<?php
require_once __DIR__ . '/../verify-email-otp.php';
?>
