<?php
require_once __DIR__ . '/../config.php';

$pdo = getDb();
checkMaintenanceMode($pdo);

$user = getAuthenticatedUser($pdo, true);

$stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ? LIMIT 1");
$stmt->execute([$user['id']]);
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);

jsonOk([
    'user_id'            => (string)$user['id'],
    'account_id'         => $user['account_id'],
    'email'              => $user['email'],
    'display_name'       => $user['display_name'],
    'avatar'             => $user['avatar'],
    'profile_image'      => $user['avatar'],
    'referral_code'      => $user['referral_code'],
    'kyc_tier'           => (int)$user['kyc_tier'],
    'account_status'     => $user['account_status'],
    'mined_balance'      => (float)($wallet['mined_balance'] ?? 0),
    'claimable_balance'  => (float)($wallet['claimable_balance'] ?? 0),
    'bonus_balance'      => (float)($wallet['bonus_balance'] ?? 0),
    'total_balance'      => (float)(($wallet['mined_balance'] ?? 0) + ($wallet['bonus_balance'] ?? 0))
], 'Session verified');
