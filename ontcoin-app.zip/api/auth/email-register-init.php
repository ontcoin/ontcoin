<?php
require_once __DIR__ . '/../email-register-init.php';
?>
