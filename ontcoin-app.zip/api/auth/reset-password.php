<?php
require_once __DIR__ . '/../config.php';
$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true) ?: [];
$post = array_merge($_POST, $body);

$email       = filter_var(trim($post['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$otp         = trim(sanitizeInput($post['otp'] ?? ''));
$newPassword = $post['new_password'] ?? '';

if (!$email || empty($otp) || empty($newPassword)) {
    jsonResponse('error', 'Email, OTP code, and new password are required.', null, 400);
}

if (strlen($newPassword) < 6) {
    jsonResponse('error', 'New password must be at least 6 characters long.', null, 400);
}

try {
    $stmt = $pdo->prepare("
        SELECT id FROM email_verifications 
        WHERE email = ? AND otp = ? AND action = 'forgot_password' AND is_verified = 0 AND expires_at > NOW()
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([$email, $otp]);
    $record = $stmt->fetch();

    if (!$record) {
        jsonResponse('error', 'Invalid or expired password reset code.', null, 400);
    }

    $pwdHash = password_hash($newPassword, PASSWORD_BCRYPT);

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE email_verifications SET is_verified = 1 WHERE id = ?")->execute([$record['id']]);
    $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE email = ?")->execute([$pwdHash, $email]);
    $pdo->commit();

    jsonResponse('success', 'Password has been reset successfully. You can now log in.');

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    jsonResponse('error', 'Password reset error: ' . $e->getMessage(), null, 500);
}
?>
