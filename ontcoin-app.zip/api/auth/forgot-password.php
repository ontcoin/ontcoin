<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers/mailer.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true) ?: [];
$post = array_merge($_POST, $body);

$email = filter_var(trim($post['email'] ?? ''), FILTER_VALIDATE_EMAIL);
if (!$email) {
    jsonResponse('error', 'Valid email address is required.', null, 400);
}

try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if (!$stmt->fetch()) {
        jsonResponse('error', 'No Skybridge account found for this email.', null, 404);
    }

    $settings = getSystemSettings($pdo);
    $expiryMinutes = (int)($settings['otp_expiry_minutes'] ?? 10);
    $otp = sprintf('%06d', mt_rand(100000, 999999));

    $ins = $pdo->prepare("
        INSERT INTO email_verifications (email, otp, action, is_verified, expires_at, created_at)
        VALUES (?, ?, 'forgot_password', 0, DATE_ADD(NOW(), INTERVAL ? MINUTE), NOW())
    ");
    $ins->execute([$email, $otp, $expiryMinutes]);

    $mailSent = sendSkybridgeOtpMail($email, $otp, 'SkyBridge - Password Reset Code', $expiryMinutes);

    jsonResponse('success', 'Password reset code has been sent to your email.', [
        'email'      => $email,
        'expires_in' => $expiryMinutes * 60,
        'mail_sent'  => $mailSent
    ]);

} catch (Exception $e) {
    jsonResponse('error', 'Forgot password error: ' . $e->getMessage(), null, 500);
}
?>
