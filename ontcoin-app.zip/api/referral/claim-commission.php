<?php
require_once __DIR__ . '/claim-bonus.php';
