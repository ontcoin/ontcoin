<?php
require_once __DIR__ . '/../config.php';

$pdo = getDb();
checkMaintenanceMode($pdo);

$user = getAuthenticatedUser($pdo, true);
$userId = $user['id'];

try {
    $pdo->beginTransaction();

    $wStmt = $pdo->prepare("SELECT bonus_balance, mined_balance FROM wallets WHERE user_id = ? FOR UPDATE");
    $wStmt->execute([$userId]);
    $wallet = $wStmt->fetch(PDO::FETCH_ASSOC);

    $bonus = (float)($wallet['bonus_balance'] ?? 0);
    if ($bonus <= 0) {
        $pdo->rollBack();
        jsonFail('No referral rewards available to transfer', 400);
    }

    // Transfer bonus_balance into mined_balance
    $upd = $pdo->prepare("
        UPDATE wallets 
        SET mined_balance = mined_balance + ?, bonus_balance = 0, updated_at = NOW() 
        WHERE user_id = ?
    ");
    $upd->execute([$bonus, $userId]);

    $txHash = '0x' . bin2hex(random_bytes(32));
    $insTx = $pdo->prepare("
        INSERT INTO transactions_ledger (tx_hash, user_id, type, amount, status, metadata_json)
        VALUES (?, ?, 'referral_bonus', ?, 'completed', ?)
    ");
    $insTx->execute([$txHash, $userId, $bonus, json_encode(['action' => 'transferred_to_main'])]);

    $pdo->commit();

    jsonOk([
        'transferred_amount'         => $bonus,
        'claimed_amount'             => $bonus,
        'mined_balance'              => (float)($wallet['mined_balance'] ?? 0) + $bonus,
        'new_main_balance'           => (float)($wallet['mined_balance'] ?? 0) + $bonus,
        'remaining_bonus_balance'    => 0.0,
        'remaining_referral_balance' => 0.0
    ], 'Referral rewards transferred to main wallet');

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    jsonFail('Failed to claim referral rewards: ' . $e->getMessage(), 500);
}
