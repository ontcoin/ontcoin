<?php
require_once __DIR__ . '/../config.php';
$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse('error', 'Only GET or POST methods are allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true) ?: [];
$params = array_merge($_GET, $_POST, $body);

$userId = sanitizeInput($params['user_id'] ?? $params['account_id'] ?? '');
if (empty($userId)) {
    jsonResponse('error', 'User identification parameter is required.', null, 400);
}

try {
    $uStmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? OR account_id = ? OR email = ? LIMIT 1");
    $uStmt->execute([$userId, $userId, $userId]);
    $user = $uStmt->fetch();

    if (!$user) {
        jsonResponse('error', 'User account not found.', null, 404);
    }

    $actualUserId = $user['user_id'];
    $settings = getSystemSettings($pdo);

    $stmt = $pdo->prepare("
        SELECT 
            u.name,
            u.email,
            u.avatar AS profile_image,
            u.created_at AS joined_date,
            r.status,
            r.reward_earned
        FROM referrals r
        INNER JOIN users u ON r.referee_id = u.user_id
        WHERE r.referrer_id = ?
        ORDER BY r.id DESC
    ");
    $stmt->execute([$actualUserId]);
    $friends = $stmt->fetchAll();

    $totalReferred = count($friends);
    $totalEarned = (float)$user['referral_balance'];

    jsonResponse('success', 'Referral data retrieved successfully', [
        'referral_code'          => $user['referral_code'],
        'referral_percentage'    => (float)($settings['referral_percentage'] ?? 10.0),
        'direct_referral_bonus'  => (float)($settings['direct_referral_bonus'] ?? 25.0),
        'total_referred'         => $totalReferred,
        'total_referral_earned'  => $totalEarned,
        'friends'                => $friends
    ]);

} catch (Exception $e) {
    jsonResponse('error', 'Referral error: ' . $e->getMessage(), null, 500);
}
?>
