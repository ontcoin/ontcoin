<?php
require_once __DIR__ . '/../config.php';

$pdo = getDb();
checkMaintenanceMode($pdo);

$user = getAuthenticatedUser($pdo, true);
$userId = $user['id'];

// Get all squad members (referees)
$refStmt = $pdo->prepare("
    SELECT 
        u.id, u.display_name, u.avatar, u.created_at,
        rt.direct_bonus_paid, rt.commission_rate,
        (SELECT COUNT(*) FROM mining_sessions ms WHERE ms.user_id = u.id AND ms.status = 'mining' AND ms.ends_at > NOW()) as is_mining,
        COALESCE((SELECT SUM(amount) FROM transactions_ledger tl WHERE tl.user_id = ? AND tl.type = 'referral_bonus' AND JSON_EXTRACT(tl.metadata_json, '$.from_user_id') = u.id), 0) as total_generated
    FROM referral_tree rt
    JOIN users u ON u.id = rt.referee_id
    WHERE rt.referrer_id = ?
    ORDER BY rt.created_at DESC
");
$refStmt->execute([$userId, $userId]);
$squad = $refStmt->fetchAll(PDO::FETCH_ASSOC);

$totalMembers = count($squad);
$activeMiners = 0;
$totalCommissionEarned = 0.0;

$membersList = [];
foreach ($squad as $m) {
    $miningActive = (int)$m['is_mining'] > 0;
    if ($miningActive) $activeMiners++;
    $gen = (float)$m['total_generated'];
    $totalCommissionEarned += $gen;

    $membersList[] = [
        'id'               => (int)$m['id'],
        'name'             => $m['display_name'],
        'avatar'           => $m['avatar'],
        'joined_at'        => $m['created_at'],
        'is_mining'        => $miningActive,
        'commission_earned'=> $gen
    ];
}

// Wallet bonus balance
$wStmt = $pdo->prepare("SELECT bonus_balance, mined_balance FROM wallets WHERE user_id = ? LIMIT 1");
$wStmt->execute([$userId]);
$wallet = $wStmt->fetch(PDO::FETCH_ASSOC);

$settings = getSystemSettings($pdo);

jsonOk([
    'referral_code'           => $user['referral_code'],
    'share_url'               => APP_URL . '/?ref=' . $user['referral_code'],
    'total_members'           => $totalMembers,
    'total_friends'           => $totalMembers,
    'active_miners'           => $activeMiners,
    'total_commission_earned' => $totalCommissionEarned,
    'total_earned'            => $totalCommissionEarned,
    'available_bonus_balance' => (float)($wallet['bonus_balance'] ?? 0),
    'referral_balance'        => (float)($wallet['bonus_balance'] ?? 0),
    'commission_rate_percent' => (float)(($settings['referral_commission_rate'] ?? 0.10) * 100),
    'squad'                   => $membersList,
    'friends'                 => array_map(function($m) {
        return [
            'name'       => $m['name'],
            'avatar'     => $m['avatar'],
            'avatar_url' => $m['avatar'],
            'status'     => $m['is_mining'] ? 'Mining' : 'Idle',
            'amount'     => number_format($m['commission_earned'], 2) . ' SB',
            'is_active'  => $m['is_mining'],
            'joined_at'  => $m['joined_at']
        ];
    }, $membersList)
], 'Referral stats retrieved');
