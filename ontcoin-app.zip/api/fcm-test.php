<?php
// Skybridge Developer FCM Test & Diagnostic Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/fcm.php';

$key = $_GET['key'] ?? $_POST['key'] ?? '';
if ($key !== 'skybridge_dev_fcm_test_2026') {
    jsonResponse('error', 'Unauthorized access to FCM test endpoint.', null, 403);
}

$pdo = getDb();
$settings = getSystemSettings($pdo);

$type = sanitizeInput($_REQUEST['type'] ?? 'BROADCAST');
$targetAccountId = sanitizeInput($_REQUEST['account_id'] ?? '');
$title = sanitizeInput($_REQUEST['title'] ?? 'Skybridge Network Security Test');
$message = sanitizeInput($_REQUEST['message'] ?? 'This is a test notification sent from the Skybridge FCM Engine.');

$eventKey = 'TEST_' . time() . '_' . rand(1000, 9999);
$result = dispatchFcmNotification($pdo, $targetAccountId ?: null, $title, $message, $type, $eventKey);

jsonResponse('success', 'FCM Test Execution Completed.', [
    'fcm_configuration_status' => 'ACTIVE',
    'target_account_id'        => $targetAccountId ?? 'ALL_USERS',
    'send_attempt_status'      => 'EXECUTED',
    'event_key'                => $eventKey,
    'dispatch_result'          => $result
]);
?>
