<?php
// Skybridge Bind Referrer Code Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$accountId = sanitizeInput($input['account_id'] ?? '');
$referralCode = sanitizeInput($input['referral_code'] ?? $input['code'] ?? '');

if (empty($accountId) || empty($referralCode)) {
    jsonResponse('error', 'Account ID and referral code are required.', null, 400);
}

// Find user
$stmtU = $pdo->prepare("SELECT id, account_id, referred_by FROM users WHERE account_id = ? LIMIT 1");
$stmtU->execute([$accountId]);
$user = $stmtU->fetch();

if (!$user) {
    jsonResponse('error', 'User account not found.', null, 404);
}

if (!empty($user['referred_by'])) {
    jsonResponse('error', 'A referrer has already been bound to this account.', null, 400);
}

// Find referrer user by referral code or account_id
$stmtRef = $pdo->prepare("SELECT id, account_id, referral_code FROM users WHERE referral_code = ? OR account_id = ? LIMIT 1");
$stmtRef->execute([$referralCode, $referralCode]);
$referrer = $stmtRef->fetch();

if (!$referrer) {
    jsonResponse('error', 'Invalid referral code provided.', null, 404);
}

if ($referrer['account_id'] === $accountId) {
    jsonResponse('error', 'You cannot use your own referral code.', null, 400);
}

// Update referred_by in users table directly
$stmtUpd = $pdo->prepare("UPDATE users SET referred_by = ? WHERE id = ?");
$stmtUpd->execute([$referrer['account_id'], $user['id']]);

jsonResponse('success', 'Referral code bound successfully.', [
    'account_id' => $accountId,
    'referrer_account_id' => $referrer['account_id']
]);
?>
