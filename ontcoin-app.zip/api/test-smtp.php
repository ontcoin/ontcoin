<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/mailer.php';

$testEmail = filter_var($_GET['email'] ?? 'skybridgenetwork000@gmail.com', FILTER_VALIDATE_EMAIL);
if (!$testEmail) {
    jsonResponse('error', 'Valid target email query parameter required (e.g. ?email=user@example.com)', null, 400);
}

$otp = sprintf('%06d', mt_rand(100000, 999999));
$sent = sendSkybridgeOtpMail($testEmail, $otp, 'SkyBridge - Diagnostic SMTP Delivery Test', 10);

if ($sent) {
    jsonResponse('success', 'SMTP delivery test completed successfully! Verification email was sent.', [
        'target_email' => $testEmail,
        'smtp_host'    => SMTP_HOST,
        'smtp_port'    => SMTP_PORT,
        'from_address' => SMTP_FROM_EMAIL,
        'delivery'     => 'success'
    ]);
} else {
    jsonResponse('error', 'SMTP test email delivery failed. Check mail server logs on host.', [
        'target_email' => $testEmail,
        'smtp_host'    => SMTP_HOST,
        'smtp_port'    => SMTP_PORT,
        'delivery'     => 'failed'
    ], 500);
}
?>
