<?php
// Skybridge Google Authentication Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/mailer.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
$googleId = sanitizeInput($input['google_id'] ?? $input['id'] ?? '');
$name = sanitizeInput($input['name'] ?? $input['display_name'] ?? 'Skybridge Miner');
$avatar = sanitizeInput($input['avatar'] ?? $input['photo_url'] ?? '');
$referralCodeInput = sanitizeInput($input['referral_code'] ?? '');

if (!$email) {
    jsonResponse('error', 'A valid email address is required for Google authentication.', null, 400);
}

// Find or create user account
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();
$isNewUser = false;

if (!$user) {
    checkAccountCreation($pdo);

    $isNewUser = true;
    $accountId = generateAccountId($pdo);
    $userId = generateUserId($pdo);
    $myReferralCode = generateReferralCode($pdo);

    // Look up referrer if referral code provided
    $referrerAccountId = null;
    if (!empty($referralCodeInput)) {
        $stmtRef = $pdo->prepare("SELECT account_id FROM users WHERE referral_code = ? LIMIT 1");
        $stmtRef->execute([$referralCodeInput]);
        $refRow = $stmtRef->fetch();
        if ($refRow) {
            $referrerAccountId = $refRow['account_id'];
        }
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $deviceInfo = sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'Android');

    $stmtIns = $pdo->prepare("INSERT INTO users (account_id, user_id, email, google_id, display_name, avatar, referral_code, referred_by, registration_ip, last_ip, device_info, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmtIns->execute([$accountId, $userId, $email, $googleId, $name, $avatar, $myReferralCode, $referrerAccountId, $ip, $ip, $deviceInfo]);

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Send Welcome Email
    sendWelcomeEmail($email, $name);
} else {
    // Existing user: update google_id and login metadata
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $deviceInfo = sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'Android');

    $stmtUpd = $pdo->prepare("UPDATE users SET google_id = COALESCE(?, google_id), display_name = ?, avatar = COALESCE(?, avatar), last_ip = ?, last_login_at = NOW() WHERE id = ?");
    $stmtUpd->execute([$googleId, $name, $avatar, $ip, $user['id']]);

    // Send New Device Login Email
    sendNewDeviceLoginEmail($email, $name, $deviceInfo, $ip);
}

// Ensure wallet exists linked with account_id, user_id, email
$wallet = getOrCreateUserWallet($pdo, $user['account_id']);

jsonResponse('success', $isNewUser ? 'Google account registered successfully.' : 'Google authentication successful.', [
    'account_id'          => $user['account_id'],
    'user_id'             => $user['user_id'],
    'email'               => $user['email'],
    'display_name'        => $user['display_name'],
    'avatar'              => $user['avatar'] ?? '',
    'referral_code'       => $user['referral_code'],
    'current_balance'     => (float)$wallet['current_balance'],
    'lifetime_total_earned' => (float)$wallet['lifetime_total_earned'],
    'is_new_user'         => $isNewUser
]);
?>
