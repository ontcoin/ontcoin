<?php
// Skybridge Network Central Production Config & Database Engine
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(200);
    exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'linexwar_sb369');
define('DB_PASS', 'Just09166388665j@');
define('DB_NAME', 'linexwar_sb369');

// Deployment & FTP/cPanel Credentials
define('FTP_HOST', 'skybridge.linexware.net.ng');
define('FTP_PORT', 21);
define('FTP_USER', 'linexware');
define('FTP_PASS', 'Just09166388665j@');
define('FTP_API_DIR', 'skybridge.linexware.net.ng/api');
define('FTP_WEB_DIR', 'skybridge.linexware.net.ng/web');

function getDb(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        
        ensureCoreTablesAndMigration($pdo);
    }
    return $pdo;
}

/**
 * Migration & Core System Setup Engine
 * Fully links user_wallets with account_id, user_id, and email.
 * Cleans up legacy tables: user_balance_backups, user_fcm_tokens, referrals.
 */
function ensureCoreTablesAndMigration(PDO $pdo): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    try {
        // Drop obsolete legacy tables
        $pdo->exec("DROP TABLE IF EXISTS `user_balance_backups`");
        $pdo->exec("DROP TABLE IF EXISTS `user_fcm_tokens`");
        $pdo->exec("DROP TABLE IF EXISTS `referrals`");
        $pdo->exec("DROP TABLE IF EXISTS `referral`");

        // Create system_settings
        $pdo->exec("CREATE TABLE IF NOT EXISTS `system_settings` (
            `setting_key` VARCHAR(64) PRIMARY KEY,
            `setting_value` TEXT NOT NULL,
            `description` VARCHAR(255) NULL,
            `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Seed requested system settings only
        $defaultSettings = [
            'mining_time'         => '86400',
            'mining_claim_amount' => '10.00000000',
            'referral_bonus'      => '10%',
            'maintenance_mode'    => 'false',
            'create_account'      => 'true'
        ];

        $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, 'Core setting')");
        foreach ($defaultSettings as $k => $v) {
            $stmt->execute([$k, $v]);
        }

        // Create user_wallets table linked with account_id, user_id, email
        $pdo->exec("CREATE TABLE IF NOT EXISTS `user_wallets` (
            `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `account_id` VARCHAR(64) NOT NULL UNIQUE,
            `user_id` VARCHAR(64) NOT NULL,
            `email` VARCHAR(191) NOT NULL,
            `current_balance` DECIMAL(24,8) NOT NULL DEFAULT 0.00000000,
            `total_incoming` DECIMAL(24,8) NOT NULL DEFAULT 0.00000000,
            `total_outgoing` DECIMAL(24,8) NOT NULL DEFAULT 0.00000000,
            `lifetime_total_earned` DECIMAL(24,8) NOT NULL DEFAULT 0.00000000,
            `last_updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_uw_account` (`account_id`),
            INDEX `idx_uw_user` (`user_id`),
            INDEX `idx_uw_email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Create wallet_ledger table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `wallet_ledger` (
            `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `account_id` VARCHAR(64) NOT NULL,
            `transaction_type` ENUM('MINING_CLAIM', 'REFERRAL_REWARD', 'BONUS', 'ADJUSTMENT', 'WITHDRAWAL') NOT NULL,
            `amount` DECIMAL(24,8) NOT NULL,
            `balance_before` DECIMAL(24,8) NOT NULL,
            `balance_after` DECIMAL(24,8) NOT NULL,
            `reference_id` VARCHAR(128) NULL,
            `description` TEXT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_wl_account` (`account_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Create notifications table with 15 pre-seeded system notification messages with title, subtitle, and message
        $pdo->exec("CREATE TABLE IF NOT EXISTS `notifications` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(255) NOT NULL,
            `subtitle` VARCHAR(255) NOT NULL,
            `message` TEXT NOT NULL,
            `category` VARCHAR(64) DEFAULT 'SYSTEM',
            `sent_count` INT UNSIGNED DEFAULT 0,
            `last_sent_at` DATETIME NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Seed 15 engaging notifications if empty
        $stmtNotifCount = $pdo->query("SELECT COUNT(*) FROM notifications");
        if ((int)$stmtNotifCount->fetchColumn() === 0) {
            $notificationsList = [
                ["Welcome to Skybridge", "Node Initialization", "Start your daily 24-hour mining cycle to accumulate tokens continuously.", "WELCOME"],
                ["Genesis Mining Pool", "Hashrate Update", "Global network hashrate is growing rapidly. Keep your session active!", "MINING"],
                ["Daily Token Reward", "Session Expired", "Your 24-hour mining cycle has ended. Claim your tokens now.", "REWARD"],
                ["Airdrop Phase 1", "Ecosystem Milestone", "Over 50,000 miners have joined the Skybridge ecosystem.", "ECOSYSTEM"],
                ["Referral Bonus Active", "Hashrate Boost", "Invite active friends with your referral ID and earn a 10% bonus.", "REFERRAL"],
                ["Security Alert", "Protect Your Account", "Enable passcode lock and biometrics in settings to secure your tokens.", "SECURITY"],
                ["Network Upgrade", "System Performance", "Server infrastructure updated for instant claim settlements.", "SYSTEM"],
                ["1,000,000 Tokens Claimed", "Community Milestone", "Skybridge mining pool total tokens claimed passed 1,000,000.", "ECOSYSTEM"],
                ["Mainnet Roadmap", "Distribution Preview", "Token generation event and mainnet wallet distribution preview released.", "ROADMAP"],
                ["Hashrate Distribution", "Node Synchronization", "Daily node rewards distributed across all active miners.", "MINING"],
                ["Squad Bonus Commission", "Wallet Updated", "Your squad member claimed rewards. Check your referral bonus balance.", "REFERRAL"],
                ["Security Checklist", "Account Safeguards", "Always keep your email and login credentials secure.", "SECURITY"],
                ["Leaderboard Update", "Top Rankings", "Check the global leaderboard to see the top Skybridge miners.", "RANKING"],
                ["Ecosystem News", "Roadmap Feeds", "Read the latest roadmap news and developments in the Feeds tab.", "NEWS"],
                ["Daily Claim Reminder", "Session Ready", "Don't let your mining session sit idle. Re-activate your session today!", "REWARD"]
            ];

            $stmtInsN = $pdo->prepare("INSERT INTO notifications (title, subtitle, message, category) VALUES (?, ?, ?, ?)");
            foreach ($notificationsList as $n) {
                $stmtInsN->execute([$n[0], $n[1], $n[2], $n[3]]);
            }
        }

    } catch (Exception $e) {
        error_log("Schema setup error: " . $e->getMessage());
    }
}

function getSystemSettings(PDO $pdo): array {
    static $cachedSettings = null;
    if ($cachedSettings !== null) {
        return $cachedSettings;
    }

    $out = [
        'mining_time'         => 86400,
        'mining_claim_amount' => 10.00000000,
        'referral_bonus'      => '10%',
        'maintenance_mode'    => 'false',
        'create_account'      => 'true'
    ];

    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
        while ($row = $stmt->fetch()) {
            $key = $row['setting_key'];
            $val = $row['setting_value'];
            if (is_numeric($val)) {
                $out[$key] = strpos($val, '.') !== false ? (float)$val : (int)$val;
            } else {
                $out[$key] = $val;
            }
        }
    } catch (Exception $e) {
        error_log("Failed reading system_settings: " . $e->getMessage());
    }

    $cachedSettings = $out;
    return $cachedSettings;
}

function checkMaintenance(PDO $pdo = null): void {
    if ($pdo === null) {
        $pdo = getDb();
    }
    $settings = getSystemSettings($pdo);
    $mMode = strtolower((string)($settings['maintenance_mode'] ?? 'false'));
    if ($mMode === 'true' || $mMode === '1') {
        jsonResponse('error', 'Skybridge Network is undergoing scheduled maintenance. Please check back shortly.', [
            'maintenance_mode' => true,
            'message' => 'Maintenance mode active'
        ], 503);
    }
}

function checkAccountCreation(PDO $pdo = null): void {
    if ($pdo === null) {
        $pdo = getDb();
    }
    $settings = getSystemSettings($pdo);
    $cAcc = strtolower((string)($settings['create_account'] ?? 'true'));
    if ($cAcc === 'false' || $cAcc === '0') {
        jsonResponse('error', 'New account registration is currently disabled by network settings.', [
            'create_account' => false
        ], 403);
    }
}

/**
 * Ensures user wallet exists and returns authoritative wallet data.
 * Fully links account_id, user_id, and email.
 */
function getOrCreateUserWallet(PDO $pdo, string $accountId): array {
    $stmt = $pdo->prepare("SELECT * FROM user_wallets WHERE account_id = ? LIMIT 1");
    $stmt->execute([$accountId]);
    $wallet = $stmt->fetch();

    if (!$wallet) {
        // Look up user details to link account_id, user_id, and email
        $stmtU = $pdo->prepare("SELECT user_id, email FROM users WHERE account_id = ? LIMIT 1");
        $stmtU->execute([$accountId]);
        $user = $stmtU->fetch();

        $userId = $user['user_id'] ?? ('SB_' . substr(md5($accountId), 0, 8));
        $email = $user['email'] ?? ($accountId . '@skybridge.app');

        $stmtIns = $pdo->prepare("INSERT IGNORE INTO user_wallets (account_id, user_id, email, current_balance, total_incoming, total_outgoing, lifetime_total_earned) VALUES (?, ?, ?, 0, 0, 0, 0)");
        $stmtIns->execute([$accountId, $userId, $email]);

        $stmt = $pdo->prepare("SELECT * FROM user_wallets WHERE account_id = ? LIMIT 1");
        $stmt->execute([$accountId]);
        $wallet = $stmt->fetch();
    }

    return $wallet ?: [
        'account_id'            => $accountId,
        'user_id'               => $user['user_id'] ?? '',
        'email'                 => $user['email'] ?? '',
        'current_balance'       => '0.00000000',
        'total_incoming'        => '0.00000000',
        'total_outgoing'        => '0.00000000',
        'lifetime_total_earned' => '0.00000000'
    ];
}

/**
 * Records wallet transaction ledger entry.
 */
function recordWalletLedger(PDO $pdo, string $accountId, string $type, float $amount, float $balanceBefore, float $balanceAfter, ?string $refId = null, ?string $desc = null): void {
    $stmt = $pdo->prepare("INSERT INTO wallet_ledger (account_id, transaction_type, amount, balance_before, balance_after, reference_id, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$accountId, $type, $amount, $balanceBefore, $balanceAfter, $refId, $desc]);
}

function jsonResponse(string $status, string $message, $data = null, int $httpCode = 200): void {
    http_response_code($httpCode);
    $payload = [
        'status'    => $status,
        'success'   => ($status === 'success'),
        'message'   => $message,
        'data'      => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function sanitizeInput($data): string {
    if ($data === null) return '';
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

function generateUserId(PDO $pdo): string {
    do {
        $userId = 'SB' . strtoupper(bin2hex(random_bytes(4)));
        $stmt = $pdo->prepare("SELECT id FROM users WHERE user_id = ? LIMIT 1");
        $stmt->execute([$userId]);
    } while ($stmt->fetch());
    return $userId;
}

function generateAccountId(PDO $pdo): string {
    do {
        $num = mt_rand(100000, 999999);
        $accountId = 'SKY-' . $num;
        $stmt = $pdo->prepare("SELECT id FROM users WHERE account_id = ? LIMIT 1");
        $stmt->execute([$accountId]);
    } while ($stmt->fetch());
    return $accountId;
}

function generateReferralCode(PDO $pdo): string {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
        $code = '';
        for ($i = 0; $i < 6; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ? LIMIT 1");
        $stmt->execute([$code]);
    } while ($stmt->fetch());
    return $code;
}
?>
