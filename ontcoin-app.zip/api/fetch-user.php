<?php
// Skybridge Fetch User Profile & Authoritative Wallet Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$searchKey = sanitizeInput($input['account_id'] ?? $input['user_id'] ?? $input['email'] ?? $input['search'] ?? '');

if (empty($searchKey)) {
    jsonResponse('error', 'Account ID, User ID, or Email is required.', null, 400);
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE account_id = ? OR user_id = ? OR email = ? LIMIT 1");
$stmt->execute([$searchKey, $searchKey, $searchKey]);
$user = $stmt->fetch();

if (!$user) {
    jsonResponse('error', 'User account not found.', null, 404);
}

// Read authoritative wallet data from user_wallets (Linked with account_id, user_id, email)
$wallet = getOrCreateUserWallet($pdo, $user['account_id']);

// Read system settings
$settings = getSystemSettings($pdo);

$mMode = strtolower((string)($settings['maintenance_mode'] ?? 'false'));
$isMaintenance = ($mMode === 'true' || $mMode === '1');

$cAcc = strtolower((string)($settings['create_account'] ?? 'true'));
$canCreateAccount = ($cAcc === 'true' || $cAcc === '1');

jsonResponse('success', 'User profile retrieved successfully.', [
    'id'                     => (int)$user['id'],
    'account_id'             => $user['account_id'],
    'user_id'                => $user['user_id'],
    'email'                  => $user['email'],
    'display_name'           => $user['display_name'],
    'avatar'                 => $user['avatar'] ?? '',
    'referral_code'          => $user['referral_code'],
    'referred_by'            => $user['referred_by'] ?? '',
    'account_status'         => $user['account_status'],
    'verification_status'    => $user['verification_status'] ?? 'VERIFIED',
    'mainnet_wallet_address' => $user['mainnet_wallet_address'] ?? null,
    'current_balance'        => (float)$wallet['current_balance'],
    'lifetime_total_earned'  => (float)$wallet['lifetime_total_earned'],
    'total_incoming'         => (float)$wallet['total_incoming'],
    'total_outgoing'         => (float)$wallet['total_outgoing'],
    'created_at'             => $user['created_at'],
    'system_settings'        => [
        'mining_time'         => (int)($settings['mining_time'] ?? 86400),
        'mining_claim_amount' => (float)($settings['mining_claim_amount'] ?? 10.0),
        'referral_bonus'      => (string)($settings['referral_bonus'] ?? '10%'),
        'maintenance_mode'    => $isMaintenance,
        'create_account'      => $canCreateAccount
    ]
]);
?>
