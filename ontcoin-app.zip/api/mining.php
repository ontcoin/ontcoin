<?php
// Skybridge Network Server-Authoritative Mining Engine
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$accountId = sanitizeInput($input['account_id'] ?? '');
$action = sanitizeInput($input['action'] ?? 'status');

if (empty($accountId)) {
    jsonResponse('error', 'Account ID is required.', null, 400);
}

// Ensure account identity exists
$stmtUser = $pdo->prepare("SELECT id, user_id, email, display_name, referral_code, referred_by FROM users WHERE account_id = ? LIMIT 1");
$stmtUser->execute([$accountId]);
$user = $stmtUser->fetch();

if (!$user) {
    jsonResponse('error', 'User account not found.', null, 404);
}

$settings = getSystemSettings($pdo);
$miningDurationSecs = (int)($settings['mining_time'] ?? 86400);
$miningDurationHours = max(1, (int)round($miningDurationSecs / 3600));
$baseMiningRate = (float)($settings['mining_claim_amount'] ?? 10.0);

$refPctStr = (string)($settings['referral_bonus'] ?? '10%');
$referralPercentage = (float)str_replace('%', '', $refPctStr);

// Get authoritative wallet record linked with account_id, user_id, email
$wallet = getOrCreateUserWallet($pdo, $accountId);

if ($action === 'status') {
    $stmtSess = $pdo->prepare("SELECT * FROM mining_sessions WHERE account_id = ? AND status IN ('ACTIVE', 'EXPIRED') ORDER BY id DESC LIMIT 1");
    $stmtSess->execute([$accountId]);
    $session = $stmtSess->fetch();

    $now = new DateTime('now', new DateTimeZone('UTC'));
    $isMining = false;
    $canClaim = false;
    $timeRemainingSecs = 0;
    $minedAmount = 0.0;

    if ($session) {
        $expiresAt = new DateTime($session['expires_at'], new DateTimeZone('UTC'));
        if ($session['status'] === 'ACTIVE' && $now < $expiresAt) {
            $isMining = true;
            $timeRemainingSecs = max(0, $expiresAt->getTimestamp() - $now->getTimestamp());
            $minedAmount = (float)$session['mined_amount'];
        } else {
            $isMining = false;
            $canClaim = ($session['status'] !== 'CLAIMED');
            $timeRemainingSecs = 0;
            $minedAmount = (float)$session['mined_amount'];
            
            if ($session['status'] === 'ACTIVE') {
                $stmtUpd = $pdo->prepare("UPDATE mining_sessions SET status = 'EXPIRED' WHERE id = ?");
                $stmtUpd->execute([$session['id']]);
            }
        }
    }

    jsonResponse('success', 'Mining status retrieved.', [
        'account_id'          => $accountId,
        'user_id'             => $user['user_id'],
        'email'               => $user['email'],
        'is_mining'           => $isMining,
        'can_claim'           => $canClaim,
        'time_remaining'      => $timeRemainingSecs,
        'current_mined'       => $minedAmount,
        'mining_rate'         => $baseMiningRate,
        'duration_hours'      => $miningDurationHours,
        'current_balance'     => (float)$wallet['current_balance'],
        'lifetime_earned'     => (float)$wallet['lifetime_total_earned'],
        'session_id'          => $session['id'] ?? null
    ]);
}

if ($action === 'start_mining') {
    $stmtSess = $pdo->prepare("SELECT id, expires_at, status FROM mining_sessions WHERE account_id = ? AND status = 'ACTIVE' ORDER BY id DESC LIMIT 1");
    $stmtSess->execute([$accountId]);
    $activeSess = $stmtSess->fetch();

    $now = new DateTime('now', new DateTimeZone('UTC'));

    if ($activeSess) {
        $expiresAt = new DateTime($activeSess['expires_at'], new DateTimeZone('UTC'));
        if ($now < $expiresAt) {
            $remaining = $expiresAt->getTimestamp() - $now->getTimestamp();
            jsonResponse('error', 'A mining session is already active.', [
                'is_mining' => true,
                'time_remaining' => $remaining
            ], 400);
        }
    }

    $sessionToken = 'SESS_' . bin2hex(random_bytes(8));
    $startedAtStr = $now->format('Y-m-d H:i:s');
    $expiresAtStr = (clone $now)->modify("+{$miningDurationSecs} seconds")->format('Y-m-d H:i:s');

    $stmtIns = $pdo->prepare("INSERT INTO mining_sessions (account_id, session_token, started_at, expires_at, mined_amount, status) VALUES (?, ?, ?, ?, ?, 'ACTIVE')");
    $stmtIns->execute([$accountId, $sessionToken, $startedAtStr, $expiresAtStr, $baseMiningRate]);
    $sessionId = $pdo->lastInsertId();

    jsonResponse('success', 'Mining session started successfully.', [
        'account_id'     => $accountId,
        'session_id'     => $sessionId,
        'is_mining'      => true,
        'time_remaining' => $miningDurationSecs,
        'mined_amount'   => $baseMiningRate,
        'expires_at'     => $expiresAtStr
    ]);
}

if ($action === 'claim') {
    $stmtSess = $pdo->prepare("SELECT * FROM mining_sessions WHERE account_id = ? AND status IN ('ACTIVE', 'EXPIRED') ORDER BY id DESC LIMIT 1");
    $stmtSess->execute([$accountId]);
    $session = $stmtSess->fetch();

    if (!$session) {
        jsonResponse('error', 'No claimable mining session found.', null, 404);
    }

    $now = new DateTime('now', new DateTimeZone('UTC'));
    $expiresAt = new DateTime($session['expires_at'], new DateTimeZone('UTC'));

    if ($now < $expiresAt && $session['status'] === 'ACTIVE') {
        $remaining = $expiresAt->getTimestamp() - $now->getTimestamp();
        jsonResponse('error', 'Mining session is still in progress.', [
            'time_remaining' => $remaining
        ], 400);
    }

    if ($session['status'] === 'CLAIMED') {
        jsonResponse('error', 'This mining reward has already been claimed.', null, 400);
    }

    $claimAmount = (float)$session['mined_amount'];
    if ($claimAmount <= 0) {
        $claimAmount = $baseMiningRate;
    }

    // ATOMIC TRANSACTION FOR WALLET UPDATE & LEDGER RECORDING
    $pdo->beginTransaction();
    try {
        $wallet = getOrCreateUserWallet($pdo, $accountId);
        $balBefore = (float)$wallet['current_balance'];
        $balAfter = $balBefore + $claimAmount;
        $totalInc = (float)$wallet['total_incoming'] + $claimAmount;
        $lifetime = (float)$wallet['lifetime_total_earned'] + $claimAmount;

        // Update user_wallets (linked with account_id, user_id, email)
        $stmtWupd = $pdo->prepare("UPDATE user_wallets SET current_balance = ?, total_incoming = ?, lifetime_total_earned = ?, user_id = ?, email = ? WHERE account_id = ?");
        $stmtWupd->execute([$balAfter, $totalInc, $lifetime, $user['user_id'], $user['email'], $accountId]);

        // Mark session CLAIMED
        $nowStr = $now->format('Y-m-d H:i:s');
        $stmtSUpd = $pdo->prepare("UPDATE mining_sessions SET status = 'CLAIMED', claimed_at = ? WHERE id = ?");
        $stmtSUpd->execute([$nowStr, $session['id']]);

        // Write to wallet_ledger
        recordWalletLedger($pdo, $accountId, 'MINING_CLAIM', $claimAmount, $balBefore, $balAfter, (string)$session['id'], '24-Hour Network Mining Claim');

        // Process Referral Commission directly to user_wallets if referred
        if (!empty($user['referred_by'])) {
            $stmtRefBy = $pdo->prepare("SELECT account_id FROM users WHERE id = ? OR referral_code = ? OR account_id = ? LIMIT 1");
            $stmtRefBy->execute([$user['referred_by'], $user['referred_by'], $user['referred_by']]);
            $inviterAccountId = $stmtRefBy->fetchColumn();

            if ($inviterAccountId) {
                $refReward = $claimAmount * ($referralPercentage / 100.0);
                if ($refReward > 0) {
                    $invWallet = getOrCreateUserWallet($pdo, $inviterAccountId);
                    $invBalBefore = (float)$invWallet['current_balance'];
                    $invBalAfter = $invBalBefore + $refReward;
                    $invLifetime = (float)$invWallet['lifetime_total_earned'] + $refReward;
                    $invInc = (float)$invWallet['total_incoming'] + $refReward;

                    $stmtInvUpd = $pdo->prepare("UPDATE user_wallets SET current_balance = ?, total_incoming = ?, lifetime_total_earned = ? WHERE account_id = ?");
                    $stmtInvUpd->execute([$invBalAfter, $invInc, $invLifetime, $inviterAccountId]);

                    recordWalletLedger($pdo, $inviterAccountId, 'REFERRAL_REWARD', $refReward, $invBalBefore, $invBalAfter, (string)$session['id'], "Referral commission from {$accountId} claim");
                }
            }
        }

        $pdo->commit();

        jsonResponse('success', 'Mining reward claimed successfully.', [
            'account_id'       => $accountId,
            'user_id'          => $user['user_id'],
            'email'            => $user['email'],
            'claimed_amount'   => $claimAmount,
            'new_balance'      => $balAfter,
            'lifetime_earned'  => $lifetime,
            'is_mining'        => false,
            'can_claim'        => false
        ]);

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Mining claim transaction error: " . $e->getMessage());
        jsonResponse('error', 'Failed to process mining claim transaction. Please try again.', null, 500);
    }
}

jsonResponse('error', 'Invalid mining action specified.', null, 400);
?>
