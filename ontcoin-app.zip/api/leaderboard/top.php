<?php
require_once __DIR__ . '/../config.php';
$pdo = getDb();
checkMaintenance($pdo);

$period = sanitizeInput($_POST['period'] ?? $_GET['period'] ?? 'all_time');

try {
    $stmt = $pdo->query("
        SELECT 
            user_id,
            account_id,
            name,
            avatar AS profile_image,
            (mined_balance + referral_balance + bonus_balance) AS total_score
        FROM users
        WHERE status = 'active'
        ORDER BY total_score DESC
        LIMIT 50
    ");
    $miners = $stmt->fetchAll();

    $leaderboard = [];
    $rank = 1;
    foreach ($miners as $m) {
        $scoreVal = (float)$m['total_score'];
        $formattedScore = number_format($scoreVal, 2, '.', '') . ' sB';

        $leaderboard[] = [
            'rank'          => $rank++,
            'user_id'       => $m['user_id'],
            'account_id'    => $m['account_id'],
            'name'          => $m['name'] ?: 'Skybridge Miner',
            'profile_image' => $m['profile_image'] ?? '',
            'score'         => $formattedScore
        ];
    }

    jsonResponse('success', 'Leaderboard rankings retrieved successfully', $leaderboard);

} catch (Exception $e) {
    jsonResponse('error', 'Leaderboard error: ' . $e->getMessage(), null, 500);
}
?>
