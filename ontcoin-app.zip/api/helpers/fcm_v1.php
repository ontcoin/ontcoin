<?php
// ============================================================================
// Skybridge Network - Firebase Cloud Messaging (FCM) HTTP v1 Helper
// Architecture: Google OAuth2 Service Account JWT -> Bearer Token -> FCM v1 API
// ============================================================================

require_once __DIR__ . '/../config.php';

/**
 * Base64Url encode utility
 */
function fcm_base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

/**
 * Retrieves a valid Google OAuth2 access token for Firebase Messaging scope.
 * Caches token in temp file until 5 minutes before expiry.
 */
function getFcmAccessToken() {
    $cacheFile = sys_get_temp_dir() . '/skybridge_fcm_token_cache.json';

    if (file_exists($cacheFile)) {
        $cached = json_decode(@file_get_contents($cacheFile), true);
        if ($cached && isset($cached['access_token']) && isset($cached['expires_at'])) {
            if ($cached['expires_at'] > (time() + 300)) {
                return $cached['access_token'];
            }
        }
    }

    // Load Service Account JSON
    $candidates = [
        '/home/linexwar/service-account.json',
        dirname(__DIR__, 3) . '/service-account.json',
        dirname(__DIR__, 2) . '/service-account.json',
        __DIR__ . '/../../service-account.json',
        __DIR__ . '/../config/service-account.json',
        dirname(__DIR__, 1) . '/config/service-account.json'
    ];

    $saPath = null;
    foreach ($candidates as $path) {
        if (file_exists($path)) {
            $saPath = $path;
            break;
        }
    }

    if (!$saPath) {
        error_log("[FCM] Service account JSON not found in configured paths");
        return null;
    }

    $sa = json_decode(file_get_contents($saPath), true);
    if (!$sa || empty($sa['private_key']) || empty($sa['client_email'])) {
        error_log("[FCM] Invalid service account JSON content");
        return null;
    }

    // Build JWT Header & Payload
    $header = fcm_base64url_encode(json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]));

    $now = time();
    $payload = fcm_base64url_encode(json_encode([
        'iss'   => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600
    ]));

    $dataToSign = $header . '.' . $payload;
    $privateKey = openssl_pkey_get_private($sa['private_key']);
    if (!$privateKey) {
        error_log("[FCM] Failed to parse private key");
        return null;
    }

    $signature = '';
    $success = openssl_sign($dataToSign, $signature, $privateKey, OPENSSL_ALGO_SHA256);
    if (!$success) {
        error_log("[FCM] OpenSSL sign failed for JWT");
        return null;
    }

    $jwt = $dataToSign . '.' . fcm_base64url_encode($signature);

    // Exchange JWT for OAuth2 Access Token
    $postFields = http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion'  => $jwt
    ]);

    $opts = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n" .
                         "Content-Length: " . strlen($postFields) . "\r\n",
            'content' => $postFields,
            'timeout' => 15
        ]
    ];

    $context = stream_context_create($opts);
    $response = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);

    if (!$response) {
        error_log("[FCM] Token exchange HTTP request failed");
        return null;
    }

    $tokenData = json_decode($response, true);
    if (!isset($tokenData['access_token'])) {
        error_log("[FCM] Access token missing from response: " . $response);
        return null;
    }

    $accessToken = $tokenData['access_token'];
    $expiresIn = (int)($tokenData['expires_in'] ?? 3600);

    // Save to cache
    @file_put_contents($cacheFile, json_encode([
        'access_token' => $accessToken,
        'expires_at'   => $now + $expiresIn
    ]));

    return $accessToken;
}

/**
 * Dispatches an FCM HTTP v1 message
 *
 * @param array $messageStructure Structure matching FCM v1 message specification
 * @return array ['success' => bool, 'response' => string|array]
 */
function sendFcmV1Message($messageStructure) {
    $accessToken = getFcmAccessToken();
    if (!$accessToken) {
        return ['success' => false, 'error' => 'Unable to acquire FCM access token'];
    }

    $projectId = 'skybridgenetwork-369';
    $url = "https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send";

    $payload = json_encode(['message' => $messageStructure]);

    $opts = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Authorization: Bearer {$accessToken}\r\n" .
                         "Content-Type: application/json; UTF-8\r\n" .
                         "Content-Length: " . strlen($payload) . "\r\n",
            'content' => $payload,
            'timeout' => 15,
            'ignore_errors' => true
        ]
    ];

    $context = stream_context_create($opts);
    $response = @file_get_contents($url, false, $context);
    $resJson = json_decode($response, true) ?: ['raw' => $response];

    $isOk = isset($resJson['name']); // FCM returns {"name": "projects/.../messages/..."} on success

    return [
        'success'  => $isOk,
        'response' => $resJson
    ];
}

/**
 * Send push notification to a specific user by user_id
 */
function sendPushToUser($pdo, $userId, $title, $body, $dataPayload = [], $category = 'system') {
    // 1. Store in notifications table
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
            VALUES (?, ?, ?, ?, 0, NOW())
        ");
        $stmt->execute([$userId, $title, $body, $category]);
    } catch (Exception $e) {
        error_log("[FCM] Failed to insert notification: " . $e->getMessage());
    }

    // 2. Fetch user's FCM token
    $uStmt = $pdo->prepare("SELECT fcm_token FROM users WHERE id = ? LIMIT 1");
    $uStmt->execute([$userId]);
    $token = $uStmt->fetchColumn();

    if (!$token) {
        return ['success' => false, 'reason' => 'User has no registered FCM token'];
    }

    $stringData = [];
    foreach ($dataPayload as $k => $v) {
        $stringData[(string)$k] = (string)$v;
    }
    $stringData['click_action'] = 'FLUTTER_NOTIFICATION_CLICK';
    $stringData['type'] = $category;

    $message = [
        'token' => $token,
        'notification' => [
            'title' => $title,
            'body'  => $body
        ],
        'data' => $stringData,
        'android' => [
            'priority' => 'high',
            'notification' => [
                'channel_id' => 'skybridge_alerts',
                'sound'      => 'default',
                'default_sound' => true,
                'default_vibrate_timings' => true
            ]
        ]
    ];

    return sendFcmV1Message($message);
}

/**
 * Dispatches an FCM HTTP v1 message to a specific topic
 */
function sendFcmV1TopicMessage($topic, $title, $body, $dataPayload = [], $category = 'system') {
    $stringData = [];
    foreach ($dataPayload as $k => $v) {
        $stringData[(string)$k] = (string)$v;
    }
    $stringData['click_action'] = 'FLUTTER_NOTIFICATION_CLICK';
    $stringData['type'] = $category;

    $message = [
        'topic' => $topic,
        'notification' => [
            'title' => $title,
            'body'  => $body
        ],
        'data' => $stringData,
        'android' => [
            'priority' => 'high',
            'notification' => [
                'channel_id' => 'skybridge_alerts',
                'sound'      => 'default',
                'default_sound' => true,
                'default_vibrate_timings' => true
            ]
        ]
    ];

    return sendFcmV1Message($message);
}

/**
 * Broadcast push notification to all miners across main FCM topics ('all', 'all_miners', 'skybridge_miners')
 * and records notifications for active users in the database.
 */
function broadcastPushToAll($pdo, $title, $body, $dataPayload = [], $category = 'system') {
    $results = [];

    // 1. Dispatch to primary global topics
    $topics = ['all', 'all_miners', 'skybridge_miners'];
    foreach ($topics as $top) {
        $results[$top] = sendFcmV1TopicMessage($top, $title, $body, $dataPayload, $category);
    }

    // 2. Also send direct push to active registered user devices
    try {
        $tokensStmt = $pdo->query("SELECT id, fcm_token FROM users WHERE fcm_token IS NOT NULL AND fcm_token != '' AND account_status = 'active' LIMIT 100");
        $tokens = $tokensStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($tokens as $u) {
            sendPushToUser($pdo, $u['id'], $title, $body, $dataPayload, $category);
        }
    } catch (Exception $e) {
        error_log("[FCM] Direct token dispatch log: " . $e->getMessage());
    }

    // 3. Log broadcast entry into notifications table
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, target_topic, title, message, type, is_read, sent_at, created_at)
            VALUES (NULL, 'all', ?, ?, ?, 0, NOW(), NOW())
        ");
        $stmt->execute([$title, $body, $category]);
    } catch (Exception $e) {
        error_log("[FCM] Broadcast log insert error: " . $e->getMessage());
    }

    return [
        'success' => true,
        'topic_dispatches' => $results
    ];
}
