<?php
// ============================================================================
// Auth Helper: Bearer Token, Account Lookup & Status Enforcement
// ============================================================================

require_once __DIR__ . '/response.php';

function getBearerToken() {
    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER['Authorization']);
    } else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } else if (function_exists('apache_request_headers')) {
        $reqHeaders = apache_request_headers();
        $headers = $reqHeaders['Authorization'] ?? $reqHeaders['authorization'] ?? null;
    }
    
    if (!empty($headers)) {
        if (preg_match('/Bearer\s+(.*)$/i', $headers, $matches)) {
            return trim($matches[1]);
        }
        return trim($headers);
    }
    
    // Also check query param or post body for fallback
    return $_GET['token'] ?? $_POST['token'] ?? $_GET['user_id'] ?? $_POST['user_id'] ?? $_GET['search'] ?? $_POST['search'] ?? $_GET['account_id'] ?? $_POST['account_id'] ?? $_GET['email'] ?? $_POST['email'] ?? null;
}

function getAuthenticatedUser($pdo, $required = true) {
    $token = getBearerToken();
    if (empty($token)) {
        if ($required) {
            jsonFail('Authentication token is required', 401);
        }
        return null;
    }

    // Try finding by account_id, google_id, email, or numeric id
    $stmt = $pdo->prepare("
        SELECT u.*, w.mined_balance, w.claimable_balance, w.bonus_balance
        FROM users u
        LEFT JOIN wallets w ON w.user_id = u.id
        WHERE u.account_id = ? OR u.google_id = ? OR u.email = ? OR u.id = ?
        LIMIT 1
    ");
    $stmt->execute([$token, $token, $token, is_numeric($token) ? (int)$token : -1]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        if ($required) {
            jsonFail('Invalid or expired authentication session', 401);
        }
        return null;
    }

    // Enforce account status: active, suspended, banned
    if ($user['account_status'] === 'banned') {
        jsonFail('Your Skybridge account has been permanently banned due to policy violation.', 403, [
            'account_status' => 'banned'
        ]);
    }
    if ($user['account_status'] === 'suspended') {
        jsonFail('Your Skybridge account is temporarily suspended. Please contact support.', 403, [
            'account_status' => 'suspended'
        ]);
    }

    return $user;
}
