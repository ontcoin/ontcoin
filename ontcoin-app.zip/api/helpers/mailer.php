<?php
// Skybridge Network Enterprise PHPMailer & Email Template Engine
declare(strict_types=1);

if (file_exists(__DIR__ . '/PHPMailer/Exception.php')) {
    require_once __DIR__ . '/PHPMailer/Exception.php';
    require_once __DIR__ . '/PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/SMTP.php';
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

define('SMTP_HOST', 'skybridge.linexware.net.ng');
define('SMTP_PORT', 465);
define('SMTP_USER', 'verify@skybridge.linexware.net.ng');
define('SMTP_PASS', 'Just09166388665j@');
define('SMTP_FROM_EMAIL', 'verify@skybridge.linexware.net.ng');
define('SMTP_FROM_NAME', 'Skybridge Network');

/**
 * Sends OTP Email with clean black/white Skybridge card styling.
 */
function sendSkybridgeOtpMail(string $toEmail, string $otp, string $subject = "Verify your login", int $expiryMinutes = 10): bool {
    // Format code as 1234-5678 or 123456
    $formattedCode = (strlen($otp) === 6) ? substr($otp, 0, 3) . '-' . substr($otp, 3) : $otp;

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #18181b;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f4f4f5; padding: 40px 16px;">
        <tr>
            <td align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; border: 1px solid #e4e4e7; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                    <tr>
                        <td style="padding: 36px 32px 12px 32px;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #09090b;">
                                        &#9632; Skybridge Network
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 24px 32px 36px 32px;">
                            <h1 style="margin: 0 0 16px 0; font-size: 26px; font-weight: 700; color: #09090b; letter-spacing: -0.5px;">Verify your login</h1>
                            <p style="margin: 0 0 24px 0; font-size: 15px; line-height: 1.5; color: #3f3f46;">
                                Below is your one time passcode:
                            </p>
                            
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom: 28px;">
                                <tr>
                                    <td align="left">
                                        <div style="font-size: 32px; font-weight: 800; letter-spacing: 2px; color: #09090b; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;">
                                            {$formattedCode}
                                        </div>
                                    </td>
                                </tr>
                            </table>

                            <p style="margin: 0 0 8px 0; font-size: 14px; line-height: 1.5; color: #52525b;">
                                We're here to help if you need it. Contact <a href="mailto:support@skybridge.linexware.net.ng" style="color: #09090b; font-weight: 600; text-decoration: underline;">Skybridge Support</a> for more info.
                            </p>

                            <p style="margin: 24px 0 0 0; font-size: 14px; color: #71717a;">
                                &mdash; Skybridge Security
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 20px 32px; background-color: #fafafa; border-top: 1px solid #f4f4f5; font-size: 12px; color: #a1a1aa;">
                            This automated message was sent to {$toEmail}. Code expires in {$expiryMinutes} minutes. Do not share this code with anyone.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;

    return sendViaPHPMailer($toEmail, $subject, $html);
}

/**
 * Sends Welcome Email to newly registered users.
 */
function sendWelcomeEmail(string $toEmail, string $displayName): bool {
    $subject = "Welcome to Skybridge Network";

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #18181b;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f4f4f5; padding: 40px 16px;">
        <tr>
            <td align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; border: 1px solid #e4e4e7; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                    <tr>
                        <td style="padding: 36px 32px 12px 32px;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #09090b;">
                                        &#9632; Skybridge Network
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 24px 32px 36px 32px;">
                            <h1 style="margin: 0 0 16px 0; font-size: 24px; font-weight: 700; color: #09090b; letter-spacing: -0.5px;">Welcome to Skybridge, {$displayName}</h1>
                            <p style="margin: 0 0 16px 0; font-size: 15px; line-height: 1.6; color: #3f3f46;">
                                Your account has been successfully created. You are now part of the Skybridge Network mining and airdrop ecosystem.
                            </p>
                            <p style="margin: 0 0 20px 0; font-size: 15px; line-height: 1.6; color: #3f3f46;">
                                Open the mobile app daily to start your 24-hour mining session, accumulate tokens, and invite friends to boost your mining rewards.
                            </p>
                            <p style="margin: 24px 0 0 0; font-size: 14px; color: #71717a;">
                                &mdash; The Skybridge Team
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 20px 32px; background-color: #fafafa; border-top: 1px solid #f4f4f5; font-size: 12px; color: #a1a1aa;">
                            &copy; 2026 Skybridge Network. Sent to {$toEmail}.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;

    return sendViaPHPMailer($toEmail, $subject, $html);
}

/**
 * Sends New Device Sign-in Notification Email.
 */
function sendNewDeviceLoginEmail(string $toEmail, string $displayName, string $deviceInfo, string $ipAddress): bool {
    $subject = "Security Alert: New Sign-in to Skybridge";
    $timeStr = date('Y-m-d H:i:s T');

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #18181b;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f4f4f5; padding: 40px 16px;">
        <tr>
            <td align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; border: 1px solid #e4e4e7; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                    <tr>
                        <td style="padding: 36px 32px 12px 32px;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #09090b;">
                                        &#9632; Skybridge Network
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 24px 32px 36px 32px;">
                            <h1 style="margin: 0 0 16px 0; font-size: 24px; font-weight: 700; color: #09090b; letter-spacing: -0.5px;">New device sign-in detected</h1>
                            <p style="margin: 0 0 20px 0; font-size: 15px; line-height: 1.6; color: #3f3f46;">
                                Hi {$displayName}, your Skybridge account was recently accessed from a new device.
                            </p>

                            <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #fafafa; border: 1px solid #f4f4f5; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                                <tr>
                                    <td style="font-size: 13px; color: #71717a; padding-bottom: 4px;">Device: <strong style="color: #18181b;">{$deviceInfo}</strong></td>
                                </tr>
                                <tr>
                                    <td style="font-size: 13px; color: #71717a; padding-bottom: 4px;">IP Address: <strong style="color: #18181b;">{$ipAddress}</strong></td>
                                </tr>
                                <tr>
                                    <td style="font-size: 13px; color: #71717a;">Time: <strong style="color: #18181b;">{$timeStr}</strong></td>
                                </tr>
                            </table>

                            <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #52525b;">
                                If this was you, no action is required. If you did not authorize this login, please update your passcode and contact support immediately.
                            </p>

                            <p style="margin: 24px 0 0 0; font-size: 14px; color: #71717a;">
                                &mdash; Skybridge Security
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 20px 32px; background-color: #fafafa; border-top: 1px solid #f4f4f5; font-size: 12px; color: #a1a1aa;">
                            &copy; 2026 Skybridge Network. Sent to {$toEmail}.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;

    return sendViaPHPMailer($toEmail, $subject, $html);
}

function sendViaPHPMailer(string $to, string $subject, string $htmlContent): bool {
    if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USER;
            $mail->Password   = SMTP_PASS;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Port 465 SSL
            $mail->Port       = SMTP_PORT;
            $mail->Timeout    = 15;
            $mail->CharSet    = 'UTF-8';

            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true
                ]
            ];

            $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
            $mail->addAddress($to);

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlContent;
            $mail->AltBody = strip_tags($htmlContent);

            return $mail->send();

        } catch (Exception $e) {
            error_log("PHPMailer Error: {$mail->ErrorInfo} | Exception: " . $e->getMessage());
        }
    }

    // Fallback socket mailer
    return sendSmtpSocketFallback($to, $subject, $htmlContent);
}

function sendSmtpSocketFallback(string $to, string $subject, string $htmlContent): bool {
    $host = SMTP_HOST;
    $port = SMTP_PORT;
    $user = SMTP_USER;
    $pass = SMTP_PASS;
    $from = SMTP_FROM_EMAIL;
    $fromName = SMTP_FROM_NAME;

    $timeout = 15;
    $socket = @fsockopen("ssl://{$host}", $port, $errno, $errstr, $timeout);

    if (!$socket) {
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$fromName} <{$from}>\r\n";
        return @mail($to, $subject, $htmlContent, $headers);
    }

    $readResponse = function() use ($socket) {
        $data = "";
        while ($str = fgets($socket, 515)) {
            $data .= $str;
            if (substr($str, 3, 1) == " ") break;
        }
        return $data;
    };

    $sendCommand = function(string $cmd) use ($socket, $readResponse) {
        fputs($socket, $cmd . "\r\n");
        return $readResponse();
    };

    $readResponse();
    $sendCommand("EHLO " . ($_SERVER['SERVER_NAME'] ?? 'skybridge.linexware.net.ng'));
    $sendCommand("AUTH LOGIN");
    $sendCommand(base64_encode($user));
    $authRes = $sendCommand(base64_encode($pass));

    if (strpos($authRes, '235') === false) {
        fclose($socket);
        return false;
    }

    $sendCommand("MAIL FROM: <{$from}>");
    $sendCommand("RCPT TO: <{$to}>");
    $sendCommand("DATA");

    $headers  = "From: {$fromName} <{$from}>\r\n";
    $headers .= "To: {$to}\r\n";
    $headers .= "Subject: {$subject}\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    $message = $headers . "\r\n" . $htmlContent . "\r\n.";
    $sendCommand($message);
    $sendCommand("QUIT");
    fclose($socket);
    return true;
}
?>
