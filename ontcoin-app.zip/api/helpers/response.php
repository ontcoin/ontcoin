<?php
// ============================================================================
// Response Helper: Standardized JSON Envelope
// Format: {"status":"success","success":true,"message":"...","data":{...},"timestamp":"..."}
// ============================================================================

function jsonOk($data = null, $message = 'Success', $httpCode = 200) {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'    => 'success',
        'success'   => true,
        'message'   => $message,
        'data'      => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function jsonFail($message = 'An error occurred', $httpCode = 400, $data = null) {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'    => 'error',
        'success'   => false,
        'message'   => $message,
        'data'      => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}
