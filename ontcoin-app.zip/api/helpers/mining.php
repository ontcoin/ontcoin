<?php
// ============================================================================
// Server-Authoritative Mining Engine Math Helper
// ============================================================================

function calculateMinedTokens($startedAt, $endsAt, $effectiveHashrate) {
    $startUnix = is_numeric($startedAt) ? (int)$startedAt : strtotime($startedAt);
    $endUnix   = is_numeric($endsAt) ? (int)$endsAt : strtotime($endsAt);
    $now       = time();

    if ($now <= $startUnix) {
        return 0.000000000000;
    }

    $elapsed = min($now, $endUnix) - $startUnix;
    if ($elapsed <= 0) {
        return 0.000000000000;
    }

    // Effective hashrate is in tokens per hour (e.g., 1.0000 SB/h)
    $tokensPerSecond = (float)$effectiveHashrate / 3600.0;
    $mined = $elapsed * $tokensPerSecond;
    return round($mined, 12);
}

function getUserActiveBoosterMultiplier($pdo, $userId) {
    $stmt = $pdo->prepare("
        SELECT mb.multiplier 
        FROM user_boosters ub
        JOIN mining_boosters mb ON mb.id = ub.booster_id
        WHERE ub.user_id = ? AND ub.status = 'active' AND ub.expires_at > NOW()
        ORDER BY mb.multiplier DESC
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $mult = $stmt->fetchColumn();
    return $mult ? (float)$mult : 1.0000;
}

function getActiveMiningSeason($pdo) {
    $stmt = $pdo->query("SELECT * FROM mining_seasons WHERE is_active = 1 AND end_time > NOW() ORDER BY season_number ASC LIMIT 1");
    $season = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$season) {
        // Fallback to season 1
        $stmt2 = $pdo->query("SELECT * FROM mining_seasons ORDER BY id ASC LIMIT 1");
        $season = $stmt2->fetch(PDO::FETCH_ASSOC);
    }
    return $season;
}

function getSystemSettings($pdo) {
    $stmt = $pdo->query("SELECT * FROM system_settings WHERE id = 1 LIMIT 1");
    $settings = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$settings) {
        return [
            'maintenance_mode' => 0,
            'base_hashrate' => 1.0000,
            'session_duration_hours' => 1,
            'min_withdrawal' => 50.0,
            'fcm_server_key' => '',
            'referral_commission_rate' => 0.1000,
            'direct_referral_bonus' => 25.0
        ];
    }
    return $settings;
}
