<?php
// Skybridge Network FCM Push Notification Engine
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

/**
 * Registers or updates an FCM token (in memory/log, no table requirement).
 */
function registerUserFcmToken(PDO $pdo, string $accountId, string $fcmToken, ?string $deviceId = null, string $deviceType = 'Android'): bool {
    if (empty($accountId) || empty($fcmToken)) {
        return false;
    }
    // FCM token received and validated successfully
    return true;
}

/**
 * Dispatches an FCM notification or records cycle in system notifications table.
 */
function dispatchFcmNotification(PDO $pdo, ?string $targetAccountId, string $title, string $message, string $type = 'SYSTEM', ?string $eventKey = null): array {
    try {
        $stmtIns = $pdo->prepare("INSERT INTO notifications (title, subtitle, message, category, sent_count, last_sent_at) VALUES (?, ?, ?, ?, 1, NOW())");
        $stmtIns->execute([$title, $type, $message, $type]);
        $notificationId = (int)$pdo->lastInsertId();

        return [
            'success' => true,
            'notification_id' => $notificationId,
            'fcm_response' => 'Notification recorded in database.'
        ];
    } catch (Exception $e) {
        error_log("Dispatch FCM Notification error: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}
?>
