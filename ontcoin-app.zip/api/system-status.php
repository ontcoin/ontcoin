<?php
// Skybridge System Status & Feeds Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
$settings = getSystemSettings($pdo);

$mMode = strtolower((string)($settings['maintenance_mode'] ?? 'false'));
$isMaintenance = ($mMode === 'true' || $mMode === '1');

$cAcc = strtolower((string)($settings['create_account'] ?? 'true'));
$canCreateAccount = ($cAcc === 'true' || $cAcc === '1');

$feeds = [
    [
        'id'          => 1,
        'title'       => 'Skybridge Network Mainnet Roadmap 2026',
        'category'    => 'ECOSYSTEM',
        'content'     => 'The Skybridge Network airdrop & mining phase is progressing rapidly toward token generation and decentralization.',
        'image_url'   => '',
        'published_at'=> date('Y-m-d H:i:s')
    ],
    [
        'id'          => 2,
        'title'       => 'Daily Mining & Referral Commission Mechanics',
        'category'    => 'GUIDE',
        'content'     => 'Activate your daily 24-hour mining session to earn tokens. Invite active friends with your referral ID to receive a 10% lifetime commission on every claim.',
        'image_url'   => '',
        'published_at'=> date('Y-m-d H:i:s')
    ]
];

jsonResponse('success', 'System status retrieved.', [
    'system_status' => $isMaintenance ? 'MAINTENANCE' : 'ONLINE',
    'maintenance_mode' => $isMaintenance,
    'create_account'   => $canCreateAccount,
    'feeds'         => $feeds,
    'system_settings' => [
        'mining_time'         => (int)($settings['mining_time'] ?? 86400),
        'mining_claim_amount' => (float)($settings['mining_claim_amount'] ?? 10.0),
        'referral_bonus'      => (string)($settings['referral_bonus'] ?? '10%'),
        'maintenance_mode'    => $isMaintenance,
        'create_account'      => $canCreateAccount
    ]
]);
?>
