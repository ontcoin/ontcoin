<?php
// Skybridge Register FCM Token Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/fcm.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$accountId = sanitizeInput($input['account_id'] ?? '');
$fcmToken = sanitizeInput($input['fcm_token'] ?? $input['token'] ?? '');
$deviceId = sanitizeInput($input['device_id'] ?? '');
$deviceType = sanitizeInput($input['device_type'] ?? 'Android');

if (empty($accountId) || empty($fcmToken)) {
    jsonResponse('error', 'Account ID and FCM Token are required.', null, 400);
}

$success = registerUserFcmToken($pdo, $accountId, $fcmToken, $deviceId, $deviceType);

if ($success) {
    jsonResponse('success', 'FCM token registered successfully.', [
        'account_id' => $accountId,
        'fcm_token'  => $fcmToken
    ]);
} else {
    jsonResponse('error', 'Failed to register FCM token.', null, 500);
}
?>
