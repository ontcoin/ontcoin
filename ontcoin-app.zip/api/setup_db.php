<?php
// Skybridge Database Auto-Installer & Schema Synchronizer
declare(strict_types=1);

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = getDb();

    // Read and execute skybridge.sql
    $sqlFile = __DIR__ . '/skybridge.sql';
    if (!file_exists($sqlFile)) {
        jsonResponse('error', 'skybridge.sql file missing.', null, 404);
    }

    $sql = file_get_contents($sqlFile);
    
    // Disable FK checks and execute queries
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
    $pdo->exec($sql);
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");

    // Fetch created tables
    $stmtTables = $pdo->query("SHOW TABLES");
    $tables = $stmtTables->fetchAll(PDO::FETCH_COLUMN);

    jsonResponse('success', 'Skybridge MySQL Schema synchronized successfully.', [
        'database' => DB_NAME,
        'tables_count' => count($tables),
        'tables' => $tables
    ]);

} catch (Exception $e) {
    jsonResponse('error', 'Database setup failed: ' . $e->getMessage(), null, 500);
}
?>
