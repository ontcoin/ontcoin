<?php
// Skybridge Email Login Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/mailer.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
$password = $input['password'] ?? '';

if (!$email || empty($password)) {
    jsonResponse('error', 'Email and password are required.', null, 400);
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
    jsonResponse('error', 'Invalid email address or password.', null, 401);
}

if ($user['account_status'] !== 'active') {
    jsonResponse('error', 'Account is suspended or inactive. Please contact support.', null, 403);
}

// Update login metadata
$ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$deviceInfo = sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'Android');

$stmtUpd = $pdo->prepare("UPDATE users SET last_ip = ?, last_login_at = NOW() WHERE id = ?");
$stmtUpd->execute([$ip, $user['id']]);

// Send New Device Login Email
sendNewDeviceLoginEmail($user['email'], $user['display_name'], $deviceInfo, $ip);

// Get authoritative wallet record
$wallet = getOrCreateUserWallet($pdo, $user['account_id']);

jsonResponse('success', 'Login successful.', [
    'account_id'          => $user['account_id'],
    'user_id'             => $user['user_id'],
    'email'               => $user['email'],
    'display_name'        => $user['display_name'],
    'avatar'              => $user['avatar'] ?? '',
    'referral_code'       => $user['referral_code'],
    'current_balance'     => (float)$wallet['current_balance'],
    'lifetime_total_earned' => (float)$wallet['lifetime_total_earned']
]);
?>
