<?php
// Skybridge OTP Verification & Account Finalization Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/mailer.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
$otpCode = sanitizeInput($input['otp'] ?? $input['otp_code'] ?? '');
$password = $input['password'] ?? '';
$name = sanitizeInput($input['name'] ?? $input['display_name'] ?? 'Skybridge Miner');
$referralCodeInput = sanitizeInput($input['referral_code'] ?? '');

if (!$email || empty($otpCode)) {
    jsonResponse('error', 'Email and 6-digit OTP code are required.', null, 400);
}

// Verify OTP code
$stmt = $pdo->prepare("SELECT * FROM email_verifications WHERE email = ? AND otp_code = ? AND is_used = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
$stmt->execute([$email, $otpCode]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    jsonResponse('error', 'Invalid or expired verification code. Please request a new code.', null, 400);
}

// Mark OTP as used
$stmtUpd = $pdo->prepare("UPDATE email_verifications SET is_used = 1 WHERE id = ?");
$stmtUpd->execute([$otpRecord['id']]);

// Find or create user account
$stmtU = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmtU->execute([$email]);
$user = $stmtU->fetch();
$isNewUser = false;

if (!$user) {
    checkAccountCreation($pdo);

    $isNewUser = true;
    $accountId = generateAccountId($pdo);
    $userId = generateUserId($pdo);
    $myReferralCode = generateReferralCode($pdo);
    $passwordHash = !empty($password) ? password_hash($password, PASSWORD_DEFAULT) : null;

    // Look up referrer if referral code provided
    $referrerAccountId = null;
    if (!empty($referralCodeInput)) {
        $stmtRef = $pdo->prepare("SELECT account_id FROM users WHERE referral_code = ? LIMIT 1");
        $stmtRef->execute([$referralCodeInput]);
        $refRow = $stmtRef->fetch();
        if ($refRow) {
            $referrerAccountId = $refRow['account_id'];
        }
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $deviceInfo = sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'Android');

    $stmtIns = $pdo->prepare("INSERT INTO users (account_id, user_id, email, password_hash, display_name, referral_code, referred_by, account_status, verification_status, registration_ip, last_ip, device_info, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', 'VERIFIED', ?, ?, ?, NOW())");
    $stmtIns->execute([$accountId, $userId, $email, $passwordHash, $name, $myReferralCode, $referrerAccountId, $ip, $ip, $deviceInfo]);

    $stmtU = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmtU->execute([$email]);
    $user = $stmtU->fetch();

    // Send Welcome Email
    sendWelcomeEmail($email, $name);
} else {
    // Mark verification_status = VERIFIED
    $stmtV = $pdo->prepare("UPDATE users SET verification_status = 'VERIFIED', last_login_at = NOW() WHERE id = ?");
    $stmtV->execute([$user['id']]);
}

// Ensure wallet exists linked with account_id, user_id, email
$wallet = getOrCreateUserWallet($pdo, $user['account_id']);

jsonResponse('success', 'Email verification successful.', [
    'account_id'          => $user['account_id'],
    'user_id'             => $user['user_id'],
    'email'               => $user['email'],
    'display_name'        => $user['display_name'],
    'referral_code'       => $user['referral_code'],
    'current_balance'     => (float)$wallet['current_balance'],
    'lifetime_total_earned' => (float)$wallet['lifetime_total_earned'],
    'is_new_user'         => $isNewUser
]);
?>
