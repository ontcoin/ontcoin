<?php
// Skybridge User Referral Dashboard Endpoint
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$pdo = getDb();
checkMaintenance($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$accountId = sanitizeInput($input['account_id'] ?? '');

if (empty($accountId)) {
    jsonResponse('error', 'Account ID is required.', null, 400);
}

// Fetch user referral code
$stmtU = $pdo->prepare("SELECT referral_code FROM users WHERE account_id = ? LIMIT 1");
$stmtU->execute([$accountId]);
$user = $stmtU->fetch();

if (!$user) {
    jsonResponse('error', 'User account not found.', null, 404);
}

// Fetch referred friends directly from users table
$stmtRef = $pdo->prepare("SELECT u.account_id, u.display_name, u.created_at FROM users u WHERE u.referred_by = ? OR u.referred_by = ? ORDER BY u.id DESC");
$stmtRef->execute([$accountId, $user['referral_code']]);
$friends = $stmtRef->fetchAll();

// Get total referral earnings from wallet_ledger
$stmtLed = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM wallet_ledger WHERE account_id = ? AND transaction_type = 'REFERRAL_REWARD'");
$stmtLed->execute([$accountId]);
$totalCommissions = (float)$stmtLed->fetchColumn();

$friendsList = [];
foreach ($friends as $f) {
    $friendsList[] = [
        'account_id'   => $f['account_id'],
        'display_name' => $f['display_name'] ?: 'Skybridge Miner',
        'joined_at'    => $f['created_at']
    ];
}

$settings = getSystemSettings($pdo);
$refBonus = (string)($settings['referral_bonus'] ?? '10%');

jsonResponse('success', 'Referral data retrieved.', [
    'account_id'          => $accountId,
    'referral_code'       => $user['referral_code'],
    'referral_bonus'      => $refBonus,
    'total_friends'       => count($friendsList),
    'total_commission'    => $totalCommissions,
    'friends'             => $friendsList
]);
?>
