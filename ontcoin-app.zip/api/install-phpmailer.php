<?php
// ============================================================================
// SkyBridge Network - PHPMailer Library Auto-Installer & Health Check
// URL: https://skybridge.linexware.net.ng/api/install-phpmailer.php
// ============================================================================

declare(strict_types=1);
ini_set('display_errors', '1');
error_reporting(E_ALL);

header('Content-Type: text/html; charset=utf-8');

$targetDir = __DIR__ . '/helpers/PHPMailer';
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

$filesNeeded = [
    'Exception.php'        => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/Exception.php',
    'PHPMailer.php'         => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/PHPMailer.php',
    'SMTP.php'              => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/SMTP.php',
    'POP3.php'              => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/POP3.php',
    'OAuth.php'             => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/OAuth.php',
    'OAuthTokenProvider.php'=> 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/OAuthTokenProvider.php',
    'DSNConfigurator.php'   => 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/DSNConfigurator.php'
];

$logs = [];
$successCount = 0;

foreach ($filesNeeded as $fileName => $downloadUrl) {
    $filePath = $targetDir . '/' . $fileName;
    if (file_exists($filePath) && filesize($filePath) > 500) {
        $logs[] = "<li style='color: #10b981;'><strong>✓ {$fileName}</strong>: Already installed (" . round(filesize($filePath)/1024, 1) . " KB)</li>";
        $successCount++;
        continue;
    }

    // Attempt download
    $opts = [
        'http' => [
            'method' => 'GET',
            'header' => "User-Agent: Mozilla/5.0 (Skybridge-Installer)\r\n"
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ];
    $ctx = stream_context_create($opts);
    $content = @file_get_contents($downloadUrl, false, $ctx);

    if ($content && strlen($content) > 500) {
        file_put_contents($filePath, $content);
        $logs[] = "<li style='color: #38bdf8;'><strong>✓ {$fileName}</strong>: Successfully downloaded and installed (" . round(strlen($content)/1024, 1) . " KB)</li>";
        $successCount++;
    } else {
        $logs[] = "<li style='color: #ef4444;'><strong>✗ {$fileName}</strong>: Failed downloading from remote source.</li>";
    }
}

// Test Class Loading
$classLoaded = false;
if (file_exists($targetDir . '/PHPMailer.php') && file_exists($targetDir . '/Exception.php') && file_exists($targetDir . '/SMTP.php')) {
    require_once $targetDir . '/Exception.php';
    require_once $targetDir . '/PHPMailer.php';
    require_once $targetDir . '/SMTP.php';
    $classLoaded = class_exists('PHPMailer\PHPMailer\PHPMailer');
}

// Test email if requested
$testResult = null;
if (isset($_GET['test_email'])) {
    $testTo = filter_var($_GET['test_email'], FILTER_VALIDATE_EMAIL);
    if ($testTo) {
        require_once __DIR__ . '/helpers/mailer.php';
        $sent = sendSkybridgeOtpMail($testTo, '123456', 'SkyBridge - PHPMailer Test Verification', 10);
        $testResult = $sent ? 'SUCCESS' : 'FAILED';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>SkyBridge PHPMailer Installer</title>
    <style>
        body { background-color: #0b0f19; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px 20px; }
        .card { max-width: 600px; margin: 0 auto; background-color: #111827; border: 1px solid #1f2937; border-radius: 16px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        h1 { color: #38bdf8; font-size: 22px; margin-top: 0; }
        ul { list-style: none; padding: 0; }
        li { padding: 8px 0; border-bottom: 1px solid #1f2937; font-size: 14px; font-family: monospace; }
        .badge { display: inline-block; padding: 6px 14px; border-radius: 8px; font-weight: bold; font-size: 13px; margin-top: 15px; }
        .badge-success { background: #065f46; color: #34d399; }
        .badge-fail { background: #7f1d1d; color: #f87171; }
        .btn { display: inline-block; margin-top: 20px; background: #38bdf8; color: #0b0f19; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 14px; }
    </style>
</head>
<body>
    <div class="card">
        <h1>⚡ SkyBridge PHPMailer Installer</h1>
        <p style="color: #9ca3af; font-size: 14px;">Target Directory: <code>/api/helpers/PHPMailer/</code></p>
        <ul>
            <?= implode('', $logs) ?>
        </ul>

        <?php if ($classLoaded): ?>
            <div class="badge badge-success">✓ PHPMailer Library is Fully Loaded &amp; Operational</div>
            <p style="font-size: 13px; color: #cbd5e1; margin-top: 15px;">
                Ready to dispatch OTP verification emails using SMTP credentials (<code>verify@skybridge.linexware.net.ng</code> on port 465 SSL).
            </p>
            <a href="test-smtp.php" class="btn">Run Diagnostic SMTP Test</a>
        <?php else: ?>
            <div class="badge badge-fail">✗ PHPMailer classes could not be initialized</div>
        <?php endif; ?>

        <?php if ($testResult): ?>
            <div style="margin-top: 20px; padding: 12px; background: #1e293b; border-radius: 8px;">
                <strong>Test Email Delivery:</strong> <?= $testResult ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
