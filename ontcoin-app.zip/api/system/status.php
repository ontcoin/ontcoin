<?php
require_once __DIR__ . '/../config.php';
$pdo = getDb();

try {
    $settings = getSystemSettings($pdo);

    $stmt = $pdo->query("
        SELECT id, title, category, content, image_url, external_url, created_at 
        FROM feeds 
        WHERE is_active = 1 
        ORDER BY id DESC 
        LIMIT 10
    ");
    $feeds = $stmt->fetchAll();

    jsonResponse('success', 'System status and feeds retrieved', [
        'maintenance_mode'       => (int)($settings['maintenance_mode'] ?? 0) === 1,
        'registration_enabled'   => (int)($settings['registration_enabled'] ?? 1) === 1,
        'mining_enabled'         => (int)($settings['mining_enabled'] ?? 1) === 1,
        'base_mining_rate'       => (float)($settings['base_mining_rate'] ?? 1.0000),
        'session_duration_hours' => (int)($settings['session_duration_hours'] ?? 25),
        'referral_percentage'    => (float)($settings['referral_percentage'] ?? 10.0),
        'season_name'            => $settings['season_name'] ?? 'Genesis Mining Pool',
        'season_pool_balance'    => (float)($settings['season_pool_balance'] ?? 10000000.00),
        'min_app_version'        => $settings['min_app_version'] ?? '1.0.0',
        'announcement_message'   => $settings['announcement_message'] ?? '',
        'feeds'                  => $feeds
    ]);

} catch (Exception $e) {
    jsonResponse('error', 'System status error: ' . $e->getMessage(), null, 500);
}
?>
