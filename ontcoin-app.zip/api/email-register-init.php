<?php
// Skybridge Email Registration Init (OTP Dispatch)
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers/mailer.php';

$pdo = getDb();
checkMaintenance($pdo);
checkAccountCreation($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse('error', 'Only POST method is allowed.', null, 405);
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? $_POST;

$email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
$password = $input['password'] ?? '';
$name = sanitizeInput($input['name'] ?? $input['display_name'] ?? 'Skybridge Miner');
$referralCodeInput = sanitizeInput($input['referral_code'] ?? '');

if (!$email) {
    jsonResponse('error', 'A valid email address is required.', null, 400);
}

if (strlen($password) < 6) {
    jsonResponse('error', 'Password must be at least 6 characters long.', null, 400);
}

// Check if user already exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    jsonResponse('error', 'An account with this email address already exists. Please log in.', null, 400);
}

// Generate 6-digit OTP
$otpCode = (string)random_int(100000, 999999);
$settings = getSystemSettings($pdo);
$expiryMins = (int)($settings['otp_expiry_minutes'] ?? 10);
$expiresAt = date('Y-m-d H:i:s', time() + ($expiryMins * 60));

// Invalidate previous OTPs for this email
$stmtDeact = $pdo->prepare("UPDATE email_verifications SET is_used = 1 WHERE email = ? AND otp_type = 'REGISTER'");
$stmtDeact->execute([$email]);

// Save new OTP
$stmtIns = $pdo->prepare("INSERT INTO email_verifications (email, otp_code, otp_type, expires_at) VALUES (?, ?, 'REGISTER', ?)");
$stmtIns->execute([$email, $otpCode, $expiresAt]);

// Dispatch OTP Email
$sent = sendSkybridgeOtpMail($email, $otpCode, "Verify your Skybridge registration", $expiryMins);

if ($sent) {
    jsonResponse('success', 'Verification code dispatched to your email.', [
        'email' => $email,
        'expires_in_minutes' => $expiryMins
    ]);
} else {
    jsonResponse('error', 'Failed to deliver verification code via email. Please check your address or try again.', null, 500);
}
?>
