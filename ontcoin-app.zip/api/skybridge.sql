-- ============================================================================
-- Skybridge Network SQL Schema
-- Relational Architecture with Linked Wallet & Pre-Seeded Notifications
-- Engine: InnoDB | Charset: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Drop legacy/obsolete tables
DROP TABLE IF EXISTS `user_balance_backups`;
DROP TABLE IF EXISTS `user_fcm_tokens`;
DROP TABLE IF EXISTS `referrals`;
DROP TABLE IF EXISTS `referral`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `system_settings`;

-- 1. Table: users (Identity Only)
CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id` VARCHAR(64) NOT NULL UNIQUE,
  `user_id` VARCHAR(64) NOT NULL UNIQUE,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NULL,
  `google_id` VARCHAR(128) NULL,
  `display_name` VARCHAR(128) NOT NULL DEFAULT 'Skybridge Miner',
  `avatar` VARCHAR(512) NULL,
  `referral_code` VARCHAR(32) NOT NULL UNIQUE,
  `referred_by` VARCHAR(64) NULL,
  `mainnet_wallet_address` VARCHAR(255) NULL,
  `account_status` ENUM('active', 'suspended', 'banned') NOT NULL DEFAULT 'active',
  `verification_status` ENUM('UNVERIFIED', 'VERIFIED') NOT NULL DEFAULT 'VERIFIED',
  `registration_ip` VARCHAR(45) NULL,
  `last_ip` VARCHAR(45) NULL,
  `device_info` TEXT NULL,
  `last_login_at` DATETIME NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_account_id` (`account_id`),
  INDEX `idx_users_referral_code` (`referral_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Table: user_wallets (Linked with account_id, user_id, email)
CREATE TABLE IF NOT EXISTS `user_wallets` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id` VARCHAR(64) NOT NULL UNIQUE,
  `user_id` VARCHAR(64) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `current_balance` DECIMAL(24, 8) NOT NULL DEFAULT 0.00000000,
  `total_incoming` DECIMAL(24, 8) NOT NULL DEFAULT 0.00000000,
  `total_outgoing` DECIMAL(24, 8) NOT NULL DEFAULT 0.00000000,
  `lifetime_total_earned` DECIMAL(24, 8) NOT NULL DEFAULT 0.00000000,
  `last_updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_uw_account_id` (`account_id`),
  INDEX `idx_uw_user_id` (`user_id`),
  INDEX `idx_uw_email` (`email`),
  CONSTRAINT `fk_uw_users` FOREIGN KEY (`account_id`) REFERENCES `users` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Table: wallet_ledger
CREATE TABLE IF NOT EXISTS `wallet_ledger` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id` VARCHAR(64) NOT NULL,
  `transaction_type` ENUM('MINING_CLAIM', 'REFERRAL_REWARD', 'BONUS', 'ADJUSTMENT', 'WITHDRAWAL') NOT NULL,
  `amount` DECIMAL(24, 8) NOT NULL,
  `balance_before` DECIMAL(24, 8) NOT NULL,
  `balance_after` DECIMAL(24, 8) NOT NULL,
  `reference_id` VARCHAR(128) NULL,
  `description` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_wl_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Table: mining_sessions
CREATE TABLE IF NOT EXISTS `mining_sessions` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id` VARCHAR(64) NOT NULL,
  `session_token` VARCHAR(64) NOT NULL,
  `started_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL,
  `mined_amount` DECIMAL(24, 8) NOT NULL DEFAULT 10.00000000,
  `status` ENUM('ACTIVE', 'EXPIRED', 'CLAIMED') NOT NULL DEFAULT 'ACTIVE',
  `notified` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ms_account` (`account_id`),
  INDEX `idx_ms_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Table: notifications (15 Pre-Seeded Messages with title, subtitle, and message)
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `subtitle` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `category` VARCHAR(64) DEFAULT 'SYSTEM',
  `sent_count` INT UNSIGNED DEFAULT 0,
  `last_sent_at` DATETIME NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Table: email_verifications
CREATE TABLE IF NOT EXISTS `email_verifications` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(191) NOT NULL,
  `account_id` VARCHAR(64) NULL,
  `otp_code` VARCHAR(10) NOT NULL,
  `otp_type` ENUM('REGISTER', 'LOGIN', 'RESET') NOT NULL DEFAULT 'REGISTER',
  `expires_at` DATETIME NOT NULL,
  `is_used` TINYINT(1) DEFAULT 0,
  `attempts` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ev_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Table: system_settings
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key` VARCHAR(64) PRIMARY KEY,
  `setting_value` TEXT NOT NULL,
  `description` VARCHAR(255) NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed 15 Random Engaging Notifications
INSERT INTO `notifications` (`id`, `title`, `subtitle`, `message`, `category`) VALUES
(1, 'Welcome to Skybridge', 'Node Initialization', 'Start your daily 24-hour mining cycle to accumulate tokens continuously.', 'WELCOME'),
(2, 'Genesis Mining Pool', 'Hashrate Update', 'Global network hashrate is growing rapidly. Keep your session active!', 'MINING'),
(3, 'Daily Token Reward', 'Session Expired', 'Your 24-hour mining cycle has ended. Claim your tokens now.', 'REWARD'),
(4, 'Airdrop Phase 1', 'Ecosystem Milestone', 'Over 50,000 miners have joined the Skybridge ecosystem.', 'ECOSYSTEM'),
(5, 'Referral Bonus Active', 'Hashrate Boost', 'Invite active friends with your referral ID and earn a 10% bonus.', 'REFERRAL'),
(6, 'Security Alert', 'Protect Your Account', 'Enable passcode lock and biometrics in settings to secure your tokens.', 'SECURITY'),
(7, 'Network Upgrade', 'System Performance', 'Server infrastructure updated for instant claim settlements.', 'SYSTEM'),
(8, '1,000,000 Tokens Claimed', 'Community Milestone', 'Skybridge mining pool total tokens claimed passed 1,000,000.', 'ECOSYSTEM'),
(9, 'Mainnet Roadmap', 'Distribution Preview', 'Token generation event and mainnet wallet distribution preview released.', 'ROADMAP'),
(10, 'Hashrate Distribution', 'Node Synchronization', 'Daily node rewards distributed across all active miners.', 'MINING'),
(11, 'Squad Bonus Commission', 'Wallet Updated', 'Your squad member claimed rewards. Check your referral bonus balance.', 'REFERRAL'),
(12, 'Security Checklist', 'Account Safeguards', 'Always keep your email and login credentials secure.', 'SECURITY'),
(13, 'Leaderboard Update', 'Top Rankings', 'Check the global leaderboard to see the top Skybridge miners.', 'RANKING'),
(14, 'Ecosystem News', 'Roadmap Feeds', 'Read the latest roadmap news and developments in the Feeds tab.', 'NEWS'),
(15, 'Daily Claim Reminder', 'Session Ready', 'Don\'t let your mining session sit idle. Re-activate your session today!', 'REWARD');

-- Seed System Settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `description`) VALUES
('mining_time', '86400', 'Mining session duration in seconds'),
('mining_claim_amount', '10.00000000', 'Total amount to be claimed on every mining session'),
('referral_bonus', '10%', 'Referral bonus percentage'),
('maintenance_mode', 'false', 'Maintenance mode true or false'),
('create_account', 'true', 'Account creation enabled true or false');

SET FOREIGN_KEY_CHECKS = 1;
