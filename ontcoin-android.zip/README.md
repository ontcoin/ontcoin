# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.

## Ads: real WebView ad screen (app 3.0.1) - no ad SDK
- Start.io is gone. Ads are smart links shown by `AdOverlay.kt`: a FULL-SCREEN layer (no rounded corners) with a standard WebView (JavaScript, DOM storage, cookies + third-party cookies, pop-ups, redirects, downloads, intent:// / market:// links).
- Look: status-bar area painted in the app theme (white in light mode, dark in dark mode, icons to match); soft purple progress bar, full screen width, 4.5 dp, centred on the line between the status bar and the ad with no gap (one segment per link); small countdown ring top right that turns into a Close X; tiny translucent purple "Ad" tag bottom left.
- The web app decides WHAT and WHEN (links and seconds: top of `OT.adv` in the web `index.src.html`); the app only shows it:
  - `Android.hasAdView()` / `Android.showAdView(token, kind, urlsJson, secsJson)` -> `OTBridge.onAdResult(token, "showing" | "closed" | "failed" | "busy" | "offline")`.
  - App-open ad: `MainActivity.onResume` sends `OTBridge.onAppResume(awayMs)` when the user was away 2 s or more (not after camera / picker / permission / Play-update screens). The web app shows it only on the dashboard (5 s).
  - Interstitial (web app): after every 5th screen opened, 8 s. Rewarded (web app): Start mining / Claim = 3 links (1, 2, 1 again), 7 s each.
- The countdown of each link starts only when its page has FULLY loaded (onPageFinished; after 12 s at the latest). A new WebView is used for every link; the old one is stopped, its history and cache cleared, and destroyed.
- No internet: the app answers "offline" and the web app does not give the reward. A link that fails while online is skipped quietly (no browser error page is ever shown).
- The app only allows HTTPS: an http:// hop inside an ad redirect chain is upgraded to https://. The ad page never gets the `Android` bridge. Close / Back are locked until the countdown ends.
- Bridge version 4. `AdOverlay` is protected in `proguard-rules.pro`. versionName 3.0.1 (versionCode comes from VERSION_CODE in gradle.properties; keep it HIGHER than the last build you uploaded to Play).

## 3.2 changes
- Passcode only after the app was closed: `MainActivity.sessionAlive` (reset in onDestroy when finishing) + bridge `isSessionAlive / setSessionAlive`. Reloads and WebView rebuilds keep you unlocked.
