# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.
