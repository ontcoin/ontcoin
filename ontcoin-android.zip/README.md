# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.

## Ads: real WebView ad screen (app 3.0.1) - no ad SDK
- Start.io is gone. Ads are smart links shown by `AdOverlay.kt`: a FULL-SCREEN layer (no rounded corners) with a standard WebView (JavaScript, DOM storage, cookies + third-party cookies, redirects).
- **The web app controls everything** (ad links, seconds, how many screens between ads, options). The app only shows what it is told, so it rarely needs an update. Links and options: top of `OT.adv` in the web `index.src.html`.
- Bridge (version 5): `Android.hasAdView()`, `Android.showAdViewV2(token, kind, urlsJson, secsJson, optsJson)` (older: `showAdView` without opts), `Android.warmUpAd(urlsJson)`  ->  `OTBridge.onAdResult(token, "showing" | "closed" | "failed" | "busy" | "offline")`. optsJson (all optional): `{"loadMaxMs":15000,"externalLinks":true,"upgradeHttp":true}`.
- **Links:** the ad link and its automatic redirects load INSIDE the ad WebView and are never touched. When the person TAPS something that leaves the ad page (another link, Play Store link, new tab, download) it opens OUTSIDE: Chrome tab (Play Store links open the Play Store app, intent:// / market:// open the phone's own app). `MainActivity.openAdLink`.
- **Loading:** a new WebView per link. The countdown starts only when the page is REALLY ready: page finished + no redirect for 0.7 s + something is drawn (text / image / video / frame). A page that stays blank is skipped quietly. `warmUpAd` resolves the ad host names and starts an empty WebView ahead of time (no ad page is requested or counted) so the next ad opens faster.
- Look: status-bar area in the app theme (white in light mode, dark in dark mode, icons to match); soft purple progress bar, full width, 4.5 dp, centred on the line between the status bar and the ad (one segment per link); small countdown ring top right that turns into a Close X; tiny translucent purple "Ad" tag bottom left.
- App-open ad: `MainActivity.onResume` sends `OTBridge.onAppResume(awayMs)` after 2 s or more away (not after camera / picker / permission / Play-update screens). Interstitial (every 5th screen, 8 s) and rewarded (3 links, 7 s each) are decided by the web app.
- **Internet:** the existing `NetworkMonitor` is used. No internet = no ad and no reward (answer "offline"); losing the internet during an ad also means no reward.
- The app only allows HTTPS: an http:// hop inside an ad redirect chain is upgraded to https://. The ad page never gets the `Android` bridge. Close / Back are locked until the countdown ends.
- `AdOverlay` is protected in `proguard-rules.pro`. versionName 3.0.1 (versionCode comes from VERSION_CODE in gradle.properties; keep it HIGHER than the last build you uploaded to Play).

## 3.2 changes
- Passcode only after the app was closed: `MainActivity.sessionAlive` (reset in onDestroy when finishing) + bridge `isSessionAlive / setSessionAlive`. Reloads and WebView rebuilds keep you unlocked.
