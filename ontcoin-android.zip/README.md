# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.

## Ads: real WebView ad screen (app 3.3) - no ad SDK
- Start.io is gone (SDK, init, permissions, AdsManager). Ads are smart links shown by `AdOverlay.kt`: a full-screen layer with a standard WebView
  (JavaScript, DOM storage, cookies + third-party cookies, pop-ups, redirects, downloads, intent:// / market:// links), split purple progress bar and a countdown ring that turns into Close.
- The web app decides WHAT and WHEN (links and seconds are at the top of `OT.adv` in the web `index.src.html`); the app only shows it:
  - `Android.hasAdView()` / `Android.showAdView(token, kind, urlsJson, secsJson)` -> `OTBridge.onAdResult(token, "showing" | "closed" | "failed" | "busy")`.
  - App-open ad: `MainActivity.onResume` sends `OTBridge.onAppResume(awayMs)` when the user was away 3 s or more (not after camera / picker / permission / Play-update screens). The web app shows it only on the dashboard.
  - Interstitial: web app, after every 4th screen (10 s). Rewarded: web app, Start mining (before) / Claim (after success) = two links, 10 s each.
- A new WebView is used for every link; the old one is stopped, its history and cache cleared, and destroyed. A link that fails to load is skipped quietly (no browser error page is ever shown).
- The app only allows HTTPS: an http:// hop inside an ad redirect chain is upgraded to https://.
- The ad page never gets the `Android` bridge. Close / Back are locked until the countdown ends.
- Bridge version 4. `NativeBridge.kt` and `AdOverlay.kt` are protected in `proguard-rules.pro`.

## 3.2 changes
- Passcode only after the app was closed: `MainActivity.sessionAlive` (reset in onDestroy when finishing) + bridge `isSessionAlive / setSessionAlive`. Reloads and WebView rebuilds keep you unlocked.
