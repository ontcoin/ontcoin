# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.

## Ads (Start.io, app 3.1)
- SDK `com.startapp:inapp-sdk:5.3.1`, App ID in `gradle.properties` (`STARTIO_APP_ID`). `STARTIO_TEST_ADS=true` = test ads only; set it to `false` for the live release.
- `AdsManager.kt`: rewarded video (asked by the web app via `Android.showRewardedAd`) and an interstitial on app resume (>= 3 s away, max one per 90 s in the live build (30 s with test ads), not in the first 45 s after opening and not within 60 s of a rewarded video, never after camera / picker / permission / Play-update screens).
- Bridge version 3: `hasAds()`, `showRewardedAd(token)` -> `OTBridge.onRewardedResult(token, status)`. App 3.0 has none of this and the web app then mines/claims as before.
