# OntCoin Android app

A thin native shell around the OntCoin web app (`https://ontcoin.linexware.net.ng/web/`): splash screen, offline dialog,
push notifications (Firebase), biometric lock, and the `Android` JavaScript bridge the web app calls.

- Package: `com.ontcoin.network.linexware`, minSdk 24, targetSdk 36
- `AppProof.kt` signs the `X-OT-App` header. `APP_SECRET` in `gradle.properties` must equal `OT_APP_SECRET` in the web `APIs/config.php`.
- `NativeBridge.kt` is protected from R8 renaming in `proguard-rules.pro`. Add a new bridge method there AND in the web app.

## Build on GitHub
1. Put this project (or this zip) in a **private** repository and add `.github/workflows/build.yml`.
2. Optional, safer: add repository secrets `KEYSTORE_BASE64` (`base64 -w0 app/build.jks`), `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `APP_SECRET`.
   If a secret is missing, the value in `gradle.properties` / `app/build.jks` is used.
3. Run the workflow. It builds the APK and AAB, checks they are signed with the key in `EXPECTED_SHA256.txt`, and checks Play Store requirements.

Back up `app/build.jks` and its passwords somewhere safe. If the key is lost, updates cannot be signed.

## Ads (Start.io, app 3.1) - LIVE
- SDK `com.startapp:inapp-sdk:5.3.1`, App ID in `gradle.properties` (`STARTIO_APP_ID`). `STARTIO_TEST_ADS=false` = live ads. Set it to `true` only to test with test ads.
- `AdsManager.kt`: rewarded video (asked by the web app via `Android.showRewardedAd`) and interstitials. The app never closes an ad: only the user does.
- Interstitial triggers (only when the user is signed in and inside the dashboard): (1) coming back to the app after leaving from the dashboard (away >= 5 s); (2) after every 3rd screen opened in the dashboard. Min 45 s between interstitials, none within 30 s of a rewarded video, none after camera / picker / permission / Play-update screens.
- Bridge version 3: `hasAds()`, `showRewardedAd(token)` -> `OTBridge.onRewardedResult`, `setAdScreen(bool)`, `showInterstitialAd()`. App 3.0 has none of this and the web app then mines/claims as before.


## 3.2 changes
- Passcode only after the app was closed: `MainActivity.sessionAlive` (reset in onDestroy when finishing) + bridge `isSessionAlive / setSessionAlive`. Reloads and WebView rebuilds keep you unlocked.
- Ads are gentler: an interstitial waits until the screen has not been touched for ~1.8 s, shows a "Short sponsor break - ad starts in 3" card that swallows taps, then the ad. Resume ad needs 20 s away. Skipped if the user is busy.
