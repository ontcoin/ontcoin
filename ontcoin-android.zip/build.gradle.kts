// Top-level build file.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.google.services) apply false
  // Not used for UI. It only pins the Kotlin compiler version (2.2.10) that the Android plugin's built-in Kotlin support uses.
  alias(libs.plugins.kotlin.compose) apply false
}
