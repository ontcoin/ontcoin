# ProGuard/R8 Rules for OntCoin Production App

# Keep the WebView JavaScript bridge (window.Android) exactly as the web app calls it
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.example.NativeBridge { *; }

# Keep line numbers for crash debugging
-keepattributes SourceFile,LineNumberTable

# Firebase Messaging & Services
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class com.example.OntCoinFirebaseMessagingService { *; }

# Biometrics
-keep class androidx.biometric.** { *; }

# Custom Tabs
-keep class androidx.browser.customtabs.** { *; }

# Google Play In-App Updates
-keep class com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**

# Start.io (StartApp) SDK
-keep class com.startapp.** { *; }
-keep class com.truenet.** { *; }
-keepattributes Exceptions, InnerClasses, Signature, Deprecated, SourceFile, LineNumberTable, *Annotation*, EnclosingMethod
-dontwarn android.webkit.JavascriptInterface
-dontwarn com.startapp.**
-dontwarn org.jetbrains.annotations.**
-keep class com.example.AdsManager { *; }

# Google Advertising ID (read by Start.io)
-keep class com.google.android.gms.ads.identifier.AdvertisingIdClient { *; }
-keep class com.google.android.gms.ads.identifier.AdvertisingIdClient$Info { *; }
-dontwarn com.google.android.gms.ads.identifier.**
