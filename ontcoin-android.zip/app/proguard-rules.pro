# ProGuard/R8 Rules for OntCoin Production App

# Keep the WebView JavaScript bridge (window.Android) exactly as the web app calls it
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.example.NativeBridge { *; }

# Keep line numbers for crash debugging
-keepattributes SourceFile,LineNumberTable

# Firebase Messaging & Services
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class com.example.OntCoinFirebaseMessagingService { *; }

# Biometrics
-keep class androidx.biometric.** { *; }

# Custom Tabs
-keep class androidx.browser.customtabs.** { *; }

# Google Play In-App Updates
-keep class com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**

# WebView ad screen (no ad SDK)
-keepattributes Exceptions, InnerClasses, Signature, Deprecated, SourceFile, LineNumberTable, *Annotation*, EnclosingMethod
-dontwarn android.webkit.JavascriptInterface
-dontwarn org.jetbrains.annotations.**
-keep class com.example.AdOverlay { *; }
