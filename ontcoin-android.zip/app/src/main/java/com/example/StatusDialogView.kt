package com.example

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Native copy of the web app's "No internet connection" dialog (same colours, radius, texts, buttons),
 * so a connection problem looks identical whether the web page is loaded yet or not.
 * It never shows URLs, error codes or WebView error pages.
 */
class StatusDialogView(context: Context, dark: Boolean) : FrameLayout(context) {

    var onClose: (() -> Unit)? = null
    var onRetry: (() -> Unit)? = null

    private val sheet = Color.parseColor(if (dark) "#14101D" else "#FFFFFF")
    private val ink = Color.parseColor(if (dark) "#F5F2FA" else "#0D0A14")
    private val muted = Color.parseColor(if (dark) "#8F86A0" else "#8B8597")
    private val roseBg = Color.parseColor(if (dark) "#40161F" else "#FFE0E6")
    private val rose = Color.parseColor(if (dark) "#FF8DA2" else "#CF2F4F")
    private val soft = Color.parseColor(if (dark) "#1E192A" else "#F1EFF5")
    private val btn = Color.parseColor(if (dark) "#FFFFFF" else "#0D0A14")
    private val btnInk = Color.parseColor(if (dark) "#0D0A14" else "#FFFFFF")

    private val card = LinearLayout(context)
    private val icon = ImageView(context)
    private val title = TextView(context)
    private val message = TextView(context)

    init {
        isClickable = true
        isFocusable = true
        setBackgroundColor(Color.parseColor("#8C0A0414")) // rgba(10,4,20,.55) like .dlgbg
        visibility = View.GONE

        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = roundRect(sheet, context.dp(30).toFloat())
        card.setPadding(context.dp(22), context.dp(26), context.dp(22), context.dp(20))
        card.elevation = context.dp(24).toFloat()

        val iconBox = FrameLayout(context)
        iconBox.background = roundRect(roseBg, context.dp(22).toFloat())
        icon.setColorFilter(rose)
        iconBox.addView(icon, FrameLayout.LayoutParams(context.dp(30), context.dp(30), Gravity.CENTER))
        card.addView(iconBox, LinearLayout.LayoutParams(context.dp(64), context.dp(64)))

        title.setTextColor(ink)
        title.textSize = 21f
        title.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        title.letterSpacing = -0.02f
        title.gravity = Gravity.CENTER
        card.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = context.dp(10); bottomMargin = context.dp(6)
        })

        message.setTextColor(muted)
        message.textSize = 14.5f
        message.gravity = Gravity.CENTER
        message.setLineSpacing(0f, 1.22f)
        card.addView(message, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = context.dp(18)
        })

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val close = button(context.getString(R.string.dlg_close), soft, ink) { onClose?.invoke() }
        val retry = button(context.getString(R.string.dlg_try_again), btn, btnInk) { onRetry?.invoke() }
        row.addView(close, LinearLayout.LayoutParams(0, context.dp(54), 1f).apply { rightMargin = context.dp(5) })
        row.addView(retry, LinearLayout.LayoutParams(0, context.dp(54), 1f).apply { leftMargin = context.dp(5) })
        card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val screenW = context.resources.displayMetrics.widthPixels
        val cardW = minOf(context.dp(360), screenW - context.dp(44))
        addView(card, LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    private fun button(label: String, bg: Int, fg: Int, click: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            setTextColor(fg)
            textSize = 16f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(46, 128, 128, 128)), roundRect(bg, context.dp(18).toFloat()), null)
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }

    /** offline = the phone has no connection; otherwise a generic "could not load" variant. */
    fun show(offline: Boolean) {
        icon.setImageResource(if (offline) R.drawable.ic_wifi_off else R.drawable.ic_alert)
        title.setText(if (offline) R.string.dlg_offline_title else R.string.dlg_error_title)
        message.setText(if (offline) R.string.dlg_offline_message else R.string.dlg_error_message)
        if (visibility == View.VISIBLE) return
        visibility = View.VISIBLE
        alpha = 0f
        animate().alpha(1f).setDuration(200L).start()
        card.scaleX = 0.9f; card.scaleY = 0.9f
        card.animate().scaleX(1f).scaleY(1f).setDuration(420L).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    fun hide() {
        animate().cancel()
        card.animate().cancel()
        visibility = View.GONE
    }

    val isShowing: Boolean get() = visibility == View.VISIBLE
}
