package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper

/**
 * Watches the phone's connectivity and reports changes (debounced) so the native side and the
 * web app always agree on whether the device is online.
 */
class NetworkMonitor(
    context: Context,
    private val onChange: (online: Boolean, type: String) -> Unit
) {
    private val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    @Volatile var online: Boolean = readOnline()
        private set
    @Volatile var type: String = readType()
        private set

    private val check = Runnable {
        val o = readOnline()
        val t = readType()
        val changed = o != online || t != type
        online = o
        type = t
        if (changed) onChange(o, t)
    }

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = schedule()
        override fun onLost(network: Network) = schedule()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = schedule()
    }

    private fun schedule() {
        main.removeCallbacks(check)
        main.postDelayed(check, 450L) // debounce wifi <-> mobile hand-over flicker
    }

    fun start() {
        if (started) return
        started = true
        try { cm.registerDefaultNetworkCallback(callback) } catch (_: Exception) { started = false }
    }

    fun stop() {
        main.removeCallbacks(check)
        if (!started) return
        started = false
        try { cm.unregisterNetworkCallback(callback) } catch (_: Exception) {}
    }

    /** Re-read right now (used before we decide to show an offline dialog). */
    fun refreshNow(): Boolean {
        online = readOnline()
        type = readType()
        return online
    }

    private fun caps(): NetworkCapabilities? = try {
        val n = cm.activeNetwork
        if (n == null) null else cm.getNetworkCapabilities(n)
    } catch (_: Exception) { null }

    private fun readOnline(): Boolean {
        val c = caps() ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun readType(): String {
        val c = caps() ?: return "none"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
            c.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "bluetooth"
            else -> "other"
        }
    }
}
