package com.example

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.view.*
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

/**
 * OntCoin ad screen: a full-screen layer with a REAL (standard) WebView that loads the ad links the web app sends.
 *
 *  - Web app asks:   Android.showAdView(token, kind, urlsJson, secsJson)      (NativeBridge -> MainActivity.showAdView)
 *  - App answers:    OTBridge.onAdResult(token, "showing" | "closed" | "failed" | "busy")
 *  - One WebView per link (a fresh one for every link; the old one is wiped: stopped, history + cache cleared, destroyed).
 *  - Standard WebView: JavaScript, DOM storage, cookies (+ third-party cookies), pop-ups / new tabs, redirect chains,
 *    downloads, intent:// and market:// links (handed to the phone). The ad page gets NO access to the OntCoin bridge.
 *  - Top: split purple progress bar (one segment per link) + countdown ring that turns into a Close button.
 *  - The countdown starts when the page has loaded (or after LOAD_MAX_MS) and pauses while the app is in the background.
 *  - Close / Back are locked until the countdown ends. A link that fails to load is skipped quietly: the person never sees an error page.
 */
object AdOverlay {
    private var cur: Overlay? = null
    private const val LOAD_MAX_MS = 8_000L

    fun isShowing() = cur != null

    /** cb(status): "showing" once on screen, then one final "closed" | "failed". "busy" when another ad is already open. */
    fun show(a: MainActivity, token: String, urlsJson: String, secsJson: String, cb: (String) -> Unit) {
        if (cur != null) { cb("busy"); return }
        try {
            val uj = JSONArray(urlsJson); val sj = JSONArray(secsJson)
            val urls = List(uj.length()) { uj.getString(it) }
            val secs = List(sj.length()) { sj.getInt(it).coerceIn(1, 120) }
            if (urls.isEmpty() || urls.size != secs.size || urls.any { !it.startsWith("https://", true) && !it.startsWith("http://", true) }) { cb("failed"); return }
            cur = Overlay(a, urls, secs, cb).also { it.start() }
        } catch (_: Exception) { cb("failed") }
    }

    /** First thing in the back-press handler: true = the press was used by the ad screen. */
    fun handleBack(): Boolean { val o = cur ?: return false; o.onBack(); return true }
    fun onPause() { cur?.setPaused(true) }
    fun onResume() { cur?.setPaused(false) }
    /** Activity is going away: remove everything, tell nobody. */
    fun dismiss() { cur?.destroyNow(report = false) }

    private class Overlay(val a: MainActivity, val urls: List<String>, val secs: List<Int>, val cb: (String) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val d = a.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = FrameLayout(a)
        val segs = urls.map { Seg(a) }
        val label = TextView(a)
        val btn = CloseBtn(a)
        val stage = FrameLayout(a)
        val spinner = ProgressBar(a)
        var wv: WebView? = null

        var idx = -1; var total = 1L; var left = 0L
        var counting = false; var done = false; var closed = false; var paused = false
        var hadError = false; var okLinks = 0
        var last = 0L
        val loadTimeout = Runnable { begin() }

        val tick = object : Runnable {
            override fun run() {
                if (closed) return
                val n = SystemClock.elapsedRealtime(); val dt = n - last; last = n
                if (!paused && counting && !done) {
                    left = max(0L, left - dt); paint()
                    if (left <= 0L) { if (idx < urls.size - 1) step() else finish() }
                }
                h.postDelayed(this, 100)
            }
        }

        fun restAfter(): Long { var t = 0L; for (j in idx + 1 until secs.size) t += secs[j] * 1000L; return t }
        fun secsLeftAll() = (left + restAfter() + 999) / 1000

        // ------------------------------------------------------------ layout
        fun start() {
            root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0D0A14.toInt(), 0xFF2A0A45.toInt()))
            root.isClickable = true; root.isFocusable = true
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }

            val top = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10) + a.systemInsetTop(), dp(14), dp(8)) }
            val segRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            segs.forEachIndexed { i, s -> segRow.addView(s, LinearLayout.LayoutParams(0, dp(4), 1f).apply { if (i > 0) leftMargin = dp(5) }) }
            top.addView(segRow, LinearLayout.LayoutParams(-1, -2))

            val bar = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val tag = TextView(a).apply {
                text = "AD"; setTextColor(0xFFEBDDF5.toInt()); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(8), dp(3), dp(8), dp(3))
                background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(0x24FFFFFF) }
            }
            label.apply { setTextColor(0xD1FFFFFF.toInt()); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; setPadding(dp(10), 0, dp(10), 0) }
            bar.addView(tag); bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f)); bar.addView(btn, LinearLayout.LayoutParams(dp(40), dp(40)))
            top.addView(bar, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
            col.addView(top, LinearLayout.LayoutParams(-1, -2))

            stage.setBackgroundColor(Color.WHITE)
            stage.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { val r = dp(22); o.setRoundRect(0, 0, v.width, v.height + r, r.toFloat()) }
            }
            stage.clipToOutline = true
            spinner.isIndeterminate = true
            spinner.indeterminateTintList = ColorStateList.valueOf(0xFF8E24AA.toInt())
            stage.addView(spinner, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
            col.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = a.systemInsetBottom() })
            root.addView(col, FrameLayout.LayoutParams(-1, -1))

            btn.contentDescription = "Close ad"
            btn.setOnClickListener { onBack() }

            root.alpha = 0f; root.scaleX = 0.985f; root.scaleY = 0.985f
            a.adHost().addView(root, ViewGroup.LayoutParams(-1, -1))
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            a.adBars(true)                         // light status-bar icons over the dark top bar
            cb("showing")
            last = SystemClock.elapsedRealtime(); h.post(tick)
            step()
        }

        // ------------------------------------------------------------ one link at a time
        fun step() {
            idx++; dropWeb(); counting = false; hadError = false
            total = secs[idx] * 1000L; left = total
            spinner.visibility = View.VISIBLE
            val w = makeWebView(); wv = w; w.alpha = 0f
            stage.addView(w, 0, FrameLayout.LayoutParams(-1, -1))
            w.loadUrl(urls[idx])
            h.postDelayed(loadTimeout, LOAD_MAX_MS)     // countdown starts at page load, or after 8 s at the latest
            paint()
        }

        fun begin() {
            if (counting || done || closed || hadError) return
            counting = true; okLinks++
            h.removeCallbacks(loadTimeout)
            spinner.visibility = View.GONE
            wv?.animate()?.alpha(1f)?.setDuration(300)?.start()
            paint()
        }

        /** This link cannot be shown: skip it quietly. Nobody ever sees a browser error page. */
        fun linkFailed() {
            if (done || closed || counting) return
            if (idx < urls.size - 1) { step(); return }
            if (okLinks == 0) end("failed") else finish()
        }

        fun finish() { done = true; counting = false; h.removeCallbacks(loadTimeout); paint() }

        fun paint() {
            for (j in segs.indices) segs[j].frac = if (j < idx || done) 1f else if (j == idx) (1f - left.toFloat() / total) else 0f
            btn.set(((left + 999) / 1000).toInt(), left.toFloat() / total, done)
            val sl = secsLeftAll()
            label.text = when {
                done -> if (urls.size > 1) "Reward ready" else "You can close now"
                !counting -> "Loading…"
                urls.size > 1 -> "Reward in ${sl}s · ${idx + 1} of ${urls.size}"
                else -> "Closes in ${sl}s"
            }
        }

        fun setPaused(p: Boolean) { paused = p; try { if (p) wv?.onPause() else wv?.onResume() } catch (_: Exception) {} }

        fun onBack() {
            if (!done) { Toast.makeText(a, "You can close this ad in ${secsLeftAll()}s", Toast.LENGTH_SHORT).show(); return }
            end("closed")
        }

        fun end(status: String) {
            if (closed) return; closed = true
            h.removeCallbacksAndMessages(null)
            root.animate().alpha(0f).scaleX(1.012f).scaleY(1.012f).setDuration(220).withEndAction { destroyNow(true, status) }.start()
        }

        fun destroyNow(report: Boolean, status: String = "closed") {
            closed = true; h.removeCallbacksAndMessages(null); dropWeb()
            try { (root.parent as? ViewGroup)?.removeView(root) } catch (_: Exception) {}
            if (cur === this) cur = null
            if (report) { a.adBars(false); try { cb(status) } catch (_: Exception) {} }
        }

        /** The page is thrown away completely before the next link opens: stopped, history + cache cleared, destroyed. */
        fun dropWeb() {
            h.removeCallbacks(loadTimeout)
            wv?.let { w ->
                try { w.stopLoading(); w.loadUrl("about:blank"); w.clearHistory(); w.clearCache(true); stage.removeView(w); w.removeAllViews(); w.destroy() } catch (_: Exception) {}
            }
            wv = null
        }

        // ------------------------------------------------------------ links
        /** Non-web links (intent://, market://, tel:, ...) go to the phone. Returns true when handled here. */
        fun route(u: String): Boolean {
            val low = u.lowercase()
            if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("about:")) return false
            if (low.startsWith("javascript:") || low.startsWith("file:") || low.startsWith("content:")) return true
            try {
                val i = if (low.startsWith("intent:")) Intent.parseUri(u, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, Uri.parse(u))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); i.component = null; i.selector = null
                i.addCategory(Intent.CATEGORY_BROWSABLE)
                a.noteSystemUi()
                a.startActivity(i)
            } catch (_: Exception) {
                // intent:// with a fallback url: use it
                try {
                    val fb = Intent.parseUri(u, Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url")
                    if (!fb.isNullOrBlank() && fb.startsWith("http", true)) wv?.loadUrl(fb)
                } catch (_: Exception) {}
            }
            return true
        }

        /** The app only allows HTTPS traffic: an http:// hop in an ad redirect chain is upgraded to https:// instead of failing. */
        fun upgrade(u: String) = if (u.startsWith("http://", true)) "https://" + u.substring(7) else u

        @SuppressLint("SetJavaScriptEnabled")
        fun makeWebView(): WebView {
            val w = WebView(a)
            w.setBackgroundColor(Color.WHITE)
            w.settings.apply {
                javaScriptEnabled = true; domStorageEnabled = true
                javaScriptCanOpenWindowsAutomatically = true; setSupportMultipleWindows(true)
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true; loadWithOverviewMode = true
                builtInZoomControls = false; displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
                allowFileAccess = false; allowContentAccess = false
                // user agent: untouched, the phone's own Chrome-based WebView agent
            }
            CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(w, true) }
            w.setDownloadListener { url, _, _, _, _ ->
                try { a.noteSystemUi(); a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
            w.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val u = r.url.toString()
                    if (route(u)) return true
                    if (r.isForMainFrame && u.startsWith("http://", true)) { v.loadUrl(upgrade(u)); return true }
                    return false
                }
                override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { if (v === wv) hadError = false }
                override fun onPageFinished(v: WebView, url: String?) {
                    if (v !== wv || url == null || url == "about:blank") return
                    if (hadError) { failedPage(v); return }
                    begin()
                }
                override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                    if (v !== wv || !r.isForMainFrame) return
                    if ((e.description?.toString() ?: "").contains("ERR_ABORTED", true)) return
                    hadError = true; failedPage(v)
                }
                override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, e: WebResourceResponse) {
                    if (v !== wv || !r.isForMainFrame) return
                    if (e.statusCode >= 400) { hadError = true; failedPage(v) }
                }
                override fun onReceivedSslError(v: WebView, handler: SslErrorHandler, e: android.net.http.SslError) {
                    handler.cancel(); if (v === wv) { hadError = true; failedPage(v) }
                }
                override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                    if (v === wv) { hadError = true; h.post { linkFailed() } }
                    return true
                }
            }
            w.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(v: WebView, p: Int) { if (v === wv && p >= 90 && !hadError) begin() }
                override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, msg: Message): Boolean {
                    // pop-up / new tab asked by the ad page: it opens in this same ad WebView
                    val tmp = WebView(a)
                    tmp.webViewClient = object : WebViewClient() {
                        var used = false
                        fun go(u: String) {
                            if (used) return; used = true
                            h.post { if (!route(u)) wv?.loadUrl(upgrade(u)); try { tmp.destroy() } catch (_: Exception) {} }
                        }
                        override fun shouldOverrideUrlLoading(x: WebView, r: WebResourceRequest): Boolean { go(r.url.toString()); return true }
                        override fun onPageStarted(x: WebView, u: String?, f: Bitmap?) { if (u != null && u != "about:blank") { x.stopLoading(); go(u) } }
                    }
                    (msg.obj as WebView.WebViewTransport).webView = tmp; msg.sendToTarget(); return true
                }
            }
            return w
        }

        /** Before the countdown started: skip this link. After it started: replace the error page with a small neutral card. */
        fun failedPage(v: WebView) {
            if (counting) {
                v.loadDataWithBaseURL(null,
                    "<html><body style='margin:0;height:100vh;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:#5B5469;background:#F4F3F7'>Ad unavailable</body></html>",
                    "text/html", "utf-8", null)
                hadError = false
            } else h.postDelayed({ if (hadError && !counting) linkFailed() }, 1200)
        }
    }

    // ------------------------------------------------------------ small custom views
    private class Seg(c: MainActivity) : View(c) {
        var frac = 0f; set(v) { field = v; invalidate() }
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x2EFFFFFF }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val r = height / 2f
            c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, track)
            if (frac > 0f) {
                fill.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, intArrayOf(0xFFD18BFF.toInt(), 0xFF9B2FB8.toInt(), 0xFF6A1B9A.toInt()), null, Shader.TileMode.CLAMP)
                c.drawRoundRect(0f, 0f, width * min(1f, frac), height.toFloat(), r, r, fill)
            }
        }
    }

    private class CloseBtn(c: MainActivity) : View(c) {
        var secs = 0; var frac = 1f; var ready = false
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun set(s: Int, f: Float, r: Boolean) { secs = s; frac = f; ready = r; invalidate() }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val cx = w / 2; val cy = height / 2f; val sw = w * 0.085f; val rad = w / 2f - sw
            p.shader = null; p.style = Paint.Style.FILL
            if (ready) {
                p.shader = LinearGradient(0f, 0f, w, height.toFloat(), 0xFF9B2FB8.toInt(), 0xFF6A1B9A.toInt(), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, w / 2f, p); p.shader = null
                p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = sw * 0.9f; p.strokeCap = Paint.Cap.ROUND
                val k = w * 0.17f; c.drawLine(cx - k, cy - k, cx + k, cy + k, p); c.drawLine(cx + k, cy - k, cx - k, cy + k, p)
            } else {
                p.color = 0x1AFFFFFF; c.drawCircle(cx, cy, w / 2f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = 0x2EFFFFFF; c.drawCircle(cx, cy, rad, p)
                p.color = 0xFFC77DFF.toInt(); p.strokeCap = Paint.Cap.ROUND
                c.drawArc(RectF(cx - rad, cy - rad, cx + rad, cy + rad), -90f, 360f * max(0f, min(1f, frac)), false, p)
                p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = w * 0.36f; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
                c.drawText(secs.toString(), cx, cy + p.textSize * 0.35f, p)
            }
        }
    }
}
