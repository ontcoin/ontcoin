package com.example

import android.animation.Animator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Outline
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The OntCoin loading screen, drawn natively inside the one and only activity
 * (same look as the old splash.html: gradient glow, pulsing logo, name, tagline, dots).
 */
class SplashView(context: Context, private val dark: Boolean) : FrameLayout(context) {

    private val bg1 = Color.parseColor(if (dark) "#09070E" else "#F4F3F7")
    private val bg2 = Color.parseColor(if (dark) "#2A0F45" else "#EBDDF5")
    private val ink = Color.parseColor(if (dark) "#F5F2FA" else "#0D0A14")
    private val muted = Color.parseColor(if (dark) "#A79DB8" else "#6B6479")
    private val halo = if (dark) Color.argb(115, 190, 100, 230) else Color.argb(102, 142, 36, 170)

    private val blob1 = if (dark) Color.argb(87, 166, 60, 208) else Color.argb(115, 166, 60, 208)
    private val blob2 = if (dark) Color.argb(36, 255, 179, 71) else Color.argb(102, 255, 179, 71)
    private val blob3 = if (dark) Color.argb(36, 55, 200, 176) else Color.argb(82, 55, 200, 176)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bgShader: Shader? = null
    private var s1: Shader? = null
    private var s2: Shader? = null
    private var s3: Shader? = null

    private val rings = ArrayList<View>()
    private val dots = ArrayList<View>()
    private lateinit var logo: ImageView
    private lateinit var nameView: TextView
    private lateinit var tagView: TextView
    private val anims = ArrayList<Animator>()
    private var running = false

    init {
        setWillNotDraw(false)
        isClickable = true // swallow touches while loading
        clipChildren = false
        clipToPadding = false

        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
        }
        addView(col, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val box = FrameLayout(context)
        box.clipChildren = false   // the pulse rings must grow freely beyond the logo box
        box.clipToPadding = false
        col.addView(box, LinearLayout.LayoutParams(context.dp(132), context.dp(132)))
        for (i in 0 until 3) {
            val r = View(context).apply {
                background = roundRect(halo, context.dp(32).toFloat())
                alpha = 0f
            }
            rings.add(r)
            box.addView(r, FrameLayout.LayoutParams(context.dp(132), context.dp(132)))
        }
        logo = ImageView(context).apply {
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, context.dp(32).toFloat())
                }
            }
            clipToOutline = true
        }
        box.addView(logo, FrameLayout.LayoutParams(context.dp(132), context.dp(132)))

        nameView = TextView(context).apply {
            text = context.getString(R.string.app_name)
            setTextColor(ink)
            textSize = 26f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            letterSpacing = -0.02f
            gravity = Gravity.CENTER
        }
        col.addView(nameView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = context.dp(34) })

        tagView = TextView(context).apply {
            text = context.getString(R.string.splash_tagline)
            setTextColor(muted)
            textSize = 14f
            gravity = Gravity.CENTER
        }
        col.addView(tagView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = context.dp(6) })

        val dotRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (i in 0 until 3) {
            val d = View(context).apply {
                background = roundRect(ink, context.dp(4).toFloat())
                alpha = 0.25f
            }
            dots.add(d)
            dotRow.addView(d, LinearLayout.LayoutParams(context.dp(7), context.dp(7)).apply {
                leftMargin = context.dp(4); rightMargin = context.dp(4)
            })
        }
        addView(dotRow, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = context.dp(92)
        })
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        bgShader = LinearGradient(fw * 0.42f, 0f, fw * 0.58f, fh, bg1, bg2, Shader.TileMode.CLAMP)
        val r = fw * 0.75f
        s1 = RadialGradient(fw * 0.12f, fh * 0.06f, r, blob1, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        s2 = RadialGradient(fw * 0.96f, fh * 0.38f, r * 0.9f, blob2, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        s3 = RadialGradient(fw * 0.40f, fh, r, blob3, Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = bgShader
        canvas.drawRect(0f, 0f, w, h, paint)
        for (s in arrayOf(s1, s2, s3)) {
            paint.shader = s
            canvas.drawRect(0f, 0f, w, h, paint)
        }
        paint.shader = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnims()
    }

    override fun onDetachedFromWindow() {
        stopAnims()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView !== this) return
        if (visibility == VISIBLE) startAnims() else stopAnims()
    }

    private fun startAnims() {
        if (running) return
        running = true

        // pulse rings
        rings.forEachIndexed { i, ring ->
            val a = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 2400L
                startDelay = i * 800L
                repeatCount = ValueAnimator.INFINITE
                interpolator = DecelerateInterpolator(1.2f)
                addUpdateListener {
                    val t = it.animatedValue as Float
                    val s = 1f + 1.1f * t
                    ring.scaleX = s; ring.scaleY = s
                    ring.alpha = 0.55f * (1f - t)
                }
            }
            anims.add(a); a.start()
        }

        // logo: pop in, then heartbeat
        logo.alpha = 0f; logo.scaleX = 0.6f; logo.scaleY = 0.6f
        val enter = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700L
            interpolator = OvershootInterpolator(1.4f)
            addUpdateListener {
                val t = it.animatedValue as Float
                logo.alpha = t.coerceIn(0f, 1f)
                val s = 0.6f + 0.4f * t
                logo.scaleX = s; logo.scaleY = s
            }
        }
        anims.add(enter); enter.start()
        val beat = ValueAnimator.ofFloat(1f, 1.06f).apply {
            duration = 1200L
            startDelay = 700L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { v ->
                if (enter.isRunning) return@addUpdateListener
                val s = v.animatedValue as Float
                logo.scaleX = s; logo.scaleY = s
            }
        }
        anims.add(beat); beat.start()

        // text rises in
        for ((view, delay) in listOf(nameView to 250L, tagView to 400L)) {
            view.alpha = 0f; view.translationY = context.dp(12).toFloat()
            val a = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 800L
                startDelay = delay
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    val t = it.animatedValue as Float
                    view.alpha = t
                    view.translationY = context.dp(12).toFloat() * (1f - t)
                }
            }
            anims.add(a); a.start()
        }

        // loading dots
        dots.forEachIndexed { i, dot ->
            val a = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 600L
                startDelay = i * 150L
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    val t = it.animatedValue as Float
                    dot.alpha = 0.2f + 0.7f * t
                    val s = 1f + 0.35f * t
                    dot.scaleX = s; dot.scaleY = s
                }
            }
            anims.add(a); a.start()
        }
    }

    private fun stopAnims() {
        if (!running) return
        running = false
        for (a in anims) a.cancel()
        anims.clear()
    }
}
