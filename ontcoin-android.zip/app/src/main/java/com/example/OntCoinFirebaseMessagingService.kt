package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Push notifications.
 *
 * Every push from the server is DATA-ONLY (title, body, url, image, nid) with high priority, so this class always draws the notification:
 *  - heads-up banner at the top of the screen (high-importance channel)
 *  - the OntCoin glyph as the small status-bar icon and the main OntCoin logo (the one on the loading screen) as the large icon
 *  - optional banner picture with rounded (curved) corners
 *  - tapping it opens the app (and the page named in "url")
 *  - the same "nid" is shown once, even when it arrives through the topic AND the device token
 *  - nothing is shown while the app is open; when the app is opened every notification of OntCoin is removed from the status bar
 *
 * Topics: "all_users" (everybody, subscribed at every app launch) and the user's private topic (subscribed after sign-in, removed at sign-out).
 */
class OntCoinFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "OntCoinFCM"
        const val CHANNEL_ID = "ontcoin_channel"
        const val TOPIC_ALL = "all_users"
        const val PREFS_NAME = "ontcoin"
        const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_USER_TOPIC = "fcm_user_topic"
        private const val KEY_TOPICS_OFF = "fcm_topics_off"
        private const val KEY_SEEN = "fcm_seen_nids"
        private val TOPIC_OK = Regex("^[A-Za-z0-9_.~%-]{1,200}$")

        fun getCachedToken(context: Context): String {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val token = prefs.getString(KEY_FCM_TOKEN, "") ?: ""
            if (token.isNotBlank()) return token
            return context.getSharedPreferences("ontcoin_prefs", Context.MODE_PRIVATE).getString(KEY_FCM_TOKEN, "") ?: ""
        }

        fun saveToken(context: Context, token: String) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_FCM_TOKEN, token).apply()
        }

        /** High-importance channel = heads-up banner. Safe to call any number of times. */
        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) != null) return
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, context.getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_HIGH).apply {
                    description = context.getString(R.string.notification_channel_description)
                    enableLights(true); lightColor = Color.parseColor("#8E24AA"); enableVibration(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
            )
        }

        private fun prefs(c: Context) = c.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        private fun topicsOff(c: Context) = prefs(c).getBoolean(KEY_TOPICS_OFF, false)

        /** Everybody-topic: called every time the app opens (signed in or not). */
        fun subscribeAll(context: Context) {
            if (topicsOff(context)) return
            try { FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_ALL) } catch (e: Exception) { Log.w(TAG, "subscribeAll: ${e.message}") }
            val u = prefs(context).getString(KEY_USER_TOPIC, "") ?: ""
            if (u.isNotBlank()) try { FirebaseMessaging.getInstance().subscribeToTopic(u) } catch (_: Exception) {}
        }

        /** Ensures FCM token is fetched, cached, and subscribed on launch. */
        @Suppress("DEPRECATION")
        fun fetchAndCacheToken(context: Context, onReady: ((String) -> Unit)? = null) {
            val cached = getCachedToken(context)
            if (cached.isNotBlank()) onReady?.invoke(cached)
            try {
                FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                    if (task.isSuccessful && !task.result.isNullOrBlank()) {
                        val token = task.result
                        Log.d(TAG, "Active FCM token: $token")
                        saveToken(context, token)
                        subscribeAll(context)
                        onReady?.invoke(token)
                    } else {
                        Log.w(TAG, "Failed to get FCM token: ${task.exception?.message}")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "fetchAndCacheToken error: ${e.message}")
            }
        }

        /** This user's private topic (name comes from the server, it is secret per user). */
        fun subscribeUser(context: Context, topic: String) {
            if (!TOPIC_OK.matches(topic) || topicsOff(context)) return
            val old = prefs(context).getString(KEY_USER_TOPIC, "") ?: ""
            try {
                if (old.isNotBlank() && old != topic) FirebaseMessaging.getInstance().unsubscribeFromTopic(old)
                FirebaseMessaging.getInstance().subscribeToTopic(topic)
                prefs(context).edit().putString(KEY_USER_TOPIC, topic).apply()
            } catch (e: Exception) { Log.w(TAG, "subscribeUser: ${e.message}") }
        }

        /** Sign-out: this phone must not receive the previous user's private notifications any more. */
        fun unsubscribeUser(context: Context) {
            val old = prefs(context).getString(KEY_USER_TOPIC, "") ?: ""
            if (old.isNotBlank()) try { FirebaseMessaging.getInstance().unsubscribeFromTopic(old) } catch (_: Exception) {}
            prefs(context).edit().remove(KEY_USER_TOPIC).apply()
        }

        /** The user's in-app notification switch. */
        fun setTopicsEnabled(context: Context, on: Boolean) {
            prefs(context).edit().putBoolean(KEY_TOPICS_OFF, !on).apply()
            if (on) subscribeAll(context)
            else {
                try { FirebaseMessaging.getInstance().unsubscribeFromTopic(TOPIC_ALL) } catch (_: Exception) {}
                val u = prefs(context).getString(KEY_USER_TOPIC, "") ?: ""
                if (u.isNotBlank()) try { FirebaseMessaging.getInstance().unsubscribeFromTopic(u) } catch (_: Exception) {}
            }
        }

        /** The user opened the app: every OntCoin notification leaves the status bar. */
        fun clearAll(context: Context) {
            try { NotificationManagerCompat.from(context).cancelAll() } catch (_: Exception) {}
        }

        @Synchronized
        private fun alreadySeen(context: Context, nid: String): Boolean {
            if (nid.isBlank()) return false
            val now = System.currentTimeMillis()
            val keep = (prefs(context).getString(KEY_SEEN, "") ?: "").split(",").filter { it.contains(":") }
                .filter { (it.substringAfterLast(":").toLongOrNull() ?: 0L) > now - 10 * 60_000L }
            if (keep.any { it.substringBeforeLast(":") == nid }) return true
            prefs(context).edit().putString(KEY_SEEN, (keep.takeLast(40) + "$nid:$now").joinToString(",")).apply()
            return false
        }
    }

    @Deprecated("Overrides FirebaseMessagingService.onNewToken")
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM token")
        saveToken(this, token)
        subscribeAll(this)
        MainActivity.onTokenRefreshed(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val d = remoteMessage.data
        val title = d["title"]?.takeIf { it.isNotBlank() } ?: remoteMessage.notification?.title ?: getString(R.string.app_name)
        val body = d["body"] ?: d["message"] ?: remoteMessage.notification?.body ?: ""
        if (body.isBlank() && title == getString(R.string.app_name)) return
        val link = d["url"] ?: d["link"] ?: remoteMessage.notification?.clickAction ?: ""
        val nid = d["nid"] ?: ""
        val image = (d["image"] ?: remoteMessage.notification?.imageUrl?.toString() ?: "").trim()

        if (alreadySeen(this, nid)) return            // same message came twice (topic + token): show it once
        MainActivity.onPushReceivedInForeground(title, body, link, image)
        showNotification(title, body, link, nid, image)
    }

    private fun showNotification(title: String, body: String, link: String, nid: String, image: String) {
        ensureChannel(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = if (nid.isNotBlank()) nid.hashCode() else System.currentTimeMillis().toInt()

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            if (link.isNotBlank()) putExtra("link", link)
        }
        val pi = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)            // white OntCoin glyph (Android draws small icons by shape only)
            .setColor(Color.parseColor("#8E24AA"))
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setContentIntent(pi)

        val pic = if (image.startsWith("https://")) fetchRounded(image) else null
        if (pic != null) {
            b.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(pic)
                    .bigLargeIcon(null as Bitmap?)
                    .setBigContentTitle(title)
                    .setSummaryText(body)
            )
        } else {
            b.setStyle(NotificationCompat.BigTextStyle().bigText(body))
        }
        try { nm.notify(id, b.build()) } catch (e: SecurityException) { Log.w(TAG, "notifications not allowed") }
    }

    /** Downloads the banner picture (max 3 MB, 6 s) and gives it curved corners. Returns null on any problem → plain text notification. */
    private fun fetchRounded(url: String): Bitmap? {
        return try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 6000; readTimeout = 6000; instanceFollowRedirects = true }
            if (c.responseCode !in 200..299) return null
            val bytes = c.inputStream.use { ins ->
                val out = ByteArrayOutputStream(); val buf = ByteArray(16 * 1024); var total = 0
                while (true) { val n = ins.read(buf); if (n < 0) break; total += n; if (total > 3_000_000) return null; out.write(buf, 0, n) }
                out.toByteArray()
            }
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bo)
            if (bo.outWidth <= 0) return null
            var sample = 1; while (bo.outWidth / sample > 1100) sample *= 2
            val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
            val radius = src.width * 0.045f
            val canvas = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            canvas.drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), radius, radius, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            canvas.drawBitmap(src, 0f, 0f, paint)
            out
        } catch (e: Exception) { Log.w(TAG, "banner image: ${e.message}"); null }
    }
}
