package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.TelephonyManager
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Everything the web app may learn about the phone: model, OS, app version, SIM/network country and the
 * country (from the IP address). No location permission is used and no GPS/coordinates are ever read.
 */
class DeviceInfoProvider(context: Context) {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("ontcoin", Context.MODE_PRIVATE)

    /** Stable per-install-signature device id (hashed - the real ANDROID_ID is never exposed). */
    @SuppressLint("HardwareIds")
    fun deviceId(): String {
        val raw = try { Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "" } catch (_: Exception) { "" }
        val md = MessageDigest.getInstance("SHA-256").digest(("ontcoin|$raw|${ctx.packageName}").toByteArray())
        return md.joinToString("") { "%02x".format(it) }.substring(0, 24)
    }

    fun appInfo(): JSONObject {
        val o = JSONObject()
        o.put("versionName", BuildConfig.VERSION_NAME)
        o.put("versionCode", BuildConfig.VERSION_CODE)
        o.put("pkg", ctx.packageName)
        o.put("sdk", Build.VERSION.SDK_INT)
        o.put("bridge", 2)
        return o
    }

    private fun simCountry(): String = try {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        (tm?.simCountryIso ?: "").uppercase(Locale.ROOT)
    } catch (_: Exception) { "" }

    private fun netCountry(): String = try {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        (tm?.networkCountryIso ?: "").uppercase(Locale.ROOT)
    } catch (_: Exception) { "" }

    private fun userDeviceName(): String = try {
        Settings.Global.getString(ctx.contentResolver, "device_name") ?: ""
    } catch (_: Exception) { "" }

    fun deviceJson(): JSONObject {
        val dm = ctx.resources.displayMetrics
        val o = JSONObject()
        o.put("did", deviceId())
        o.put("brand", Build.BRAND ?: "")
        o.put("manufacturer", Build.MANUFACTURER ?: "")
        o.put("model", Build.MODEL ?: "")
        o.put("name", userDeviceName())
        o.put("os", "Android")
        o.put("osVersion", Build.VERSION.RELEASE ?: "")
        o.put("sdk", Build.VERSION.SDK_INT)
        o.put("appVersion", BuildConfig.VERSION_NAME)
        o.put("appCode", BuildConfig.VERSION_CODE)
        o.put("locale", Locale.getDefault().toLanguageTag())
        o.put("localeCountry", Locale.getDefault().country ?: "")
        o.put("tz", TimeZone.getDefault().id)
        o.put("simCountry", simCountry())
        o.put("netCountry", netCountry())
        o.put("screen", "${dm.widthPixels}x${dm.heightPixels}")
        val loc = cachedLocation()
        if (loc != null) o.put("loc", loc)
        return o
    }

    // ------------------------------------------------------------------ country (IP only - no location permission, no GPS)
    fun cachedLocation(): JSONObject? {
        val s = prefs.getString("loc_json", null) ?: return null
        return try { JSONObject(s) } catch (_: Exception) { null }
    }

    /** Country only (e.g. Nigeria), found from the phone's public IP. Falls back to SIM/network country. Calls back on the main thread, exactly once. */
    fun fetchLocation(cb: (JSONObject?) -> Unit) {
        val done = AtomicBoolean(false)
        val finish: (JSONObject?) -> Unit = { r -> if (done.compareAndSet(false, true)) main.post { cb(r ?: cachedLocation() ?: fallbackFromNetwork()) } }
        main.postDelayed({ finish(null) }, 8000L)
        Thread {
            var out: JSONObject? = null
            try {
                val c = java.net.URL("https://ipwho.is/?fields=success,country,country_code").openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000; c.requestMethod = "GET"
                if (c.responseCode == 200) {
                    val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    val cc = j.optString("country_code", "").uppercase(Locale.ROOT)
                    if (j.optBoolean("success", false) && cc.length == 2) {
                        out = JSONObject().put("country", cc).put("countryName", j.optString("country", cc))
                            .put("region", "").put("city", "").put("source", "ip").put("at", System.currentTimeMillis())
                    }
                }
                c.disconnect()
            } catch (_: Exception) {}
            if (out == null) out = fallbackFromNetwork()
            val res = out
            if (res != null) prefs.edit().putString("loc_json", res.toString()).apply()
            finish(res)
        }.start()
    }

    private fun fallbackFromNetwork(): JSONObject? {
        val cc = netCountry().ifBlank { simCountry() }
        if (cc.isBlank()) return null
        return JSONObject().put("country", cc)
            .put("countryName", try { Locale.Builder().setRegion(cc).build().getDisplayCountry(Locale.ENGLISH) } catch (_: Exception) { cc })
            .put("region", "").put("city", "").put("source", "network").put("at", System.currentTimeMillis())
    }
}
