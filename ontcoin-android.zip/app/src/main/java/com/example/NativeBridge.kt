package com.example

import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * window.Android - the ONLY door between the web app and the phone.
 * Every method first checks that the page currently loaded is the real OntCoin site over HTTPS
 * (MainActivity.trustedPage). Any other page gets safe default values and no hardware access.
 *
 * Bridge version 4 (4 = native WebView ad screen: hasAdView / showAdView; no ad SDK).
 */
class NativeBridge(private val act: MainActivity) {

    private fun <T> guard(default: T, block: () -> T): T =
        if (!act.trustedPage) default else try { block() } catch (_: Exception) { default }

    private fun ui(block: () -> Unit) {
        if (!act.trustedPage) return
        act.runOnUiThread { try { block() } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------ app session (passcode only after the app was closed)
    @JavascriptInterface
    fun isSessionAlive(): Boolean = guard(false) { MainActivity.sessionAlive }

    @JavascriptInterface
    fun setSessionAlive(on: Boolean) {
        if (!act.trustedPage) return
        MainActivity.sessionAlive = on
    }

    // ------------------------------------------------------------------ handshake / identity
    @JavascriptInterface
    fun getBridgeVersion(): Int = guard(0) { 4 }

    /** {"versionName":"1.1.0","versionCode":20,"pkg":"...","sdk":34,"bridge":2} - the ANDROID app version, used for update checks. */
    @JavascriptInterface
    fun getAppInfo(): String = guard("") { act.device.appInfo().toString() }

    /** Short-lived signed proof that this is the genuine app. Sent by the web app to the server on every request. */
    @JavascriptInterface
    fun getAppProof(): String = guard("") { AppProof.create() }

    /** The web app calls this when the page, fonts and images are fully loaded and the first screen is drawn. */
    @JavascriptInterface
    fun onWebReady(payload: String?) {
        ui { act.onWebReadyFromWeb(payload) }
    }

    /** The web app calls this when it cannot start at all (so the user never sees a broken page). */
    @JavascriptInterface
    fun onWebFailed(reason: String?) {
        ui { act.onWebFailedFromWeb(reason) }
    }

    // ------------------------------------------------------------------ ads: real WebView ad screen (AdOverlay) - app 3.3
    /** true when this app has the native ad screen. Older apps have no such method and the web app falls back to a frame. */
    @JavascriptInterface
    fun hasAdView(): Boolean = guard(false) { true }

    /**
     * Shows the full-screen ad. urlsJson = ["https://...", ...] (one WebView per link), secsJson = [10, 10] (countdown seconds per link).
     * The answer comes back as OTBridge.onAdResult(token, status): "showing" (on screen), then one final "closed" | "failed" ("busy" = another ad is open).
     */
    @JavascriptInterface
    fun showAdView(token: String?, kind: String?, urlsJson: String?, secsJson: String?) {
        val t = token ?: ""
        ui { act.showAdView(t, urlsJson ?: "[]", secsJson ?: "[]") }
    }

    // ------------------------------------------------------------------ device
    @JavascriptInterface
    fun getDeviceInfo(): String = guard("{}") { act.device.deviceJson().toString() }

    @JavascriptInterface
    fun getDeviceId(): String = guard("") { act.device.deviceId() }

    @JavascriptInterface
    fun isOnline(): Boolean = guard(false) { act.networkOnline() }

    @JavascriptInterface
    fun getNetworkType(): String = guard("none") { act.networkType() }

    /** Looks up the COUNTRY from the phone's IP address (no location permission, no GPS). Result arrives via OTBridge.onLocation(obj|null). */
    @JavascriptInterface
    fun requestLocation() {
        ui { act.requestLocation() }
    }

    /** Last known approximate place as JSON ("" if none). */
    @JavascriptInterface
    fun getLocation(): String = guard("") { act.device.cachedLocation()?.toString() ?: "" }

    // ------------------------------------------------------------------ biometrics, push, theme (unchanged API)
    @JavascriptInterface
    fun isBiometricAvailable(): Boolean = guard(false) { act.isBiometricAvailable() }

    @JavascriptInterface
    fun authenticateBiometric() {
        ui { act.authenticateBiometric() }
    }

    @JavascriptInterface
    fun getFcmToken(): String = guard("") { OntCoinFirebaseMessagingService.getCachedToken(act) }

    /** After sign-in the web app hands over the server-made topic names: everybody + this user's private channel. */
    @JavascriptInterface
    fun subscribeTopics(all: String, user: String) {
        if (!act.trustedPage) return
        try { OntCoinFirebaseMessagingService.subscribeAll(act.applicationContext); OntCoinFirebaseMessagingService.subscribeUser(act.applicationContext, user) } catch (_: Exception) {}
    }

    /** Sign-out: stop receiving this user's private notifications on this phone. */
    @JavascriptInterface
    fun unsubscribeUser() {
        if (!act.trustedPage) return
        try { OntCoinFirebaseMessagingService.unsubscribeUser(act.applicationContext) } catch (_: Exception) {}
    }

    /** The in-app "Notifications" switch: off = leave both topics, on = join again. */
    @JavascriptInterface
    fun setPushTopics(on: Boolean) {
        if (!act.trustedPage) return
        try { OntCoinFirebaseMessagingService.setTopicsEnabled(act.applicationContext, on) } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun requestNotificationPermission() {
        ui { act.requestNotificationPermission() }
    }

    @JavascriptInterface
    fun areNotificationsEnabled(): Boolean = guard(false) { act.notificationsEnabled() }

    @JavascriptInterface
    fun openAppSettings() {
        ui { act.openAppSettings() }
    }

    @JavascriptInterface
    fun setTheme(isDark: Boolean) {
        ui { act.applySystemBars(isDark) }
    }

    @JavascriptInterface
    fun getThemeMode(): String = guard("system") { act.prefs.getString("theme_mode", "system") ?: "system" }

    @JavascriptInterface
    fun setThemeMode(mode: String?) {
        if (mode != "light" && mode != "dark" && mode != "system") return
        if (!act.trustedPage) return
        act.prefs.edit().putString("theme_mode", mode).apply()
        ui { act.applySystemBars(act.resolveDark(mode)) }
    }

    // ------------------------------------------------------------------ phone hardware
    @JavascriptInterface
    fun haptic(ms: Int) {
        ui { act.haptic(ms) }
    }

    /** type: tick | click | heavy | success | error */
    @JavascriptInterface
    fun hapticType(type: String?) {
        ui { act.hapticType(type ?: "click") }
    }

    @JavascriptInterface
    fun share(text: String?, title: String?) {
        if (text.isNullOrBlank()) return
        ui { act.shareText(text, title) }
    }

    @JavascriptInterface
    fun copyText(text: String?): Boolean {
        if (text == null) return false
        return guard(false) { act.copyToClipboard(text) }
    }

    /** Blocks screenshots / screen recording / recents preview while a secret (recovery phrase) is on screen. */
    @JavascriptInterface
    fun setSecure(on: Boolean) {
        ui { act.setSecureScreen(on) }
    }

    @JavascriptInterface
    fun keepScreenOn(on: Boolean) {
        ui { act.setKeepScreenOn(on) }
    }

    // ------------------------------------------------------------------ navigation
    @JavascriptInterface
    fun openExternal(url: String?) {
        if (url.isNullOrBlank()) return
        ui { act.openExternal(url) }
    }

    @JavascriptInterface
    fun checkPlayStoreUpdate() {
        ui { act.checkPlayStoreUpdate(interactive = true) }
    }

    @JavascriptInterface
    fun openPlayStore() {
        ui { act.openGooglePlayStore() }
    }

    @JavascriptInterface
    fun reload() {
        ui { act.reloadApp() }
    }

    @JavascriptInterface
    fun exitApp() {
        ui { act.finishAffinity() }
    }
}
