package com.example

import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Signs a short-lived "I am the real OntCoin app" proof. The web app attaches it to every API call
 * (header X-OT-App) and the PHP server verifies it with the same shared secret (OT_APP_SECRET).
 * Format:  v1.<unix-seconds>.<nonce-hex>.<hmac-sha256-hex>
 */
object AppProof {
    private val rnd = SecureRandom()

    fun create(): String {
        val ts = System.currentTimeMillis() / 1000L
        val nb = ByteArray(8)
        rnd.nextBytes(nb)
        val nonce = nb.joinToString("") { "%02x".format(it) }
        val msg = "v1.$ts.$nonce"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(BuildConfig.APP_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val sig = mac.doFinal(msg.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        return "$msg.$sig"
    }
}
