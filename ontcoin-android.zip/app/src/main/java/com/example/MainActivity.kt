package com.example

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import org.json.JSONObject
import java.io.File

/**
 * The one and only activity. It owns:
 *  - the native loading screen (SplashView)
 *  - the OntCoin web app (WebView) - never shown until the web app itself says "I am fully loaded"
 *  - the native "no connection" dialog that looks exactly like the web app's dialog
 *  - the two-way bridge (NativeBridge <-> OTBridge in the web app)
 *
 * The WebView's own error pages (the "Webpage not available ... net::ERR_..." screen) can never appear:
 * every main-frame failure is caught and replaced by the dialog, and the page stays hidden until the web
 * app confirms it loaded without errors.
 */
@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    companion object {
        /** true once the app has been opened + unlocked in this phone session. A reload (WebView rebuilt, reconnect, retry) does NOT reset it,
         *  so the passcode is asked only after the app was really closed (back-exit / swiped away / phone restarted). */
        @Volatile var sessionAlive: Boolean = false
        private var activeInstance: MainActivity? = null
        /** true while the app is on screen: pushes are not drawn as banners then */
        @Volatile var inForeground: Boolean = false

        fun onTokenRefreshed(token: String) {
            val a = activeInstance ?: return
            a.runOnUiThread { a.sendFcmToken(token) }
        }

        fun onPushReceivedInForeground(title: String, body: String, link: String, image: String) {
            val a = activeInstance ?: return
            a.runOnUiThread {
                try {
                    val json = JSONObject().apply {
                        put("title", title)
                        put("body", body)
                        put("link", link)
                        put("image", image)
                    }
                    a.callBridge("onPushReceived", json.toString())
                } catch (_: Exception) {}
            }
        }

        private const val MIN_SPLASH_MS = 1200L     // never flash the splash
        private const val PAGE_TIMEOUT_MS = 30000L  // page must finish loading
        private const val READY_TIMEOUT_MS = 15000L // ...and the web app must then confirm it is ready
        private const val POLL_MS = 400L
        private const val AD_AWAY_MS = 2_000L        // app-open ad: away at least this long (2 s)
    }

    // ---------------------------------------------------------------- state
    private lateinit var root: FrameLayout
    private lateinit var splash: SplashView
    private lateinit var statusDialog: StatusDialogView
    private lateinit var net: NetworkMonitor
    lateinit var device: DeviceInfoProvider
        private set
    private var web: WebView? = null
    private val main = Handler(Looper.getMainLooper())

    /** True only while the loaded page is https://<APP_HOST>/... Checked by every bridge method. */
    @Volatile var trustedPage: Boolean = false

    private var pageFinished = false
    private var webReady = false
    private var revealed = false
    private var failureShown = false
    private var historyCleared = false
    private var splashShownAt = 0L
    private var pendingLink: String? = null

    val prefs: SharedPreferences by lazy { getSharedPreferences("ontcoin", Context.MODE_PRIVATE) }

    // ---------------------------------------------------------------- activity result plumbing
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var captureUri: Uri? = null

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        noteSystemUi()
        val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        filePathCallback?.onReceiveValue(results)
        filePathCallback = null
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        noteSystemUi()
        val uri = captureUri
        captureUri = null
        if (result.resultCode == RESULT_OK && uri != null) filePathCallback?.onReceiveValue(arrayOf(uri))
        else filePathCallback?.onReceiveValue(null)
        filePathCallback = null
    }

    private val cameraPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        noteSystemUi()
        if (granted) { try { launchCamera() } catch (_: Exception) { filePathCallback?.onReceiveValue(null); filePathCallback = null } }
        else { filePathCallback?.onReceiveValue(null); filePathCallback = null }
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        noteSystemUi()
        if (granted) {
            val token = OntCoinFirebaseMessagingService.getCachedToken(this)
            if (token.isNotBlank()) sendFcmToken(token)
        }
    }

    // ---------------------------------------------------------------- edge-to-edge (Android 7 - 16)
    // The WebView fills the WHOLE screen, so the page's own background/gradient is drawn behind the transparent status and navigation bars.
    // The page keeps its content clear of the bars: the real bar sizes are handed to it as CSS variables (--safe-t / --safe-b).
    private var insetTopPx = 0; private var insetBottomPx = 0; private var imeBottomPx = 0

    /** WebView layout: full screen; only the on-screen keyboard shrinks it, so inputs stay visible. */
    private fun webLp(): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).also { it.setMargins(0, 0, 0, imeBottomPx) }

    private fun installInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            insetTopPx = bars.top
            imeBottomPx = ime.bottom
            insetBottomPx = if (ime.bottom > 0) 0 else bars.bottom   // keyboard open: the navigation bar is hidden behind it
            web?.layoutParams = webLp()
            pushInsetsToWeb()
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(root)
    }

    /** Tells the page how tall the status bar / navigation bar are (CSS px) so it can keep its content clear of them. */
    private fun pushInsetsToWeb() {
        val d = resources.displayMetrics.density.coerceAtLeast(1f)
        val t = Math.round(insetTopPx / d * 100f) / 100f
        val b = Math.round(insetBottomPx / d * 100f) / 100f
        web?.evaluateJavascript(
            "(function(){try{var s=document.documentElement.style;s.setProperty('--safe-t','${t}px');s.setProperty('--safe-b','${b}px')}catch(e){}})()", null
        )
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = this
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // drop the Android 12+ system splash the instant it is allowed to go
            splashScreen.setOnExitAnimationListener { it.remove() }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false      // no grey scrim behind the bars
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.also { it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        }

        val mode = prefs.getString("theme_mode", "system") ?: "system"
        val dark = resolveDark(mode)
        val bg = Color.parseColor(if (dark) "#09070E" else "#F4F3F7")
        window.decorView.setBackgroundColor(bg)
        applySystemBars(dark)

        root = FrameLayout(this)
        root.setBackgroundColor(bg)
        setContentView(root)

        // push: banner channel + subscribe to the "all users" topic on every launch (the private topic follows after sign-in)
        OntCoinFirebaseMessagingService.ensureChannel(this)
        OntCoinFirebaseMessagingService.subscribeAll(this)
        OntCoinFirebaseMessagingService.fetchAndCacheToken(this) { token ->
            sendFcmToken(token)
        }
        requestNotificationPermission()

        device = DeviceInfoProvider(this)
        splash = SplashView(this, dark)
        statusDialog = StatusDialogView(this, dark)
        statusDialog.onClose = { finishAffinity() }
        statusDialog.onRetry = { startLoad(fresh = true) }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(splash, FrameLayout.LayoutParams(match, match))
        root.addView(statusDialog, FrameLayout.LayoutParams(match, match))

        net = NetworkMonitor(this) { online, type -> onNetworkChanged(online, type) }
        net.start()

        val firstWeb = createWebView(bg)
        web = firstWeb
        root.addView(firstWeb, 0, webLp())
        installInsets()
        device.fetchLocation { }   /* warm the IP-country cache (country only) */

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })

        handleIntent(intent)
        startLoad()
        checkPlayStoreUpdate(interactive = false)
    }

    override fun onResume() {
        super.onResume()
        inForeground = true
        AdOverlay.onResume()
        // app-open ad: the person was away for 3 s or more (not for camera / picker / permission / Play-update screens). The web app decides whether the screen allows an ad.
        val t = SystemClock.elapsedRealtime()
        val away = if (stoppedAt == 0L) 0L else t - stoppedAt
        stoppedAt = 0L
        if (revealed && away >= AD_AWAY_MS && t - lastSystemUiAt > 4_000L && !AdOverlay.isShowing()) callBridge("onAppResume", away.toString())
        OntCoinFirebaseMessagingService.clearAll(this)   // opening the app removes OntCoin notifications from the top of the screen
        if (revealed) {
            pushInsetsToWeb()
            pushNetworkToWeb()
            callBridge("onResume")
        }
        try {
            appUpdateManager?.appUpdateInfo?.addOnSuccessListener { info ->
                if (info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    try {
                        appUpdateManager?.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 9001)
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    override fun onPause() {
        inForeground = false
        AdOverlay.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onStop() {
        if (!AdOverlay.isShowing() && stoppedAt == 0L) stoppedAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        noteSystemUi()      // e.g. the Google Play update screen: not an app "resume"
        super.onActivityResult(requestCode, resultCode, data)
    }

    // ---------------------------------------------------------------- ads: real WebView ad screen (AdOverlay), asked for by the web app
    private var stoppedAt = 0L
    private var lastSystemUiAt = 0L
    private var lastDark = false

    /** A system screen (camera, picker, permission, Play update) just returned: that is not an app "resume". */
    fun noteSystemUi() { lastSystemUiAt = SystemClock.elapsedRealtime() }

    /** The layer the ad screen is added to (above the web app, the splash and the dialogs). */
    fun adHost(): FrameLayout = root
    fun systemInsetTop(): Int = insetTopPx
    fun systemInsetBottom(): Int = insetBottomPx

    fun adDark(): Boolean = lastDark

    /** Ad screen open: status / navigation bar icons follow the app theme (dark icons on white in light mode); closed: the theme's own icons again. */
    fun adBars(on: Boolean) {
        if (!on) { applySystemBars(lastDark); return }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = !lastDark
        c.isAppearanceLightNavigationBars = !lastDark
    }

    /** Web app asked for an ad: show it and tell the page how it went (OTBridge.onAdResult). */
    fun showAdView(token: String, urlsJson: String, secsJson: String, optsJson: String? = null) {
        AdOverlay.show(this, token, urlsJson, secsJson, optsJson) { status ->
            callBridge("onAdResult", "${JSONObject.quote(token)}, ${JSONObject.quote(status)}")
        }
    }

    override fun onDestroy() {
        if (isFinishing) sessionAlive = false   // the app was really closed: next open asks for the passcode
        AdOverlay.dismiss()
        main.removeCallbacksAndMessages(null)
        net.stop()
        web?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        web = null
        if (activeInstance === this) activeInstance = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val mode = prefs.getString("theme_mode", "system") ?: "system"
        if (mode == "system") {
            val dark = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            applySystemBars(dark)
            callBridge("onSystemThemeChanged")
        }
    }

    // ---------------------------------------------------------------- WebView construction
    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(bgColor: Int): WebView {
        val wv = WebView(this)
        wv.alpha = 0f
        wv.setBackgroundColor(bgColor)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = userAgentString + " OntCoinApp/" + BuildConfig.VERSION_NAME + " OntCoinBridge/2"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, false)
        }

        wv.addJavascriptInterface(NativeBridge(this), "Android")
        wv.webViewClient = OntClient()
        wv.webChromeClient = OntChrome()
        return wv
    }

    private inner class OntClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url ?: return true
            /* Pages the web app opens inside a frame (the airdrop screen) load normally. Only top-level navigation is checked below. */
            if (!request.isForMainFrame) return false
            if (isTrustedUrl(u.toString())) return false
            openExternal(u.toString())
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            trustedPage = isTrustedUrl(url)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            CookieManager.getInstance().flush()
            if (failureShown || !isTrustedUrl(url)) return
            trustedPage = true
            if (!historyCleared) { historyCleared = true; view.clearHistory() }
            pageFinished = true
            view.settings.cacheMode = WebSettings.LOAD_DEFAULT
            main.removeCallbacks(pageTimeout)
            val token = OntCoinFirebaseMessagingService.getCachedToken(this@MainActivity)
            if (token.isNotBlank()) {
                sendFcmToken(token)
            } else {
                OntCoinFirebaseMessagingService.fetchAndCacheToken(this@MainActivity) { t ->
                    sendFcmToken(t)
                }
            }
            pushInsetsToWeb()
            pushNetworkToWeb()
            if (!webReady) {
                main.removeCallbacks(readyTimeout)
                main.postDelayed(readyTimeout, READY_TIMEOUT_MS)
                main.removeCallbacks(readyPoll)
                main.postDelayed(readyPoll, POLL_MS)
            }
        }

        // The WebView's own error page can never show: we catch every main-frame problem here.
        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val d = error.description?.toString() ?: ""
            if (d.contains("ERR_ABORTED", true)) return
            val offline = !net.refreshNow() || when (error.errorCode) {
                ERROR_HOST_LOOKUP, ERROR_CONNECT, ERROR_TIMEOUT, ERROR_IO -> true
                else -> false
            }
            showFailure(offline)
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
            if (!request.isForMainFrame) return
            if (errorResponse.statusCode >= 400) showFailure(!net.refreshNow())
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            // Never continue past a certificate problem on a wallet app. Show the dialog instead.
            handler.cancel()
            showFailure(!net.refreshNow())
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            // The WebView process died. Rebuild it silently and reload instead of crashing.
            rebuildWebView()
            return true
        }
    }

    private inner class OntChrome : WebChromeClient() {
        /** Only the OntCoin web app may use the camera, video only (never the microphone), after Android's own "Allow camera" prompt. */
        override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
            runOnUiThread {
                val res = request.resources
                val onlyVideo = res.isNotEmpty() && res.all { it == android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE }
                val originOk = request.origin?.scheme.equals("https", true) && request.origin?.host.equals(BuildConfig.APP_HOST, true)
                if (!onlyVideo || !originOk || !isAppHostPage()) { request.deny(); return@runOnUiThread }
                if (ContextCompat.checkSelfPermission(this@MainActivity, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                } else {
                    try { pendingWebPerm?.deny() } catch (_: Exception) {}
                    pendingWebPerm = request
                    webCamPermLauncher.launch(android.Manifest.permission.CAMERA)
                }
            }
        }
        override fun onPermissionRequestCanceled(request: android.webkit.PermissionRequest) { if (pendingWebPerm === request) pendingWebPerm = null }

        override fun onShowFileChooser(
            wv: WebView?,
            callback: ValueCallback<Array<Uri>>?,
            params: FileChooserParams?
        ): Boolean {
            if (!trustedPage) { callback?.onReceiveValue(null); return true }
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            return try {
                val wantsImage = params?.acceptTypes?.any { it.startsWith("image") } == true
                if (params?.isCaptureEnabled == true && wantsImage) launchCamera() else launchPicker(params)
                true
            } catch (_: Exception) {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
                false
            }
        }
    }

    private fun launchPicker(params: WebChromeClient.FileChooserParams?) {
        val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        filePickerLauncher.launch(intent)
    }

    /** Opens the phone camera (front camera hint) and returns the photo to the page's <input type=file capture>. */
    private fun launchCamera() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            cameraPermLauncher.launch(android.Manifest.permission.CAMERA); return
        }
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        val file = File.createTempFile("selfie_", ".jpg", dir)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        captureUri = uri
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            putExtra("android.intent.extras.CAMERA_FACING", 1)
            putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
            putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        cameraLauncher.launch(intent)
    }

    // ---------------------------------------------------------------- loading flow
    private val pageTimeout = Runnable { if (!pageFinished && !failureShown) showFailure(!net.refreshNow()) }
    private val readyTimeout = Runnable { if (!webReady && !failureShown) showFailure(!net.refreshNow()) }
    private val readyPoll = object : Runnable {
        override fun run() {
            if (webReady || failureShown) return
            pushInsetsToWeb()
            web?.evaluateJavascript(
                "(typeof OTBridge!=='undefined'&&typeof OTBridge.isReady==='function'&&OTBridge.isReady())?'1':'0'"
            ) { r -> if (r == "\"1\"") onWebReadyUi() }
            main.postDelayed(this, POLL_MS)
        }
    }

    private fun cancelWatchdogs() {
        main.removeCallbacks(pageTimeout)
        main.removeCallbacks(readyTimeout)
        main.removeCallbacks(readyPoll)
        main.removeCallbacks(revealRunnable)
    }

    /** (Re)starts the whole load: splash up, check connection, load the URL, wait for the web app's ready signal. */
    private fun startLoad(fresh: Boolean = false) {
        cancelWatchdogs()
        failureShown = false
        pageFinished = false
        webReady = false
        revealed = false
        historyCleared = false
        trustedPage = false
        statusDialog.hide()
        splash.animate().cancel()
        splash.alpha = 1f
        splash.scaleX = 1f; splash.scaleY = 1f
        splash.visibility = View.VISIBLE
        splashShownAt = SystemClock.uptimeMillis()
        web?.animate()?.cancel()
        web?.alpha = 0f

        if (!net.refreshNow()) { showFailure(true); return }
        val wv = web
        if (wv != null) {
            if (fresh) {
                // retry = a brand-new load: drop the HTTP cache, the old (failed) page and its history. Cookies stay, so the user stays signed in.
                wv.stopLoading()
                wv.clearCache(true)
                wv.clearHistory()
                wv.settings.cacheMode = WebSettings.LOAD_NO_CACHE
                wv.loadUrl(BuildConfig.APP_URL, mapOf("Cache-Control" to "no-cache", "Pragma" to "no-cache"))
            } else {
                wv.settings.cacheMode = WebSettings.LOAD_DEFAULT
                wv.loadUrl(BuildConfig.APP_URL)
            }
        }
        main.postDelayed(pageTimeout, PAGE_TIMEOUT_MS)
    }

    private fun showFailure(offline: Boolean) {
        if (isFinishing || isDestroyed || failureShown) return
        cancelWatchdogs()
        failureShown = true
        revealed = false
        trustedPage = false
        web?.stopLoading()
        web?.animate()?.cancel()
        web?.alpha = 0f
        splash.animate().cancel()
        splash.alpha = 1f
        splash.visibility = View.VISIBLE
        statusDialog.show(offline)
    }

    private fun rebuildWebView() {
        val old = web
        val dark = resolveDark(prefs.getString("theme_mode", "system") ?: "system")
        val bg = Color.parseColor(if (dark) "#09070E" else "#F4F3F7")
        if (old != null) {
            (old.parent as? ViewGroup)?.removeView(old)
            old.destroy()
        }
        val fresh = createWebView(bg)
        web = fresh
        root.addView(fresh, 0, webLp())
        startLoad()
    }

    fun reloadApp() = startLoad(fresh = true)

    // Web app -> native: "I am loaded" / "I cannot start"
    fun onWebReadyFromWeb(payload: String?) {
        if (!payload.isNullOrBlank()) {
            try {
                val o = JSONObject(payload)
                if (o.has("ok") && !o.optBoolean("ok", true)) { showFailure(!net.refreshNow()); return }
            } catch (_: Exception) { /* a plain "ready" is fine too */ }
        }
        onWebReadyUi()
    }

    fun onWebFailedFromWeb(reason: String?) {
        showFailure(!net.refreshNow())
    }

    private val revealRunnable = Runnable { reveal() }

    private fun onWebReadyUi() {
        if (webReady || failureShown) return
        webReady = true
        main.removeCallbacks(pageTimeout)
        main.removeCallbacks(readyTimeout)
        main.removeCallbacks(readyPoll)
        val wait = (MIN_SPLASH_MS - (SystemClock.uptimeMillis() - splashShownAt)).coerceAtLeast(0L)
        main.postDelayed(revealRunnable, wait)
    }

    /** Crossfade: loading screen out, web app in. Only reachable after the web app confirmed it is ready. */
    private fun reveal() {
        if (revealed || failureShown || !webReady) return
        revealed = true
        pushInsetsToWeb()
        val wv = web
        if (wv != null) {
            wv.scaleX = 1.02f; wv.scaleY = 1.02f
            wv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520L)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        }
        splash.animate().alpha(0f).scaleX(1.04f).scaleY(1.04f).setStartDelay(120L).setDuration(460L)
            .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator()).withEndAction {
                splash.scaleX = 1f; splash.scaleY = 1f
                if (revealed) splash.visibility = View.GONE
            }.start()
        pushNetworkToWeb()
        pendingLink?.let { callBridge("onLink", JSONObject.quote(it)); pendingLink = null }
        // notification permission is requested by the web app once the dashboard is showing
    }

    // ---------------------------------------------------------------- network <-> web
    fun networkOnline(): Boolean = net.online
    fun networkType(): String = net.type

    private fun onNetworkChanged(online: Boolean, type: String) {
        AdOverlay.onNetwork(online)           // losing the internet during an ad: the reward is not given
        if (revealed) pushNetworkToWeb()
        if (online && failureShown) {
            main.postDelayed({ if (failureShown) startLoad(fresh = true) }, 600L) // reconnect automatically
        }
        if (!online && !webReady && !failureShown) showFailure(true)
    }

    fun pushNetworkToWeb() {
        callBridge("onNetwork", "${net.online}, ${JSONObject.quote(net.type)}")
    }

    // ---------------------------------------------------------------- native -> web calls
    /** Calls OTBridge.<fn>(args) in the web app if it exists. Must be called on the main thread. */
    fun callBridge(fn: String, args: String = "") {
        val js = "(function(){try{return typeof OTBridge!=='undefined'&&typeof OTBridge.$fn==='function'?OTBridge.$fn($args):null}catch(e){return null}})()"
        web?.evaluateJavascript(js, null)
    }

    fun sendFcmToken(token: String) = callBridge("onFcmToken", JSONObject.quote(token))

    // ---------------------------------------------------------------- back button
    private fun onBack() {
        if (AdOverlay.handleBack()) return       // the ad screen is open: Back is used by it (locked until the countdown ends)
        if (!revealed || failureShown) { finishAffinity(); return }
        val wv = web ?: run { finish(); return }
        wv.evaluateJavascript("(function(){try{return typeof OTBridge!=='undefined'&&typeof OTBridge.onBack==='function'?OTBridge.onBack():false}catch(e){return false}})()") { result ->
            if (result != "true" && result != "\"true\"") {
                if (wv.canGoBack()) wv.goBack() else finish()
            }
        }
    }

    // ---------------------------------------------------------------- links
    private fun handleIntent(i: Intent?) {
        val link = i?.data?.toString() ?: i?.getStringExtra("link")
        if (link.isNullOrBlank()) return
        if (revealed) callBridge("onLink", JSONObject.quote(link)) else pendingLink = link
    }

    private fun isTrustedUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val u = Uri.parse(url)
        if (!u.scheme.equals("https", true)) return false
        if (u.host.equals(BuildConfig.APP_HOST, true)) return true
        /* survey pages are hosted on the website domain; nothing else on that domain is trusted */
        return u.host.equals(BuildConfig.SITE_HOST, true) && (u.path ?: "").startsWith("/sv/")
    }

    private fun isAppHostPage(): Boolean = trustedPage && (web?.url?.let { Uri.parse(it).host.equals(BuildConfig.APP_HOST, true) } == true)

    fun openExternal(url: String) {
        val uri = try { Uri.parse(url) } catch (_: Exception) { return }
        when (uri.scheme?.lowercase()) {
            "http", "https" -> try {
                CustomTabsIntent.Builder().build().launchUrl(this, uri)
            } catch (_: Exception) {
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
            }
            "mailto", "tel", "sms" -> try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
            else -> { /* blocked: intent:, file:, javascript:, ... */ }
        }
    }

    /** A link the person tapped inside an ad: Play Store links open the Play Store app, everything else a Chrome tab (outside the ad screen). */
    fun openAdLink(url: String) {
        noteSystemUi()
        val uri = try { Uri.parse(url) } catch (_: Exception) { return }
        val host = (uri.host ?: "").lowercase()
        val web = uri.scheme?.lowercase().let { it == "http" || it == "https" }
        if (web && (host == "play.google.com" || host == "market.android.com")) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
        }
        openExternal(url)
    }

    // ---------------------------------------------------------------- Google Play Store In-App Updates
    private var appUpdateManager: AppUpdateManager? = null

    fun checkPlayStoreUpdate(interactive: Boolean = false) {
        try {
            val mgr = appUpdateManager ?: AppUpdateManagerFactory.create(this).also { appUpdateManager = it }
            mgr.appUpdateInfo.addOnSuccessListener { info ->
                val avail = info.updateAvailability()
                if (avail == UpdateAvailability.UPDATE_AVAILABLE) {
                    if (info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                        try {
                            mgr.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 9001)
                        } catch (_: Exception) {
                            if (interactive) openGooglePlayStore()
                        }
                    } else if (interactive) {
                        openGooglePlayStore()
                    }
                } else if (avail == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    try {
                        mgr.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 9001)
                    } catch (_: Exception) {}
                } else if (interactive) {
                    openGooglePlayStore()
                }
            }.addOnFailureListener {
                if (interactive) openGooglePlayStore()
            }
        } catch (_: Exception) {
            if (interactive) openGooglePlayStore()
        }
    }

    fun openGooglePlayStore() {
        val pkg = packageName
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
                setPackage("com.android.vending")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(marketIntent)
        } catch (_: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(webIntent)
            } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------- permissions
    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun notificationsEnabled(): Boolean = NotificationManagerCompat.from(this).areNotificationsEnabled()

    // ---------------------------------------------------------------- WebView camera (face check runs inside the web app)
    private var pendingWebPerm: android.webkit.PermissionRequest? = null
    private val webCamPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val r = pendingWebPerm; pendingWebPerm = null
        try { if (granted) r?.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else r?.deny() } catch (_: Exception) {}
    }

    fun openAppSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {}
    }

    /** Country from the IP address only. No location permission exists in this app. */
    fun requestLocation() { fetchAndSendLocation() }

    private fun fetchAndSendLocation() {
        device.fetchLocation { loc -> callBridge("onLocation", loc?.toString() ?: "null") }
    }

    // ---------------------------------------------------------------- biometrics
    fun isBiometricAvailable(): Boolean {
        val bm = BiometricManager.from(this)
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticateBiometric() {
        if (!isBiometricAvailable()) { notifyBiometric(false); return }
        val executor = ContextCompat.getMainExecutor(this)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_title))
            .setSubtitle(getString(R.string.biometric_subtitle))
            .setNegativeButtonText(getString(R.string.cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = notifyBiometric(true)
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = notifyBiometric(false)
            override fun onAuthenticationFailed() {}
        }).authenticate(info)
    }

    private fun notifyBiometric(ok: Boolean) = runOnUiThread { callBridge("onBiometric", ok.toString()) }

    // ---------------------------------------------------------------- theme / system bars
    fun resolveDark(mode: String): Boolean = when (mode.lowercase()) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun applySystemBars(dark: Boolean) {
        lastDark = dark
        // The bars stay transparent: the web page's own background shows through them. Only the icon colour follows the theme.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }

    // ---------------------------------------------------------------- phone hardware helpers
    private fun vibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) { null }

    fun haptic(ms: Int) {
        try {
            val d = ms.coerceIn(1, 1000).toLong()
            val v = vibrator() ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(d)
            }
        } catch (_: Exception) {}
    }

    fun hapticType(type: String) {
        val pattern: LongArray = when (type) {
            "tick" -> longArrayOf(0, 8)
            "heavy" -> longArrayOf(0, 38)
            "success" -> longArrayOf(0, 12, 70, 24)
            "error" -> longArrayOf(0, 40, 60, 40)
            else -> longArrayOf(0, 18)
        }
        try {
            val v = vibrator() ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                v.vibrate(pattern, -1)
            }
        } catch (_: Exception) {}
    }

    fun shareText(text: String, title: String?) {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(send, title ?: getString(R.string.share_title)))
        } catch (_: Exception) {}
    }

    fun copyToClipboard(text: String): Boolean = try {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("OntCoin", text))
        true
    } catch (_: Exception) { false }

    fun setSecureScreen(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
