package com.example

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.startapp.sdk.adsbase.adlisteners.VideoListener
import java.lang.ref.WeakReference

/**
 * Start.io (StartApp) ads for OntCoin. Two formats only:
 *  - rewarded video: the web app asks for it (Android.showRewardedAd) before "Start mining" and before "Claim".
 *    Whatever happens (no fill, no internet, SDK not ready, timeout) the answer comes back and the web app carries on.
 *  - interstitial: shown when the user comes back to the app (on resume), never at first launch and never after
 *    camera / file picker / permission / Play-update screens.
 *
 * All calls must be made on the main thread.
 */
object AdsManager {

    // ---------------------------------------------------------------- tuning
    private const val LOAD_TIMEOUT_MS = 10_000L          // rewarded: max wait for an ad to load
    private const val DISPLAY_TIMEOUT_MS = 8_000L        // only used when showAd() itself reports a problem
    private const val RESUME_MIN_AWAY_MS = 20_000L        // must have been away at least this long to count as "resume"
    private const val RESUME_COOLDOWN_MS = 45_000L          // minimum gap between two interstitials of any kind
    private const val AFTER_REWARDED_QUIET_MS = 30_000L  // no interstitial right after a rewarded video
    private const val AFTER_AD_QUIET_MS = 4_000L         // no resume ad right after any other ad or system screen
    private const val AD_MAX_AGE_MS = 20 * 60_000L       // a preloaded ad older than this is thrown away
    private const val RETRY_LOAD_MS = 30_000L
    private const val TOUCH_QUIET_MS = 1_800L            // no ad until the user has not touched the screen for this long
    private const val NOTICE_SECONDS = 3                 // "ad starts in 3, 2, 1" card before every interstitial
    /** false: mining/claim go ahead as soon as the video is closed. true: only after it was watched to the end. */
    private const val REQUIRE_FULL_WATCH = false

    private val main = Handler(Looper.getMainLooper())
    private var act: WeakReference<Activity>? = null

    private var initStarted = false
    @Volatile var enabled = false          // SDK init call went through without crashing
        private set
    private var sdkReady = false           // SDK finished initialising

    private var interstitial: StartAppAd? = null
    private var interstitialAt = 0L
    private var interstitialLoading = false

    private var rewarded: StartAppAd? = null
    private var rewardedAt = 0L
    private var rewardedLoading = false

    /** True from showAd() until the ad is hidden. Used so nothing else is shown on top and resume logic ignores it. */
    @Volatile var showing = false
        private set

    private var lastAdEndedAt = 0L
    private var lastRewardedEndedAt = 0L
    private var inDashboard = false           // set by the web app: signed in and on the dashboard (not login / onboarding / lock)
    private var dashWhenLeft = false           // was the user inside the dashboard when the app went to the background?
    private var shownAtMs = 0L                 // when the current ad was handed to showAd()
    private var lastSystemUiAt = 0L
    private var lastInterstitialAt = 0L
    private var backgroundedAt = 0L
    private var lastTouchAt = 0L
    private var gateRunning = false
    private var gateTask: Runnable? = null
    private var noticeView: android.view.View? = null

    private class Pending(val token: String, val cb: (String) -> Unit) {
        var done = false
        var timeout: Runnable? = null
        var displayWatch: Runnable? = null
        var completed = false
    }
    private var pending: Pending? = null

    private fun now() = SystemClock.elapsedRealtime()
    private fun activity(): Activity? = act?.get()?.takeIf { !it.isFinishing && !it.isDestroyed }

    // ---------------------------------------------------------------- lifecycle (called by MainActivity)
    fun init(a: Activity) {
        act = WeakReference(a)
        if (initStarted) return
        initStarted = true
        try {
            // TEST ads while BuildConfig.STARTIO_TEST_ADS is true (gradle.properties: STARTIO_TEST_ADS)
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST_ADS)
            StartAppSDK.initParams(a.applicationContext, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)       // we show our own resume interstitial
                .setCallback {
                    main.post {
                        sdkReady = true
                        preloadInterstitial()
                        preloadRewarded()
                    }
                }
                .init()
            enabled = true
        } catch (_: Throwable) {
            enabled = false
        }
    }

    /** The activity instance changed (re-created): ads must be created with the live activity, so drop the old ones. */
    fun attach(a: Activity) {
        if (act?.get() !== a) {
            act = WeakReference(a)
            interstitial = null; rewarded = null
            interstitialLoading = false; rewardedLoading = false
            if (sdkReady) { preloadInterstitial(); preloadRewarded() }
        }
    }

    fun detach(a: Activity) {
        if (act?.get() === a) {
            act = null
            gateTask?.let { main.removeCallbacks(it) }; dismissNotice(); gateRunning = false
            interstitial = null; rewarded = null
            interstitialLoading = false; rewardedLoading = false
            finishRewarded("failed")
        }
    }

    /** A system screen (camera, picker, permission, Play update) just returned: do not show a resume ad for it. */
    fun noteSystemUi() { lastSystemUiAt = now() }

    /** The web app tells us whether the user is inside the dashboard (signed in) right now. */
    fun setDashboard(on: Boolean) { inDashboard = on }

    fun noteTouch() { lastTouchAt = now() }

    private fun dismissNotice() {
        val v = noticeView ?: return
        noticeView = null
        try { (v.parent as? android.view.ViewGroup)?.removeView(v) } catch (_: Throwable) {}
    }

    fun onBackgrounded() {
        if (gateRunning) { gateTask?.let { main.removeCallbacks(it) }; dismissNotice(); gateRunning = false }
        if (showing || pending != null) return          // the app is only covered by one of our own ads
        if (now() - lastSystemUiAt < AFTER_AD_QUIET_MS * 3) return
        backgroundedAt = now()
        dashWhenLeft = inDashboard
    }

    /** Called from onResume. */
    fun onResumed(a: Activity) {
        // An ad was on screen and the app is visible again: the ad has been closed by the user.
        if (showing && shownAtMs != 0L && now() - shownAtMs > 1_500L) {
            if (pending != null) finishRewarded(if (pending?.completed == true) "completed" else "closed")
            else { showing = false; lastAdEndedAt = now(); preloadInterstitial() }
        }
        val away = backgroundedAt
        val wasInDash = dashWhenLeft
        backgroundedAt = 0L
        if (away == 0L || !wasInDash) return                    // only when the user left from inside the dashboard
        if (now() - away < RESUME_MIN_AWAY_MS) return
        showInterstitial()
    }

    /** Called by the web app after the user opened a few screens inside the dashboard. */
    fun showNavInterstitial() {
        if (!inDashboard) return
        showInterstitial()
    }

    /**
     * Gentle interstitial: wait until the user has stopped touching the screen, then show a small "Sponsor break - ad starts in 3" card
     * that swallows taps (so a late tap can never land on the ad), and only then show the ad.
     */
    private fun showInterstitial() {
        if (gateRunning || !enabled || !sdkReady || showing || pending != null) return
        gateRunning = true
        waitIdle(0)
    }

    private fun waitIdle(tries: Int) {
        if (!gateRunning) return
        if (showing || pending != null || activity() == null) { gateRunning = false; return }
        if (now() - lastTouchAt >= TOUCH_QUIET_MS) { showNotice(); return }
        if (tries >= 10) { gateRunning = false; return }        // user is busy: skip this one, never interrupt
        val r = Runnable { waitIdle(tries + 1) }
        gateTask = r
        main.postDelayed(r, 400L)
    }

    private fun showNotice() {
        val a = activity() ?: run { gateRunning = false; return }
        try {
            val d = a.resources.displayMetrics.density
            val box = android.widget.FrameLayout(a)
            box.setBackgroundColor(0xB3000000.toInt())
            box.isClickable = true; box.isFocusable = true
            val card = android.widget.LinearLayout(a)
            card.orientation = android.widget.LinearLayout.VERTICAL
            card.gravity = android.view.Gravity.CENTER
            val bg = android.graphics.drawable.GradientDrawable()
            bg.setColor(0xFF1B1426.toInt()); bg.cornerRadius = 22 * d
            card.background = bg
            card.setPadding((28 * d).toInt(), (22 * d).toInt(), (28 * d).toInt(), (22 * d).toInt())
            val title = android.widget.TextView(a)
            title.text = "Short sponsor break"
            title.setTextColor(0xFFFFFFFF.toInt()); title.textSize = 17f
            title.typeface = android.graphics.Typeface.DEFAULT_BOLD
            title.gravity = android.view.Gravity.CENTER
            val sub = android.widget.TextView(a)
            sub.setTextColor(0xFFB9B2C8.toInt()); sub.textSize = 14f
            sub.gravity = android.view.Gravity.CENTER
            sub.setPadding(0, (6 * d).toInt(), 0, 0)
            card.addView(title); card.addView(sub)
            box.addView(card, android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER))
            (a.window.decorView as android.view.ViewGroup).addView(box, android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
            noticeView = box
            var left = NOTICE_SECONDS
            lateinit var tick: Runnable
            tick = Runnable {
                if (!gateRunning || noticeView !== box) return@Runnable
                if (left <= 0) {
                    dismissNotice(); gateRunning = false
                    showInterstitialNow()
                } else {
                    sub.text = "Ad starts in $left\u2026"
                    left--
                    gateTask = tick
                    main.postDelayed(tick, 1000L)
                }
            }
            tick.run()
        } catch (_: Throwable) { dismissNotice(); gateRunning = false }
    }

    /** One place decides whether an interstitial may appear now, then shows it. Closed only by the user. */
    private fun showInterstitialNow() {
        if (!enabled || !sdkReady || showing || pending != null) return
        val t = now()
        if (lastInterstitialAt != 0L && t - lastInterstitialAt < RESUME_COOLDOWN_MS) return
        if (lastRewardedEndedAt != 0L && t - lastRewardedEndedAt < AFTER_REWARDED_QUIET_MS) return
        if (t - lastAdEndedAt < AFTER_AD_QUIET_MS || t - lastSystemUiAt < AFTER_AD_QUIET_MS) return
        val ad = takeInterstitial()
        if (ad == null) { preloadInterstitial(); return }
        lastInterstitialAt = t
        showing = true
        shownAtMs = t
        var finished = false
        fun finish() {
            if (finished) return
            finished = true; showing = false; lastAdEndedAt = now(); preloadInterstitial()
        }
        try {
            val ok = ad.showAd(object : AdDisplayListener {
                override fun adHidden(p0: Ad?) { finish() }
                override fun adDisplayed(p0: Ad?) { showing = true }
                override fun adClicked(p0: Ad?) {}
                override fun adNotDisplayed(p0: Ad?) { finish() }
            })
            if (!ok) finish()
        } catch (_: Throwable) { finish() }
    }

    // ---------------------------------------------------------------- preloading
    private fun takeInterstitial(): StartAppAd? {
        val ad = interstitial
        interstitial = null
        return if (ad != null && now() - interstitialAt < AD_MAX_AGE_MS) ad else null
    }

    private fun preloadInterstitial() {
        val a = activity() ?: return
        if (!sdkReady || interstitialLoading) return
        if (interstitial != null && now() - interstitialAt < AD_MAX_AGE_MS) return
        interstitialLoading = true
        try {
            val ad = StartAppAd(a)
            ad.loadAd(object : AdEventListener {
                override fun onReceiveAd(p0: Ad) { main.post { interstitialLoading = false; interstitial = ad; interstitialAt = now() } }
                override fun onFailedToReceiveAd(p0: Ad?) { main.post { interstitialLoading = false; main.postDelayed({ preloadInterstitial() }, RETRY_LOAD_MS) } }
            })
        } catch (_: Throwable) { interstitialLoading = false }
    }

    private fun preloadRewarded() {
        val a = activity() ?: return
        if (!sdkReady || rewardedLoading) return
        if (rewarded != null && now() - rewardedAt < AD_MAX_AGE_MS) return
        rewardedLoading = true
        try {
            val ad = StartAppAd(a)
            ad.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
                override fun onReceiveAd(p0: Ad) {
                    main.post { rewardedLoading = false; rewarded = ad; rewardedAt = now(); showPendingRewarded() }
                }
                override fun onFailedToReceiveAd(p0: Ad?) {
                    main.post {
                        rewardedLoading = false
                        // someone is waiting: tell them now instead of making them wait for the timeout
                        if (pending != null) finishRewarded("failed") else main.postDelayed({ preloadRewarded() }, RETRY_LOAD_MS)
                    }
                }
            })
        } catch (_: Throwable) { rewardedLoading = false; if (pending != null) finishRewarded("failed") }
    }

    // ---------------------------------------------------------------- rewarded video (asked for by the web app)
    /**
     * Shows a rewarded video and reports back through [cb] with exactly one final status:
     *  "completed" - watched to the end and closed
     *  "closed"    - closed early
     *  "failed"    - no ad could be shown (no fill, no internet, SDK not ready, timeout)
     * and, before the final one, possibly "showing" once the ad is on screen.
     * The web app treats every final status as "go ahead" (unless REQUIRE_FULL_WATCH and the status is "closed").
     */
    fun showRewarded(a: Activity, token: String, cb: (String) -> Unit) {
        if (!enabled || showing || pending != null || activity() == null) { cb("failed"); return }
        val p = Pending(token, cb)
        pending = p
        val t = Runnable { if (pending === p && !p.completed) finishRewarded("failed") }
        p.timeout = t
        main.postDelayed(t, LOAD_TIMEOUT_MS)
        if (rewarded != null && now() - rewardedAt >= AD_MAX_AGE_MS) rewarded = null
        if (rewarded != null) showPendingRewarded() else preloadRewarded()
    }

    private fun showPendingRewarded() {
        val p = pending ?: return
        if (p.done || showing) return
        val ad = rewarded ?: return
        rewarded = null
        p.timeout?.let { main.removeCallbacks(it) }
        showing = true
        shownAtMs = now()
        try {
            ad.setVideoListener(object : VideoListener {
                override fun onVideoCompleted() { p.completed = true }
            })
            val ok = ad.showAd(object : AdDisplayListener {
                override fun adDisplayed(x: Ad?) { showing = true }
                override fun adHidden(x: Ad?) { finishRewarded(if (p.completed) "completed" else "closed") }
                override fun adClicked(x: Ad?) {}
                override fun adNotDisplayed(x: Ad?) { finishRewarded("failed") }
            })
            if (!ok) { finishRewarded("failed"); return }
            // the ad is on screen: tell the page to wait for the user to close it (the app never closes an ad itself)
            if (!p.done) p.cb("showing")
        } catch (_: Throwable) { finishRewarded("failed") }
    }

    private fun finishRewarded(status: String) {
        val p = pending ?: return
        if (p.done) return
        p.done = true
        pending = null
        p.timeout?.let { main.removeCallbacks(it) }
        showing = false
        lastAdEndedAt = now()
        lastRewardedEndedAt = now()
        val out = if (status == "closed" && !REQUIRE_FULL_WATCH) "completed" else status
        try { p.cb(out) } catch (_: Throwable) {}
        preloadRewarded()          // a rewarded ad can only be shown once: get the next one ready
    }

    fun isReady(): Boolean = enabled
}
