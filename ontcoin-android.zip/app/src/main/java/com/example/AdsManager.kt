package com.example

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.startapp.sdk.adsbase.adlisteners.VideoListener
import java.lang.ref.WeakReference

/**
 * Start.io (StartApp) ads for OntCoin. Two formats only:
 *  - rewarded video: the web app asks for it (Android.showRewardedAd) before "Start mining" and before "Claim".
 *    Whatever happens (no fill, no internet, SDK not ready, timeout) the answer comes back and the web app carries on.
 *  - interstitial: shown when the user comes back to the app (on resume), never at first launch and never after
 *    camera / file picker / permission / Play-update screens.
 *
 * All calls must be made on the main thread.
 */
object AdsManager {

    // ---------------------------------------------------------------- tuning
    private const val LOAD_TIMEOUT_MS = 10_000L          // rewarded: max wait for an ad to load
    private const val DISPLAY_TIMEOUT_MS = 8_000L        // max wait between showAd() and the ad actually appearing
    private const val RESUME_MIN_AWAY_MS = 5_000L        // must have been away at least this long to count as "resume"
    private val RESUME_COOLDOWN_MS = if (BuildConfig.STARTIO_TEST_ADS) 30_000L else 90_000L   // gap between two resume interstitials (short while testing)
    private const val FIRST_QUIET_MS = 45_000L           // no resume ad in the first moments after the app was opened
    private const val AFTER_REWARDED_QUIET_MS = 60_000L  // no resume ad right after a rewarded video
    private const val AFTER_AD_QUIET_MS = 4_000L         // no resume ad right after any other ad or system screen
    private const val AD_MAX_AGE_MS = 20 * 60_000L       // a preloaded ad older than this is thrown away
    private const val RETRY_LOAD_MS = 30_000L
    /** false: mining/claim go ahead as soon as the video is closed. true: only after it was watched to the end. */
    private const val REQUIRE_FULL_WATCH = false

    private val main = Handler(Looper.getMainLooper())
    private var act: WeakReference<Activity>? = null

    private var initStarted = false
    @Volatile var enabled = false          // SDK init call went through without crashing
        private set
    private var sdkReady = false           // SDK finished initialising

    private var interstitial: StartAppAd? = null
    private var interstitialAt = 0L
    private var interstitialLoading = false

    private var rewarded: StartAppAd? = null
    private var rewardedAt = 0L
    private var rewardedLoading = false

    /** True from showAd() until the ad is hidden. Used so nothing else is shown on top and resume logic ignores it. */
    @Volatile var showing = false
        private set

    private var lastAdEndedAt = 0L
    private var lastRewardedEndedAt = 0L
    private val startedAt = SystemClock.elapsedRealtime()
    private var lastSystemUiAt = 0L
    private var lastResumeAdAt = 0L
    private var backgroundedAt = 0L

    private class Pending(val token: String, val cb: (String) -> Unit) {
        var done = false
        var timeout: Runnable? = null
        var displayWatch: Runnable? = null
        var completed = false
    }
    private var pending: Pending? = null

    private fun now() = SystemClock.elapsedRealtime()
    private fun activity(): Activity? = act?.get()?.takeIf { !it.isFinishing && !it.isDestroyed }

    // ---------------------------------------------------------------- lifecycle (called by MainActivity)
    fun init(a: Activity) {
        act = WeakReference(a)
        if (initStarted) return
        initStarted = true
        try {
            // TEST ads while BuildConfig.STARTIO_TEST_ADS is true (gradle.properties: STARTIO_TEST_ADS)
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST_ADS)
            StartAppSDK.initParams(a.applicationContext, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)       // we show our own resume interstitial
                .setCallback {
                    main.post {
                        sdkReady = true
                        preloadInterstitial()
                        preloadRewarded()
                    }
                }
                .init()
            enabled = true
        } catch (_: Throwable) {
            enabled = false
        }
    }

    /** The activity instance changed (re-created): ads must be created with the live activity, so drop the old ones. */
    fun attach(a: Activity) {
        if (act?.get() !== a) {
            act = WeakReference(a)
            interstitial = null; rewarded = null
            interstitialLoading = false; rewardedLoading = false
            if (sdkReady) { preloadInterstitial(); preloadRewarded() }
        }
    }

    fun detach(a: Activity) {
        if (act?.get() === a) {
            act = null
            interstitial = null; rewarded = null
            interstitialLoading = false; rewardedLoading = false
            finishRewarded("failed")
        }
    }

    /** A system screen (camera, picker, permission, Play update) just returned: do not show a resume ad for it. */
    fun noteSystemUi() { lastSystemUiAt = now() }

    fun onBackgrounded() {
        if (showing || pending != null) return          // the app is only covered by one of our own ads
        if (now() - lastSystemUiAt < AFTER_AD_QUIET_MS * 3) return
        backgroundedAt = now()
    }

    /** Called from onResume. Shows the interstitial if the user really came back to the app. */
    fun onResumed(a: Activity) {
        val away = backgroundedAt
        backgroundedAt = 0L
        if (away == 0L || !enabled || !sdkReady) return
        val t = now()
        if (showing || pending != null) return
        if (t - away < RESUME_MIN_AWAY_MS) return
        if (t - lastResumeAdAt < RESUME_COOLDOWN_MS) return
        if (t - startedAt < FIRST_QUIET_MS) return
        if (lastRewardedEndedAt != 0L && t - lastRewardedEndedAt < AFTER_REWARDED_QUIET_MS) return
        if (t - lastAdEndedAt < AFTER_AD_QUIET_MS || t - lastSystemUiAt < AFTER_AD_QUIET_MS) return
        val ad = takeInterstitial()
        if (ad == null) { preloadInterstitial(); return }
        lastResumeAdAt = t
        showing = true
        var finished = false
        fun finish() {
            if (finished) return
            finished = true; showing = false; lastAdEndedAt = now(); preloadInterstitial()
        }
        val watch = Runnable { finish() }
        main.postDelayed(watch, DISPLAY_TIMEOUT_MS)
        try {
            val ok = ad.showAd(object : AdDisplayListener {
                override fun adHidden(p0: Ad?) { main.removeCallbacks(watch); finish() }
                override fun adDisplayed(p0: Ad?) { main.removeCallbacks(watch); showing = true }
                override fun adClicked(p0: Ad?) {}
                override fun adNotDisplayed(p0: Ad?) { main.removeCallbacks(watch); finish() }
            })
            if (!ok) { main.removeCallbacks(watch); finish() }
        } catch (_: Throwable) { main.removeCallbacks(watch); finish() }
    }

    // ---------------------------------------------------------------- preloading
    private fun takeInterstitial(): StartAppAd? {
        val ad = interstitial
        interstitial = null
        return if (ad != null && now() - interstitialAt < AD_MAX_AGE_MS) ad else null
    }

    private fun preloadInterstitial() {
        val a = activity() ?: return
        if (!sdkReady || interstitialLoading) return
        if (interstitial != null && now() - interstitialAt < AD_MAX_AGE_MS) return
        interstitialLoading = true
        try {
            val ad = StartAppAd(a)
            ad.loadAd(object : AdEventListener {
                override fun onReceiveAd(p0: Ad) { main.post { interstitialLoading = false; interstitial = ad; interstitialAt = now() } }
                override fun onFailedToReceiveAd(p0: Ad?) { main.post { interstitialLoading = false; main.postDelayed({ preloadInterstitial() }, RETRY_LOAD_MS) } }
            })
        } catch (_: Throwable) { interstitialLoading = false }
    }

    private fun preloadRewarded() {
        val a = activity() ?: return
        if (!sdkReady || rewardedLoading) return
        if (rewarded != null && now() - rewardedAt < AD_MAX_AGE_MS) return
        rewardedLoading = true
        try {
            val ad = StartAppAd(a)
            ad.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
                override fun onReceiveAd(p0: Ad) {
                    main.post { rewardedLoading = false; rewarded = ad; rewardedAt = now(); showPendingRewarded() }
                }
                override fun onFailedToReceiveAd(p0: Ad?) {
                    main.post {
                        rewardedLoading = false
                        // someone is waiting: tell them now instead of making them wait for the timeout
                        if (pending != null) finishRewarded("failed") else main.postDelayed({ preloadRewarded() }, RETRY_LOAD_MS)
                    }
                }
            })
        } catch (_: Throwable) { rewardedLoading = false; if (pending != null) finishRewarded("failed") }
    }

    // ---------------------------------------------------------------- rewarded video (asked for by the web app)
    /**
     * Shows a rewarded video and reports back through [cb] with exactly one final status:
     *  "completed" - watched to the end and closed
     *  "closed"    - closed early
     *  "failed"    - no ad could be shown (no fill, no internet, SDK not ready, timeout)
     * and, before the final one, possibly "showing" once the ad is on screen.
     * The web app treats every final status as "go ahead" (unless REQUIRE_FULL_WATCH and the status is "closed").
     */
    fun showRewarded(a: Activity, token: String, cb: (String) -> Unit) {
        if (!enabled || showing || pending != null || activity() == null) { cb("failed"); return }
        val p = Pending(token, cb)
        pending = p
        val t = Runnable { if (pending === p && !p.completed) finishRewarded("failed") }
        p.timeout = t
        main.postDelayed(t, LOAD_TIMEOUT_MS)
        if (rewarded != null && now() - rewardedAt >= AD_MAX_AGE_MS) rewarded = null
        if (rewarded != null) showPendingRewarded() else preloadRewarded()
    }

    private fun showPendingRewarded() {
        val p = pending ?: return
        if (p.done || showing) return
        val ad = rewarded ?: return
        rewarded = null
        p.timeout?.let { main.removeCallbacks(it) }
        showing = true
        val watch = Runnable { if (pending === p) finishRewarded("failed") }
        p.displayWatch = watch
        main.postDelayed(watch, DISPLAY_TIMEOUT_MS)
        try {
            ad.setVideoListener(object : VideoListener {
                override fun onVideoCompleted() { p.completed = true }
            })
            val ok = ad.showAd(object : AdDisplayListener {
                override fun adDisplayed(x: Ad?) {
                    main.removeCallbacks(watch); p.displayWatch = null
                    showing = true
                    if (!p.done) p.cb("showing")
                }
                override fun adHidden(x: Ad?) { finishRewarded(if (p.completed) "completed" else "closed") }
                override fun adClicked(x: Ad?) {}
                override fun adNotDisplayed(x: Ad?) { finishRewarded("failed") }
            })
            if (!ok) finishRewarded("failed")
        } catch (_: Throwable) { finishRewarded("failed") }
    }

    private fun finishRewarded(status: String) {
        val p = pending ?: return
        if (p.done) return
        p.done = true
        pending = null
        p.timeout?.let { main.removeCallbacks(it) }
        p.displayWatch?.let { main.removeCallbacks(it) }
        showing = false
        lastAdEndedAt = now()
        lastRewardedEndedAt = now()
        val out = if (status == "closed" && !REQUIRE_FULL_WATCH) "completed" else status
        try { p.cb(out) } catch (_: Throwable) {}
        preloadRewarded()          // a rewarded ad can only be shown once: get the next one ready
    }

    fun isReady(): Boolean = enabled
}
