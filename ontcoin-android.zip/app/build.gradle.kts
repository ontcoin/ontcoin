import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.google.services)
}

/** A setting from the environment (GitHub secrets) first, then gradle.properties. Blank values are ignored. */
fun setting(name: String): String? =
  listOf(System.getenv(name), project.findProperty(name) as? String).firstOrNull { !it.isNullOrBlank() }

android {
  namespace = "com.example"
  compileSdk = 36

  defaultConfig {
    applicationId = "com.ontcoin.network.linexware"
    minSdk = 24
    targetSdk = 36
    // GitHub sets VERSION_CODE (always rising). A local build uses 31.
    versionCode = setting("VERSION_CODE")?.toIntOrNull() ?: 32
    versionName = "3.1"

    buildConfigField("String", "APP_URL", "\"https://ontcoin.linexware.net.ng/web/\"")
    buildConfigField("String", "APP_HOST", "\"ontcoin.linexware.net.ng\"")
    // Website domain: its /sv/ pages are also trusted inside the app.
    buildConfigField("String", "SITE_HOST", "\"ontcoin.space\"")
    // Signs the "app proof" header. Must be identical to OT_APP_SECRET in the web APIs/config.php.
    buildConfigField("String", "APP_SECRET", "\"${setting("APP_SECRET") ?: ""}\"")
    // Start.io (StartApp) ads. STARTIO_TEST_ADS=true shows TEST ads only. Set it to false in gradle.properties for the live release.
    val startioAppId = setting("STARTIO_APP_ID") ?: "210874116"
    val startioTest = (setting("STARTIO_TEST_ADS") ?: "false").trim().lowercase() != "false"
    buildConfigField("String", "STARTIO_APP_ID", "\"$startioAppId\"")
    buildConfigField("boolean", "STARTIO_TEST_ADS", startioTest.toString())
    manifestPlaceholders["startioAppId"] = startioAppId
    manifestPlaceholders["appUrlHost"] = "ontcoin.linexware.net.ng"
  }

  signingConfigs {
    create("release") {
      val keystoreFile = file(setting("KEYSTORE_PATH") ?: "build.jks")
      if (keystoreFile.exists()) {
        storeFile = keystoreFile
        storeType = "jks"
        storePassword = setting("STORE_PASSWORD")
        keyAlias = setting("KEY_ALIAS") ?: "ontcoin_key"
        keyPassword = setting("KEY_PASSWORD") ?: setting("STORE_PASSWORD")
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }

  buildFeatures {
    buildConfig = true
  }

  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

dependencies {
  implementation(platform(libs.firebase.bom))
  implementation(libs.firebase.messaging)

  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.appcompat)
  implementation(libs.androidx.biometric)
  implementation(libs.androidx.browser)

  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)

  implementation(libs.play.app.update)
  implementation(libs.play.app.update.ktx)

  implementation(libs.startio.inapp)
  // lets Start.io read the Google Advertising ID (needed for targeting, attribution and correct reporting)
  implementation(libs.play.ads.identifier)
}
